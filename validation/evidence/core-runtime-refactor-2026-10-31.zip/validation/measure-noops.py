import hashlib,json,os,subprocess,time,tempfile,statistics
from pathlib import Path
rows=[]
with tempfile.TemporaryDirectory(prefix='omktr-noops-') as temp:
 cwd=Path(temp); jobs=' '.join('job'+str(i) for i in range(2000))
 (cwd/'Makefile').write_text('.PHONY: all '+jobs+'\nall: '+jobs+'\n'+jobs+':\n\t@:\n')
 for sample in range(24):
  for variant in (('baseline','candidate') if sample%2==0 else ('candidate','baseline')):
   binary='/baseline/omktr' if variant=='baseline' else '/workspace/omktr'
   start=time.perf_counter(); p=subprocess.Popen([binary,'-j4','all'],cwd=cwd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); _,status,usage=os.wait4(p.pid,0); p.returncode=os.waitstatus_to_exitcode(status)
   assert p.returncode==0
   rows.append(dict(variant=variant,sample=sample,warmup=sample<3,seconds=time.perf_counter()-start,peak_rss_kib=usage.ru_maxrss))
report=dict(description='2000 phony literal no-op recipes, -j4, alternating paired order',binaries={v:hashlib.sha256(Path(p).read_bytes()).hexdigest() for v,p in [('baseline','/baseline/omktr'),('candidate','/workspace/omktr')]},samples=rows,medians={v:statistics.median(x['seconds'] for x in rows if x['variant']==v and not x['warmup']) for v in ('baseline','candidate')})
Path('/results/noop-recipes.json').write_text(json.dumps(report,indent=2)+'\n'); print(report['medians'])
