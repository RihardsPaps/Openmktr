import hashlib,json,statistics,subprocess,time,os
from pathlib import Path
root=Path('/evidence/refactor-ninja-confirmation'); rows=[]
for scenario in ('noop','missing'):
 for sample in range(51):
  for variant in (('baseline','candidate') if sample%2==0 else ('candidate','baseline')):
   cwd=root/('build-j4-retained-'+variant)
   tool='/baseline/omktr' if variant=='baseline' else '/workspace/omktr'
   expected=hashlib.sha256((cwd/'out0.o').read_bytes()).hexdigest()
   if scenario=='missing':(cwd/'out0.o').unlink()
   for phase,cmd in [('generation',[tool,'--ninja','--regen','-j4','all','--ninja_dir=.openmktr']),('execution',['sh','.openmktr/ninja.sh','-j4'])]:
    start=time.perf_counter();p=subprocess.Popen(cmd,cwd=cwd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); _,status,_=os.wait4(p.pid,0); p.returncode=os.waitstatus_to_exitcode(status); duration=time.perf_counter()-start
    assert p.returncode==0,(phase,variant)
    rows.append(dict(scenario=scenario,sample=sample,variant=variant,phase=phase,seconds=duration,warmup=sample<10))
   assert hashlib.sha256((cwd/'out0.o').read_bytes()).hexdigest()==expected
Path('/results/ninja-attribution-wait4.json').write_text(json.dumps(rows,indent=2)+'\n')
for scenario in ('noop','missing'):
 for phase in ('generation','execution'):
  print(scenario,phase,{v:statistics.median(x['seconds'] for x in rows if not x['warmup'] and x['scenario']==scenario and x['phase']==phase and x['variant']==v) for v in ('baseline','candidate')})
