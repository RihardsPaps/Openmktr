import json, os, subprocess, time
from pathlib import Path
root=Path('/evidence')
results=[]
def run(name, command, extra=None):
    env=dict(os.environ); env.update(extra or {})
    start=time.monotonic()
    with (root/(name+'.log')).open('w') as log:
        result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(name=name,command=command,exit_code=result.returncode,seconds=time.monotonic()-start)
    results.append(row)
    (root/'gates.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
for name in ('ready_queue','timeutil','find','ninja','strutil','load_limit'):
    run(name+'_unit',['out/'+name+'_test'])
for name in ('version_generator','correctness','generated_recipe_reads','graph_optimizations','make_compat_regressions','portage','manager','manager_terminal','load_limits','portage_validation','cross_version_cache','ninja_benchmark','workspace','ninja_jobserver','release_packaging','incremental_campaign'):
    run(name,['python','tests/'+name+'.py'])
run('correctness_aggressive',['python','tests/correctness.py'],{'OMKTR_TEST_GRAPH_PROFILE':'aggressive'})
run('regression',['python','tests/regression.py'])
run('regression_aggressive',['python','tests/regression.py'],{'OMKTR_TEST_GRAPH_PROFILE':'aggressive'})
run('dump',['sh','testcase/dump/run.sh'])
