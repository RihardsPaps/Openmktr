PR 74 Linux regression fixes, 6 November 2026.
All local execution used Docker Desktop on the user's PC. No NAS was accessed.
linux-final: 2242f8f versus e466d48, seven paired retained samples/two warmups.
linux-intermediate-e53d: superseded seven-pair attempt, kept separately.
diagnostics: exploratory phase profiles, not qualifying performance samples.
Some diagnostics use temporary child-profile instrumentation. Its injection
script and build logs are retained; it was removed and the restored sources
were rebuilt before qualification. The final binary was checked for absence
of the temporary profile-validation.json string.
local: build/test logs, expected failing-before regressions, controllers,
standard benchmark, header checks and the committed code patch from eab8428.
The retained trees originate in the earlier verified clean-build campaign.
These runs do not retime clean builds and do not test kernel booting.
The retained harness restores source mtimes and candidate fingerprint state
between source-touch cases. Following graph checks follow object restoration.
All code optimizations remain enabled. The strict combined gate remains false:
the no-op estimate/interval and small RSS median increases fail its thresholds.
No timing cell has a statistically supported regression in the final cohort.
The archive excludes large binaries and release source/object trees.
manifest.json hashes every other entry, including retained failed attempts.
