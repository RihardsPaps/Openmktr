from pathlib import Path

p = Path('/candidate/src/graph_import.cc')
s = p.read_text()
old = 'if (std::find(argv.begin(), argv.end(), "--regen") == argv.end())'
assert old in s
s = s.replace(old, 'argv.push_back("--stats_json=" + cache + "/profile-validation.json"); ' + old)
p.write_text(s)
p = Path('/candidate/src/main.cc')
s = p.read_text()
old = 'if (g_flags.import_root && getenv("KATI_IMPORT_VALIDATE_ONLY")) {'
assert old in s
p.write_text(s.replace(old, old + ' g_flags.enable_stat_logs = false;'))
