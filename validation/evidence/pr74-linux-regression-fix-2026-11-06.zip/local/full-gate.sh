#!/bin/sh
set -eu
cd /candidate
ninja -j4 omktr tests
out/session_test && out/ready_queue_test && out/timeutil_test && out/find_test && out/ninja_test && out/strutil_test && out/load_limit_test && python tests/version_generator.py && python tests/architecture.py && python tests/correctness.py && python tests/generated_recipe_reads.py && python tests/graph_optimizations.py && OMKTR_TEST_GRAPH_PROFILE=aggressive python tests/correctness.py && python tests/make_compat_regressions.py && python tests/portage.py && python tests/manager.py && python tests/manager_terminal.py && python tests/load_limits.py && python tests/portage_validation.py && python tests/cross_version_cache.py && python tests/ninja_benchmark.py && python tests/workspace.py && python tests/ninja_jobserver.py && python tests/release_packaging.py && python tests/regression.py && OMKTR_TEST_GRAPH_PROFILE=aggressive python tests/regression.py && sh testcase/dump/run.sh
python tools/gen_sanitizer_build.py
ninja -f build.sanitizer.ninja -j4 omktr-sanitized tests
ASAN_OPTIONS=detect_leaks=1 out/sanitized/session_test
export ASAN_OPTIONS=detect_leaks=0
export OMKTR_BINARY=/candidate/omktr-sanitized
for test in ready_queue timeutil find ninja strutil load_limit; do out/sanitized/"${test}_test"; done
for suite in portage load_limits architecture correctness generated_recipe_reads graph_optimizations workspace ninja_jobserver make_compat_regressions; do python tests/"${suite}.py"; done
OMKTR_TEST_GRAPH_PROFILE=aggressive python tests/correctness.py
CLANG_FORMAT_FILES='src/graph_import.cc src/graph_import.h src/ninja.cc src/ninja_test.cc src/import_observer.cc src/regen.cc src/main.cc src/command.cc' sh clang-format-check
