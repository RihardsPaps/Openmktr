from pathlib import Path
import struct, json, sys
data = memoryview(Path(sys.argv[1]).read_bytes())
position = 12
def integer():
    global position
    n, = struct.unpack_from('<i', data, position)
    position += 4
    assert 0 <= n <= 1000000
    return n
def string():
    global position
    n = integer()
    value = bytes(data[position:position+n]).decode()
    position += n
    return value
evaluation = integer()
artifacts = [(string(), string()) for _ in range(integer())]
files = [(string(), string()) for _ in range(integer())]
undefined = [string() for _ in range(integer())]
environment = [(string(), string()) for _ in range(integer())]
globs = [(string(), [string() for _ in range(integer())]) for _ in range(integer())]
commands = []
for _ in range(integer()):
    op = integer()
    command = dict(op=op, shell=string(), flag=string(), command=string(), result=string(), status=integer(), location=string(), line=integer())
    if op == 4:
        raise RuntimeError('FIND requires extra lists')
    commands.append(command)
print(json.dumps(dict(evaluation=evaluation, files=len(files), globs=len(globs), commands=commands), indent=2))
