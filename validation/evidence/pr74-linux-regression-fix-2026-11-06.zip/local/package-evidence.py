from pathlib import Path
import hashlib, json, re, zipfile

root = Path('/task-evidence')
final = json.loads((root/'linux-final-report.json').read_text())
header = json.loads((root/'header-touch.json').read_text())
standard = json.loads((root/'standard-benchmark.json').read_text())
assert final['failure'] is None and final['source_changes'] == []
assert len(final['summary']) == 4 and all(x['pairs'] == 7 for x in final['summary'])
assert not any(x['supported_regression'] for x in final['summary'])
assert header['revision'] == '2242f8fcbe42c4a3caf227ae89fd08ae0d497b28'
gate = (root/'utility-guard-full-gate.log').read_text()
assert gate.count('Ran 97 tests') == 2
assert gate.count('860/860 scenarios match; 0 known crashes quarantined') == 2
assert '\nFAILED (' not in gate
entries = {}
with zipfile.ZipFile(root/'release-evidence.zip') as source:
    for name in source.namelist():
        entries[name] = source.read(name)
for path in root.iterdir():
    if path.is_file() and path.suffix in ('.log','.json','.py','.sh','.patch'):
        entries['local/'+path.name] = path.read_bytes()
entries['README.txt'] = b'''PR 74 Linux regression fixes, 6 November 2026.
All local execution used Docker Desktop on the user's PC. No NAS was accessed.
linux-final: 2242f8f versus e466d48, seven paired retained samples/two warmups.
linux-intermediate-e53d: superseded seven-pair attempt, kept separately.
diagnostics: exploratory phase profiles, not qualifying performance samples.
Some diagnostics use temporary child-profile instrumentation. Its injection
script and build logs are retained; it was removed and the restored sources
were rebuilt before qualification. The final binary was checked for absence
of the temporary profile-validation.json string.
local: build/test logs, expected failing-before regressions, controllers,
standard benchmark, header checks and the committed code patch from eab8428.
The retained trees originate in the earlier verified clean-build campaign.
These runs do not retime clean builds and do not test kernel booting.
The retained harness restores source mtimes and candidate fingerprint state
between source-touch cases. Following graph checks follow object restoration.
All code optimizations remain enabled. The strict combined gate remains false:
the no-op estimate/interval and small RSS median increases fail its thresholds.
No timing cell has a statistically supported regression in the final cohort.
The archive excludes large binaries and release source/object trees.
manifest.json hashes every other entry, including retained failed attempts.
'''
manifest = {name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
            for name,data in sorted(entries.items())}
entries['manifest.json'] = (json.dumps(manifest,indent=2)+'\n').encode()
archive = Path('/pr74-linux-regression-fix-2026-11-06.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as output:
    for name,data in sorted(entries.items()):
        output.writestr(name,data)
archive_digest = hashlib.sha256(archive.read_bytes()).hexdigest()
report = dict(schema=1, date='2026-11-06',
    code_revision='2242f8fcbe42c4a3caf227ae89fd08ae0d497b28',
    baseline_revision='e466d484059e29f641142acd0fbcf81376b2ecc1',
    execution='User PC, Docker Desktop; no NAS; unpatched Linux 6.12',
    linux=final, header=header, standard_benchmark=standard,
    validation=dict(full_portable_gate=True, full_sanitizer_sequence=True,
                    graph_tests_normal=97,graph_tests_sanitized=97,
                    fresh_docker_image_graph_tests=97,
                    correctness_each_profile=210,snapshots_each_profile=860,
                    known_crashes=0,changed_cpp_formatting=True,
                    codex_review=dict(commit='2242f8fcbe42c4a3caf227ae89fd08ae0d497b28',
                                      completed=True,findings=False),
                    code_ci_runs=[42257690958,42257691072,42257691067],
                    code_ci_conclusions=['success','success','success']),
    limits=['Retained incremental comparison; clean builds not retimed.',
            'No kernel boot test.',
            'No-op confidence interval crosses zero; no no-op speedup claim.',
            'Strict combined timing/RSS gate false; no profile promotion.'],
    evidence=dict(path='evidence/'+archive.name, sha256=archive_digest,
                  bytes=archive.stat().st_size,entries=len(entries)))
Path('/pr74-linux-regression-fix.json').write_text(json.dumps(report,indent=2)+'\n')
Path('/pr74-linux-regression-fix-2026-11-06.zip.sha256').write_text(archive_digest+'  '+archive.name+'\n')
print(json.dumps(report['evidence']))
