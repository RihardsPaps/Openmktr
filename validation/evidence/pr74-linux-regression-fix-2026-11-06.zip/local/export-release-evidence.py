from pathlib import Path
import zipfile
root = Path('/reports')
entries = {}
for source, label in [('pr74-linux-fixed-2242','linux-final'),
                      ('pr74-linux-fixed-e53d','linux-intermediate-e53d'),
                      ('pr74-linux-preparation-2242','preparation'),
                      ('pr74-linux-header-2242','header')]:
    directory = root / source
    for path in directory.rglob('*'):
        if path.is_file():
            entries[label+'/'+str(path.relative_to(directory))] = path
for pattern in ('regression-profile-*.log','linear-profile-*.log','symbol-profile-*.log',
                'normalized-profile-*.log','bulk-profile-*.log','symmetric-profile-*.log',
                'observer-fast-profile-*.log','observer-history-profile-*.log',
                'child-profile-*.log','argument-fast-profile-*.log',
                'restored-argument-profile-*.log','native-probe-profile-*.log'):
    for path in (root/'pr74-linux-final').glob(pattern):
        entries['diagnostics/'+path.name] = path
for name in ('benchmark-retained-retry.py','run-linux-fixed-2242.py',
             'run-linux-fixed.py','probe-linux-validation.py',
             'prepare-final-linux.py','check-linux-header-2242.py'):
    entries['controllers/'+name] = Path('/'+name)
entries['toolchain/manifest.json'] = Path('/opt/pr74-toolchain/manifest.json')
with zipfile.ZipFile('/pr74-linux-release-evidence.zip','w',zipfile.ZIP_DEFLATED,9) as output:
    for name, path in sorted(entries.items()):
        output.write(path,name)
print(len(entries))
