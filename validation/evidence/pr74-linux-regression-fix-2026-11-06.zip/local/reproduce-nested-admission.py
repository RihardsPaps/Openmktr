from pathlib import Path
import os, subprocess, signal
root = Path('/tmp/pr74-nested-admission-repro')
root.mkdir(exist_ok=True)
(root/'grand').mkdir(exist_ok=True)
(root/'grand/Makefile').write_text('all:\n\t@printf done > result\n')
(root/'child.mk').write_text('all:\n\t@for directory in grand; do $(MAKE) -C $$directory all; done\n')
(root/'Makefile').write_text('all:\n\t@printf "state=%s\\n" "$$KATI_NINJA_RECURSION_STATE"; $(MAKE) --ninja --graph_optimizations=aggressive -f child.mk all && ninja all\n')
binary = '/pre-observer-fast'
subprocess.run([binary,'--ninja','--graph_optimizations=aggressive','all'],cwd=root,check=True)
print((root/'build.ninja').read_text(), flush=True)
child = subprocess.Popen(['ninja','-j4','all'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
try:
    output = child.communicate(timeout=4)[0]
    print('status',child.returncode,output)
except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGKILL)
    print('DEADLOCK',child.communicate()[0])
