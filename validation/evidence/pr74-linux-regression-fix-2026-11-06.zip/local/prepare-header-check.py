from pathlib import Path
p = Path('/check-linux-header.py').read_text()
p = p.replace('/reports/pr74-linux-retained-v4/report.json', '/reports/pr74-linux-fixed-2242/report.json')
p = p.replace("root = Path('/reports/pr74-linux-final')", "root = Path('/reports/pr74-linux-final')\nlogs = Path('/reports/pr74-linux-header-2242')\nlogs.mkdir()")
p = p.replace("root / 'header-touch.log'", "logs / 'header-touch.log'")
p = p.replace("root / 'header-touch.json'", "logs / 'header-touch.json'")
p = p.replace('result = dict(command=command,', "result = dict(revision=metadata['binaries']['candidate']['revision'], binary_sha256=digest(Path('/final-omktr')), command=command,")
Path('/check-linux-header-2242.py').write_text(p)
