# SPDX-License-Identifier: MPL-2.0
import subprocess
import sys

options = [
    '--graph_optimizations=aggressive', '--use_ninja_phony_output',
    'KCFLAGS=-Wno-error=default-const-init-var-unsafe -Wno-error=default-const-init-field-unsafe -Wno-error=unterminated-string-initialization',
    'KBUILD_BUILD_TIMESTAMP=2024-11-18T00:00:00Z',
]
command = [sys.executable, '/benchmark-retained-retry.py', '--root', '/reports/pr74-linux-fixed-e53d',
           '--archives', '/previous/input', '--baseline', '/baseline-omktr',
           '--candidate', '/final-omktr', '--baseline-revision',
           'e466d484059e29f641142acd0fbcf81376b2ecc1', '--candidate-revision',
           'e53d4f53027db85903c18ca0d1ed1d68c448f4e5', '--project', 'linux',
           '--entrypoints', 'build', '--jobs', '8', '--samples', '7',
           '--warmups', '2', '--retained', '--toolchain-dir', '/opt/pr74-toolchain/bin']
for variant in ('baseline', 'candidate'):
    command.extend('--' + variant + '-option=' + option for option in options)
subprocess.run(command, check=True)
