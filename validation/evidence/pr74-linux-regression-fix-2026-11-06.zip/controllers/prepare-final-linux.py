from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path('/reports/pr74-linux-final')
metadata = json.loads(Path('/reports/pr74-linux-retained-v4/report.json').read_text())['metadata']
env = dict(metadata['environment'], HOME='/root', USER='benchmark', LOGNAME='benchmark', SHELL='/bin/sh')
logs = Path('/reports/pr74-linux-preparation-2242')
logs.mkdir()
def digest(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
results = {}
for variant, tool in [('baseline','/baseline-omktr'),('candidate','/final-omktr')]:
    build = root / ('build-j8-retained-' + variant)
    command = [tool,'build','-j8','-f',str(root/'sources/linux-6.12/Makefile'),
               'LLVM=1','LLVM_IAS=1','ARCH=x86','all',*metadata[variant+'_options']]
    artifacts = ['vmlinux','arch/x86/boot/bzImage']
    before = {p:digest(build/p) for p in artifacts}
    start = time.monotonic()
    with (logs/(variant+'.log')).open('wb') as output:
        subprocess.run(command,cwd=build,env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
    after = {p:digest(build/p) for p in artifacts}
    assert before == after
    results[variant] = dict(command=command, seconds=time.monotonic()-start,
                            artifacts=after, config_sha256=digest(build/'.config'),
                            binary_sha256=digest(Path(tool)))
assert results['baseline']['artifacts'] == results['candidate']['artifacts']
assert results['baseline']['config_sha256'] == results['candidate']['config_sha256']
(logs/'preparation.json').write_text(json.dumps(results,indent=2)+'\n')
