#!/bin/sh
set -eu
. /etc/profile
export PATH=/usr/local/bin:$PATH
mkdir -p /repro/baseline
cd /repro/baseline
/src/configure --prefix=/usr --libdir=/usr/lib64 --enable-kernel=5.10 --disable-werror > /repro/configure-baseline.log 2>&1
/opt/omktr/omktr --ninja --graph_optimizations=aggressive -j8 all > /repro/generate-baseline.log 2>&1
KATI_JOBS=8 sh ./ninja.sh -j8 all > /repro/clean-baseline.log 2>&1
touch /src/sysdeps/wordsize-64/strtol.c
KATI_JOBS=8 sh ./ninja.sh -j8 all > /repro/incremental-baseline.log 2>&1
