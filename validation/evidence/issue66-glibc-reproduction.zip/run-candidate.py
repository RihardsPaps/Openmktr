import hashlib, json, os, pathlib, subprocess, time
root = pathlib.Path('/repro')
build = root / 'candidate'
build.mkdir()
binary = '/opt/omktr/omktr'
report = {'binary_sha256': hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(), 'phases': []}
env = dict(os.environ, KATI_JOBS='8')
def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT)
    report['phases'].append({'name': name, 'command': command, 'returncode': result.returncode, 'seconds': time.monotonic()-start})
    (root / 'candidate.json').write_text(json.dumps(report, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
run('configure-candidate', ['/src/configure', '--prefix=/usr', '--libdir=/usr/lib64', '--enable-kernel=5.10', '--disable-werror'])
run('generate-candidate', [binary, '--ninja', '--graph_optimizations=aggressive', '-j8', 'all'])
run('clean-candidate', ['sh', './ninja.sh', '-j8', 'all'])
for name in ['incremental-candidate', 'noop-candidate', 'incremental2-candidate']:
    if not name.startswith('noop'):
        pathlib.Path('/src/sysdeps/wordsize-64/strtol.c').touch()
    run(name, ['sh', './ninja.sh', '-j8', 'all'])
run('archive-candidate', ['readelf', '-h', 'linkobj/libc_pic.a'])
(root/'smoke.c').write_text('#include <stdlib.h>\n#include <string.h>\nint main(void) { char *e; return strtol("12345x", &e, 10)!=12345 || strcmp(e,"x"); }\n')
run('compile-smoke-candidate', ['gcc', str(root/'smoke.c'), '-o', str(root/'smoke')])
run('runtime-smoke-candidate', [str(build/'elf/ld.so'), '--library-path', str(build), str(root/'smoke')])
