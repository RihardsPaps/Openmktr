import hashlib, json, os, pathlib, subprocess, time
root = pathlib.Path('/repro')
build = root / 'candidate-v3'
build.mkdir()
binary = '/opt/omktr/omktr'
report = {'binary_sha256': hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(), 'phases': []}
env = dict(os.environ, KATI_JOBS='8')
def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT)
    report['phases'].append({'name': name, 'command': command, 'returncode': result.returncode, 'seconds': time.monotonic()-start})
    (root / 'candidate-v3.json').write_text(json.dumps(report, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
run('configure-candidate-v3', ['/src/configure', '--prefix=/usr', '--libdir=/usr/lib64', '--enable-kernel=5.10', '--disable-werror'])
run('generate-candidate-v3', [binary, '--ninja', '--graph_optimizations=aggressive', '-j8', 'all'])
run('clean-candidate-v3', ['sh', './ninja.sh', '-j8', 'all'])
for name in ['incremental-candidate-v3', 'noop-candidate-v3', 'incremental2-candidate-v3']:
    if not name.startswith('noop'):
        pathlib.Path('/src/sysdeps/wordsize-64/strtol.c').touch()
    run(name, ['sh', './ninja.sh', '-j8', 'all'])
run('archive-candidate-v3', ['readelf', '-h', 'linkobj/libc_pic.a'])
(root/'smoke.c').write_text('#include <stdlib.h>\n#include <string.h>\nint main(void) { char *e; return strtol("12345x", &e, 10)!=12345 || strcmp(e,"x"); }\n')
run('compile-smoke-candidate-v3', ['gcc', str(root/'smoke.c'), '-o', str(root/'smoke')])
run('runtime-smoke-candidate-v3', [str(build/'elf/ld.so'), '--library-path', str(build), str(root/'smoke')])
