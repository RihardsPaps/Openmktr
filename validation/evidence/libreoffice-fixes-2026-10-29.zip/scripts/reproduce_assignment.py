from pathlib import Path
import subprocess

root = Path('/root/omktr-lo-fix-20261029/assignment')
root.mkdir(parents=True, exist_ok=True)
(root / 'Makefile').write_text('''all: result
result: COMMAND := printf old > result
result:
	$(eval result: COMMAND := printf new > result)
	$(COMMAND)
''')
for tool in ['/root/openmktr-libreoffice-fullblast-20261029/omktr', '/root/omktr-lo-fix-20261029/omktr']:
    for mode in [[], ['--ninja']]:
        (root / 'result').unlink(missing_ok=True)
        result = subprocess.run([tool, *mode, 'all'], cwd=root, capture_output=True, text=True)
        print(tool, mode, result.returncode, result.stdout, result.stderr, flush=True)
        if result.returncode == 0 and mode:
            print(subprocess.run(['sh', 'ninja.sh'], cwd=root, capture_output=True, text=True))
        if (root / 'result').exists():
            print('OUTPUT:', (root / 'result').read_text())
