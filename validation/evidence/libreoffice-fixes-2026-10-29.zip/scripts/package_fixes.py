from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
root=Path('/root/omktr-lo-fix-20261029')
lo=root/'libreoffice'
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
patch=subprocess.check_output(['git','-C',str(repo),'diff','--','src','tests'])
(root/'implementation.patch').write_bytes(patch)
final=json.loads((root/'final-checks.json').read_text())
assert final['direct-sal-parallel']['exit_code']==0
assert final['direct-sal-parallel']['compiler_peak']==32
for lane in ['gnu','ninja','direct']:
    item=final['final-'+lane+'-repeat']
    assert item['exit_code']==0 and item['compiler_peak']==0 and item['selected_object_mtimes_unchanged']
assert len({final['final-'+lane+'-repeat']['library_sha256'] for lane in ['gnu','ninja','direct']})==1
for obj in final['final-gnu-repeat']['object_sha256']:
    assert len({final['final-'+lane+'-repeat']['object_sha256'][obj] for lane in ['gnu','ninja','direct']})==1
normal=(root/'normal-gate.log').read_text()
assert '858/858 scenarios match; 0 known crashes quarantined' in normal
assert 'Ran 180 tests' in normal and '\nFAILED' not in normal
suites=['portage','load_limits','correctness','graph_optimizations','workspace','ninja_jobserver','make_compat_regressions','aggressive']
for suite in suites:
    text=(root/('sanitized-'+suite+'.log')).read_text()
    assert re.search(r'\nOK(?: \(skipped=\d+\))?\s*$',text),suite
files=[p for p in root.glob('*.log')]+[root/'implementation.patch',root/'final-checks.json']
files += list(lo.glob('*.log'))+[lo/'bounded-results.json']
scripts=repo/'validation/logs/libreoffice-fullblast-20261029'
files += [scripts/name for name in ['reproduce_assignment.py','build_fix.py','validate_fix.py','format_fix.py','replay_fix.py','generate_sal.py','bounded_objects.py','final_checks.py','package_fixes.py']]
report={
 'date':'2026-10-29','status':'priority-fixes-validated-with-generated-read-limitation',
 'base_revision':'38ddf6d0e4c8bee9e5449992ed1c412205d6e56c',
 'branch':'codex/libreoffice-benchmark-20261029','implementation_patch_sha256':digest(root/'implementation.patch'),
 'candidate_binary_sha256':digest(root/'omktr'),'candidate_source_sha256':{str(p.relative_to(repo)):digest(p) for p in repo.joinpath('src').iterdir() if p.name in ['command.cc','dep.cc','eval.cc','eval.h','exec.cc','func.cc','ninja.cc','var.cc','var.h']},
 'version_note':'Locally built working-tree patch on the recorded revision. Binary version text alone does not identify these uncommitted changes.',
 'fixed':['recipe-time target-specific assignment use-after-free','active and later target binding refresh','prerequisite-first Ninja recipe evaluation','cycle-aware component ranks preserve cooperative scheduling','synthetic parent-directory edges cannot introduce a cycle','deferred response-file writes preserve empty Make value'],
 'baseline_evidence':{'assignment':'ASan heap-use-after-free; six profile/mode subcases fail','parallelism':'cycle cases peak at one worker instead of eight','response_file':'Ninja command embeds printf in RESPONSE assignment and fails','synthetic_directory':'baseline warns Circular headers/ <- headers/item'},
 'validation':{'environment':'Local Chimera chroot on user PC','docker':'Unavailable Docker Desktop Linux engine; Docker image gate not run','normal_gate':'C++ units, version, 180 correctness, compatibility, 858 snapshots, include dump passed','sanitizer_suites':suites,'sanitizer_skips':{'portage':1},'sanitized_cpp_units':'find_test ninja_test strutil_test load_limit_test passed','formatting':'Chimera clang-format-check passed for all changed C++ source/header files','full_libreoffice_benchmark_run':False,'source_integrity':(root/'source-integrity.log').read_text().strip()},
 'libreoffice':{'release':'25.2.7.2','compiler':'Clang 18.1.3','job_limit':32,'execution_cap_seconds':300,'broad_graph_generation':'exit 0, no SIGSEGV','broad_graph_missing_file_messages':(lo/'generation.log').read_text().count('No such file or directory'),'sal_graph_missing_file_messages':(lo/'generation-sal.log').read_text().count('No such file or directory'),'direct_cycle_warnings':(lo/'direct-objects.log').read_text().count('Circular'),'final_checks':final,'bounded_runs':json.loads((lo/'bounded-results.json').read_text())},
 'remaining':['Nested Make functions consuming generated-file reads still evaluate prematurely in the broader graph; no full Ninja LibreOffice correctness claim.','Ninja repeat validation/generation remains expensive (about 46 seconds in this bounded case).','Raw execution-only Ninja launchers cannot regenerate placeholder prerequisites when new depfiles appear; use omktr build.'],
 'scope':'No source patches to LibreOffice, no NAS access, no full benchmark, no merge or publication. Original benchmark evidence retained.'}
report['validation']['sanitizer_skip_reason']='Optional Portage test requires a binary configured with an absolute Ninja executable; this candidate uses PATH-based Ninja selection.'
(root/'fix-results.json').write_text(json.dumps(report,indent=2)+'\n')
files.append(root/'fix-results.json')
entries={}
for p in files:
    name=('libreoffice/'+p.name) if p.parent==lo else ('scripts/'+p.name) if p.parent==scripts else p.name
    assert name not in entries
    entries[name]=p
manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in entries.items()}
archive=repo/'validation/evidence/libreoffice-fixes-2026-10-29.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(entries.items()):z.write(p,name)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
report['evidence_archive']={'path':str(archive.relative_to(repo)),'sha256':digest(archive),'entries':len(entries)}
(repo/'validation/libreoffice-fix-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archive':report['evidence_archive'],'normal_gate':'passed','sanitizers':'passed','library_matches':True,'read_limit':report['libreoffice']['broad_graph_missing_file_messages']},indent=2))
