from pathlib import Path
import os
import shutil
import subprocess

root = Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
work = root / 'tmp/lo-fix-20261029'
baseline = root / 'tmp/lo-fix-baseline-20261029'
if not baseline.exists():
    shutil.copytree(root / 'tmp/lo-fullblast-tool-20261029', baseline)
shutil.copytree(work / 'tests', baseline / 'tests', dirs_exist_ok=True)
for directory, command in [('proc', ['mount', '-t', 'proc', 'proc']), ('dev', ['mount', '--bind', '/dev'])]:
    if subprocess.run(['mountpoint', '-q', str(root / directory)]).returncode:
        subprocess.run(command + [str(root / directory)], check=True)
logs = Path('/root/omktr-lo-fix-20261029')
def run(label, command):
    with (logs / (label + '.log')).open('w') as log:
        result = subprocess.run(['chroot', str(root), '/bin/sh', '-c', command], stdout=log, stderr=subprocess.STDOUT)
    print(label, result.returncode, flush=True)

run('baseline-sanitizer-build', 'cd /tmp/lo-fix-baseline-20261029 && python tools/gen_sanitizer_build.py && ninja -f build.sanitizer.ninja -j16 omktr-sanitized')
run('baseline-assignment-asan', 'cd /tmp/lo-fix-baseline-20261029 && ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY=/tmp/lo-fix-baseline-20261029/omktr-sanitized python tests/correctness.py BuildCorrectness.test_recipe_target_assignment_updates_active_binding')
run('baseline-concurrency', 'cd /tmp/lo-fix-baseline-20261029 && python tests/graph_optimizations.py GraphOptimizations.test_shared_dependency_waiters_keep_the_recipe_budget_busy')
run('normal-gate', 'cd /tmp/lo-fix-20261029 && ninja -j16 omktr tests && out/find_test && out/ninja_test && out/strutil_test && python tests/version_generator.py && python tests/correctness.py && python tests/make_compat_regressions.py && python tests/regression.py && sh testcase/dump/run.sh')
for suite in ['portage', 'load_limits', 'correctness', 'graph_optimizations', 'workspace', 'ninja_jobserver', 'make_compat_regressions']:
    run('sanitized-' + suite, 'cd /tmp/lo-fix-20261029 && ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY=/tmp/lo-fix-20261029/omktr-sanitized python tests/' + suite + '.py')
run('sanitized-aggressive', 'cd /tmp/lo-fix-20261029 && ASAN_OPTIONS=detect_leaks=0 OMKTR_TEST_GRAPH_PROFILE=aggressive OMKTR_BINARY=/tmp/lo-fix-20261029/omktr-sanitized python tests/correctness.py')
