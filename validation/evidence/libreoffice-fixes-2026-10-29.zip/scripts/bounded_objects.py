from pathlib import Path
import hashlib
import json
import os
import runpy
import signal
import subprocess
import time

settings = runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root = Path('/root/omktr-lo-fix-20261029/libreoffice')
source = root / 'libreoffice-25.2.7.2'
candidate = root / 'build'
gnu = root / 'gnu-small'
gnu.mkdir(exist_ok=True)
graph = (candidate / '.openmktr/build.ninja').read_text()
relative = []
for path in sorted((source / 'sal/rtl').glob('*.cxx')):
    obj = Path('workdir/CxxObject/sal/rtl') / (path.stem + '.o')
    if 'build ' + str(candidate / obj) + ':' in graph:
        relative.append(obj)
    if len(relative) == 8:
        break
assert len(relative) == 8
report = {'targets':list(map(str, relative)), 'execution_cap_seconds':300, 'runs':{}}
def run(label, command, cwd, env):
    start = time.monotonic()
    peak = 0
    with (root / (label + '.log')).open('w') as log:
        child = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while child.poll() is None and time.monotonic() - start < 300:
            count = 0
            for p in Path('/proc').glob('[0-9]*/comm'):
                try:
                    count += p.read_text().strip() == 'clang++-18'
                except OSError:
                    pass
            peak = max(peak, count)
            time.sleep(.05)
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        report['runs'][label] = {'exit_code':child.returncode, 'wall_seconds':time.monotonic()-start, 'observed_compiler_peak':peak, 'command':command}
    (root / 'bounded-results.json').write_text(json.dumps(report,indent=2))
    print(label,report['runs'][label],flush=True)
    return child.returncode
env = dict(settings['ENV'], SRCDIR=str(source), BUILDDIR=str(gnu), WORKDIR=str(gnu / 'workdir'))
assert run('gnu-small-configure',[str(source / 'configure')] + settings['OPTIONS'],gnu,env) == 0
langs = next(l.split('=',1)[1] for l in (gnu/'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
direct = root / 'direct-small'
direct.mkdir(exist_ok=True)
direct_env = dict(env,BUILDDIR=str(direct),WORKDIR=str(direct/'workdir'))
assert run('direct-small-configure',[str(source/'configure')]+settings['OPTIONS'],direct,direct_env)==0
for lane, directory in [('gnu',gnu),('ninja',candidate),('direct',direct)]:
    lane_env = dict(env,BUILDDIR=str(directory),WORKDIR=str(directory/'workdir'))
    # Enter the library scope: GNU raw-object goals omit inherited include
    # and define settings. This is still a bounded SAL-only validation.
    targets = ['Library_sal']
    tool = '/usr/bin/make' if lane=='gnu' else '/root/omktr-lo-fix-20261029/omktr'
    for obj in relative:
        path = directory / obj
        assert path.is_relative_to(root)
        path.unlink(missing_ok=True)
    command = [tool] + (['build','--ninja_dir=.openmktr-sal','--graph_optimizations=aggressive'] if lane=='ninja' else ['--graph_optimizations=aggressive'] if lane=='direct' else []) + ['-j32','-rs','-f',str(source/'Makefile.gbuild'),'MAKE='+tool,'ALL_LANGS='+langs]+targets
    run(lane+'-objects',command,directory,lane_env)
    run(lane+'-repeat',command,directory,lane_env)
report['objects']={str(obj):{lane:hashlib.sha256((directory/obj).read_bytes()).hexdigest() if (directory/obj).exists() else None for lane,directory in [('gnu',gnu),('ninja',candidate),('direct',direct)]} for obj in relative}
(root/'bounded-results.json').write_text(json.dumps(report,indent=2))
