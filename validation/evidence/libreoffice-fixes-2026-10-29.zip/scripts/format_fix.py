from pathlib import Path
import shutil
import subprocess

repo = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
root = Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
work = root / 'tmp/lo-fix-20261029'
files = ['src/command.cc','src/eval.cc','src/eval.h','src/exec.cc','src/dep.cc','src/ninja.cc','src/var.cc','src/var.h','src/func.cc']
for name in files:
    shutil.copy2(repo/name,work/name)
subprocess.run(['chroot',str(root),'clang-format','-i']+['/tmp/lo-fix-20261029/'+name for name in files],check=True)
for name in files:
    shutil.copy2(work/name,repo/name)
