from pathlib import Path
import shutil
import subprocess

repo = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
chroot = Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
old = chroot / 'tmp/lo-fullblast-tool-20261029'
work = chroot / 'tmp/lo-fix-20261029'
if not work.exists():
    shutil.copytree(old, work)
for directory in ['src', 'tests', 'tools']:
    shutil.copytree(repo / directory, work / directory, dirs_exist_ok=True)
for target, command in [('dev', ['mount', '--bind', '/dev']), ('proc', ['mount', '-t', 'proc', 'proc'])]:
    if not subprocess.run(['mountpoint', '-q', str(chroot / target)]).returncode == 0:
        subprocess.run(command + [str(chroot / target)], check=True)
subprocess.run(['chroot', str(chroot), '/bin/sh', '-c',
                'cd /tmp/lo-fix-20261029 && ninja -j32 omktr'], check=True)
destination = Path('/root/omktr-lo-fix-20261029/omktr')
shutil.copy2(work / 'omktr', destination.with_suffix('.next'))
destination.with_suffix('.next').replace(destination)
