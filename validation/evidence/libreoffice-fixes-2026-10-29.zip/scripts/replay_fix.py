from pathlib import Path
import os
import runpy
import subprocess
import tarfile

settings = runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root = Path('/root/omktr-lo-fix-20261029/libreoffice')
root.mkdir(parents=True, exist_ok=True)
source = root / 'libreoffice-25.2.7.2'
if not source.exists():
    with tarfile.open(settings['ARCHIVE']) as archive:
        archive.extractall(root, filter='data')
build = root / 'build'
build.mkdir(exist_ok=True)
tool = '/root/omktr-lo-fix-20261029/omktr'
env = dict(settings['ENV'], SRCDIR=str(source), BUILDDIR=str(build), WORKDIR=str(build / 'workdir'))
def run(label, command):
    with (root / (label + '.log')).open('w') as log:
        try:
            status = subprocess.run(command, cwd=build, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=300).returncode
        except subprocess.TimeoutExpired:
            status = 'timeout'
    print(label, status, flush=True)
    return status
if run('configure', [str(source / 'configure')] + settings['OPTIONS']) == 0:
    if run('bootstrap', [tool, '-j32', 'MAKE=' + tool, 'bootstrap', 'fetch', 'install-gdb-printers']) == 0:
        langs = next(l.split('=', 1)[1] for l in (build / 'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
        run('generation', [tool, '--ninja', '--regen', '--ninja_dir=.openmktr', '--graph_optimizations=aggressive', '-j32', '-rs', '-f', str(source / 'Makefile.gbuild'), 'MAKE=' + tool, 'ALL_LANGS=' + langs, 'build'])
