from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

root=Path('/root/omktr-lo-fix-20261029')
lo=root/'libreoffice'
results=json.loads((lo/'bounded-results.json').read_text())
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',CCACHE_DISABLE='1',LC_ALL='C')
checks={}
def run(label,command,directory):
    start=time.monotonic();peak=0
    with (root/(label+'.log')).open('w') as log:
        process=subprocess.Popen(command,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while process.poll() is None and time.monotonic()-start<300:
            count=0
            for p in Path('/proc').glob('[0-9]*/comm'):
                try: count+=p.read_text().strip()=='clang++-18'
                except OSError: pass
            peak=max(peak,count);time.sleep(.02)
        timed_out=process.poll() is None
        if timed_out:
            os.killpg(process.pid,signal.SIGKILL)
        process.wait()
    checks[label]={'exit_code':process.returncode,'timeout':timed_out,'seconds':time.monotonic()-start,'compiler_peak':peak,'command':command}
    print(label,checks[label]['exit_code'],peak,flush=True)
    return checks[label]
direct=lo/'direct-small'
env.update(SRCDIR=str(lo/'libreoffice-25.2.7.2'),BUILDDIR=str(direct),WORKDIR=str(direct/'workdir'))
objects=list((direct/'workdir').rglob('*.o'))
for p in objects:
    assert p.resolve().is_relative_to(direct.resolve())
    p.unlink()
run('direct-sal-parallel',results['runs']['direct-objects']['command'],direct)
for lane,directory in [('gnu',lo/'gnu-small'),('ninja',lo/'build'),('direct',direct)]:
    env.update(SRCDIR=str(lo/'libreoffice-25.2.7.2'),BUILDDIR=str(directory),WORKDIR=str(directory/'workdir'))
    before={target:(directory/target).stat().st_mtime_ns for target in results['targets']}
    run('final-'+lane+'-repeat',results['runs'][lane+'-repeat']['command'],directory)
    checks['final-'+lane+'-repeat']['selected_object_mtimes_unchanged']=before=={target:(directory/target).stat().st_mtime_ns for target in results['targets']}
    checks['final-'+lane+'-repeat']['object_sha256']={target:hashlib.sha256((directory/target).read_bytes()).hexdigest() for target in results['targets']}
    library=directory/'instdir/program/libuno_sal.so.3'
    checks['final-'+lane+'-repeat']['library_sha256']=hashlib.sha256(library.read_bytes()).hexdigest()
(root/'final-checks.json').write_text(json.dumps(checks,indent=2))
