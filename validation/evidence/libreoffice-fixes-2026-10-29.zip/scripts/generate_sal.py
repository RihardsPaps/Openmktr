from pathlib import Path
import os
import runpy
import subprocess

settings=runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root=Path('/root/omktr-lo-fix-20261029/libreoffice')
source=root/'libreoffice-25.2.7.2'
build=root/'build'
tool='/root/omktr-lo-fix-20261029/omktr'
langs=next(l.split('=',1)[1] for l in (build/'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
env=dict(settings['ENV'],SRCDIR=str(source),BUILDDIR=str(build),WORKDIR=str(build/'workdir'))
command=[tool,'--ninja','--regen','--ninja_dir=.openmktr-sal','--graph_optimizations=aggressive','-j32','-rs','-f',str(source/'Makefile.gbuild'),'MAKE='+tool,'ALL_LANGS='+langs,'Library_sal']
with (root/'generation-sal.log').open('w') as log:
    result=subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
print('SAL generation',result.returncode)
