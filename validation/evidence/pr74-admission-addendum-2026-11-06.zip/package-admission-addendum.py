# SPDX-License-Identifier: MPL-2.0
import hashlib
import json
from pathlib import Path
import zipfile

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

root = Path('/candidate')
metadata = dict(code_revision='ac1ce3fd7e190d9f226f750c3470f1351e30750b',
                finding='https://github.com/RihardsPaps/Openmktr/pull/74#discussion_r4493339196',
                binary_sha256=digest(root/'omktr'),
                before_binary_sha256=digest(Path('/pre-alias-omktr')),
                graph_tests_normal=91, graph_tests_asan_ubsan=91,
                aggressive_correctness=210, aggressive_snapshots=860,
                ninja_jobserver_tests=14, shell_indirection_cases=8,
                shell_indirection_before='all eight cases fail',
                shell_indirection_after='all eight cases pass with peak=1',
                deferred_literal_compiler_peak='3 to 4 workers in native and standalone Ninja',
                performance_matrix_rerun=False,
                limitation='Dollar/backtick shell expressions retain conservative admission; earlier performance tables keep their measured revisions.')
paths = {str(p.relative_to('/admission-evidence')): p for p in Path('/admission-evidence').iterdir() if p.is_file()}
for name in ('src/command.cc', 'tests/graph_optimizations.py', 'LICENSE', 'NOTICE', 'docs/LICENSING.md'):
    paths['source/'+name] = root/name
paths['package-admission-addendum.py'] = Path('/package-admission-addendum.py')
manifest = {}
archive = Path('/pr74-admission-addendum.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, path in sorted(paths.items()):
        data = path.read_bytes()
        output.writestr(name, data)
        manifest[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    data = (json.dumps(metadata, indent=2)+'\n').encode()
    output.writestr('results.json', data)
    manifest['results.json'] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    output.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(path='validation/evidence/pr74-admission-addendum-2026-11-06.zip',
                     sha256=digest(archive), bytes=archive.stat().st_size,
                     entries=len(manifest), metadata=metadata), indent=2))
