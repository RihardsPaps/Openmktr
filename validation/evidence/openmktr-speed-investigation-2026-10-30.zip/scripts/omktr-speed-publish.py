from pathlib import Path
import collections,hashlib,json,re,shutil,statistics,zipfile
E=Path('/root/openmktr-speed-20261030');repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
def load(name):return json.loads((E/name).read_text())
historical_path=repo/'validation/libreoffice-improvements-results.json'
old=json.loads(historical_path.read_text())
def samples(label):return [load(label+suffix+'.json') for suffix in ('','-warm-1','-warm-2')]
generation={label:samples(label+'-1') for label in ('aggressive','safe','nomemo')}
warm={k:statistics.mean(x['wall_seconds'] for x in v[1:]) for k,v in generation.items()}
baseline=load('clean-front-baseline-generate.json');candidate=load('clean-front-nomemo-generate.json')
saving=baseline['wall_seconds']-candidate['wall_seconds']
historical_runs={k:old['benchmark']['runs'][k] for k in ('gnu-build','aggressive-v17-build')}
gap=historical_runs['aggressive-v17-build']['wall_seconds']-historical_runs['gnu-build']['wall_seconds']
runtime=load('runtime-results.json');graph=load('graph-compaction.json');audit=load('audit.json');restore=load('restoration.json')
runtime_medians={k:{field:statistics.median(r[field] for r in rows) for field in rows[0]} for k,rows in runtime['samples'].items()}
phases={}
for name in ('clean-front-baseline-generate','clean-front-nomemo-generate','aggressive-1','aggressive-1-warm-1','aggressive-1-warm-2','safe-1','safe-1-warm-1','safe-1-warm-2','nomemo-1','nomemo-1-warm-1','nomemo-1-warm-2'):
    log=(E/(name+'.log')).read_text()
    phases[name]={key:[float(x) for x in re.findall(r'^\*kati\*: '+re.escape(key)+r': ([0-9.]+)',log,re.M)] for key in ('eval time','make dep time','ninja gen (eval)','ninja gen (emit)','generate ninja time','execute included makefiles time')}
    phases[name]['action_tags']=dict(collections.Counter(re.findall(r'\[build ([^]]+)\]',log)))
assert audit['source_integrity_exit_code']==0 and audit['clean_configurations_match']
assert not audit['working_source_differences_from_frozen_baseline']
assert load('bench-j32-status.json')['exit_code']==0
assert restore['original_sha256']==restore['restored_sha256'] and restore['final_timesync_service']=='active'
assert all(r['exit_code']==0 for values in generation.values() for r in values)
assert phases['clean-front-baseline-generate']['action_tags']==phases['clean-front-nomemo-generate']['action_tags']
report=dict(schema='openmktr-speed-investigation-v1',date='2026-10-30',local_workspace=str(E),
    scope='Performance investigation and disposable diagnostic prototypes; no production C++ edits or completed full clean-build speedup claim.',
    protocol=dict(jobs=32,wsl_memory_gib=30,host_physical_bytes=restore['host_physical_bytes'],clock='CLOCK_MONOTONIC_RAW',sequential_workloads=True,cache_policy='filesystem caches uncontrolled; compiler caches disabled for LibreOffice phases',
        generation='one initial and two repeated generations per variant, original build protected by private overlay mounts',
        clean_front='fresh out-of-tree configurations; original source mounted read-only; candidate first, baseline second; graph preparation only',
        toolchain='Clang 22.1.8, musl, libc++, O2, ThinLTO; diagnostic changes only IncrementalEvaluator enabled_ to false',
        runtime='four alternating batches per variant, 256 recipes per batch, 32 concurrent workers, outputs checked after every batch; instrumented timings separate',
        standard_bench='disposable tests/bench.py copy changes job limits to 32, removes 1/4 job lanes, uses raw clock; 2 warmups and 3 measured samples in Chimera'),
    historical=dict(report=str(historical_path.relative_to(repo)),sha256=hashlib.sha256(historical_path.read_bytes()).hexdigest(),runs=historical_runs,gap_seconds=gap),
    clean_front=dict(baseline=baseline,diagnostic=candidate,saving_seconds=saving,saving_percent=100*saving/baseline['wall_seconds'],saving_as_percent_of_historical_gap=100*saving/gap),
    generation=generation,warm_generation_mean_seconds=warm,phase_statistics=phases,
    runtime=runtime,runtime_medians=runtime_medians,graph_compaction=graph,audit=audit,
    standard_bench=load('bench-j32.json'),standard_bench_status=load('bench-j32-status.json'),diagnostic_build=load('diagnostic-no-memo-build.json'),
    profiler=dict(generation=load('generation-perf.json'),note='Sampling only; WSL perf lacks ELF/DWARF unwind support. Leaf offsets were mapped through ELF load segments and llvm-symbolizer. Unresolved library symbols remain unresolved. Raw stack data retained locally, excluded from archive.'),
    excluded=dict(disabling_entire_evaluation_feature=load('noeval-1.json'),interrupted_execution_probe=load('execution-perf.json'),
        reasons=['Entire evaluation switch also disables pattern-variable indexing; stopped after 165 seconds while still resolving dependencies.',
                 'Execution following diagnostic regeneration scheduled compilation; interrupted after 35 seconds, never counted as no-op or complete clean timing.',
                 'Setup retries corrected an absolute perf path, a relative fixture context path, a reused fixture directory, and an unmounted Chimera /proc. Only successful timed results are compared.']),
    restoration=restore,
    limits=['No fresh full GNU/Openmktr clean comparison or completed full application validation for diagnostic variant.',
            'Initial preparation pair and two warm repetitions per profile are not randomized statistical confidence intervals.',
            'Microbenchmark isolates context load/restore and trivial expansion, excluding production supervision and read-certificate publication.',
            'Generated graph identities can change with executable path and inherited environment; original WSL_INTEROP differs after restarting WSL. Standalone launcher probes are not qualified no-op comparisons.',
            'Normal and sanitizer gates and new CI were not run for this disposable diagnostic experiment. Prior full-build correctness remains the historical report boundary.'])

doc=f'''# Openmktr speed investigation on LibreOffice

The largest confirmed opportunity is evaluation memoization overhead. A disposable
variant that disables memoization while retaining pattern-variable indexing cuts
fresh LibreOffice graph preparation from **{baseline['wall_seconds']:.2f} s to
{candidate['wall_seconds']:.2f} s**. The **{saving:.2f} s** phase saving is equivalent
to **{100*saving/gap:.1f}%** of the latest reported {gap:.3f}-second clean-build gap.
It is not a measured reduction in a completed full build.

The existing Safe profile also generates this project's graph faster than
Aggressive. Runtime context restoration is the next measured CPU target.
Graph path compaction reduces storage and Ninja loading memory, but the tested
form does not improve loading time.

[Structured results](../validation/openmktr-speed-investigation-results.json)
and [checksummed evidence](../validation/evidence/openmktr-speed-investigation-2026-10-30.zip)
retain commands, individual samples, diagnostic patches, scripts and logs.
The [previous full comparison](libreoffice-improvements-2026-10-30.md) remains
the authoritative completed build comparison: GNU 834.112 s, Openmktr 960.223 s.

## Test conditions and boundaries

All benchmark workloads ran on the user's PC, in native WSL Linux storage. Every build invocation
requested 32 jobs; the runtime fixture used 32 workers. WSL temporarily had 30 GiB
RAM and 16 GiB swap, leaving about 1.8 GiB of the host's physical memory for Windows.
Serial evaluation cannot use all 32 workers merely because the job limit is 32.
Workloads ran sequentially. No NAS was accessed.

The measured baseline is the exact reported binary, SHA-256
`{old['candidate_sha256']}`. The diagnostic uses the same Chimera Clang 22.1.8,
musl, libc++, O2 and ThinLTO toolchain. Its sole behavioral source change is
forcing `IncrementalEvaluator::enabled_` false in a disposable source copy.
The working C++ files still match the frozen baseline after CRLF normalization.
No production optimization, commit, push or PR was made.

Generation controls use private copy-on-write overlays of the retained build.
Fresh preparation uses two new build directories and a read-only mount of the
original release source. Normalized configurations match. Original-source
verification checks 147,364 files/symlinks with zero differences. The retained
original graph's SHA-256 is unchanged. Timers use CLOCK_MONOTONIC_RAW; guest NTP
was temporarily stopped for the generation and standard benchmark controls, then
restored. The original 24 GiB WSL configuration was restored byte for byte and
confirmed active at final inspection.

## Evaluation caching is losing on this workload

The fresh preparation pair includes initial evaluation, generated include work,
the required restart, dependency resolution and graph emission. It excludes the
main Ninja application build, configuration and bootstrap setup timers. Each
configuration completed the same visible include-remake work: one C compilation,
one link and 303 dependency actions.

| Fresh graph preparation | Current Aggressive | Memoization disabled with index retained |
| --- | ---: | ---: |
| Complete generation invocation | {baseline['wall_seconds']:.3f} s | {candidate['wall_seconds']:.3f} s |
| First Makefile evaluation | 27.993 s | 3.705 s |
| Evaluation after include restart | 28.271 s | 2.755 s |
| Include execution before restart | 13.473 s | 13.230 s |
| Final dependency resolution | 4.431 s | 4.600 s |
| Final Ninja generation | 13.440 s | 8.435 s |

Scoped rows can overlap; do not sum them to reconstruct the total. The candidate
ran first, with uncontrolled filesystem caches. This is one preparation pair,
not a confidence interval or a completed LibreOffice speed result.

On the retained, populated build, the repeated generation controls were:

| Variant | Initial invocation | Repeat 1 | Repeat 2 | Repeat mean |
| --- | ---: | ---: | ---: | ---: |
| Current Aggressive | {generation['aggressive'][0]['wall_seconds']:.2f} s | {generation['aggressive'][1]['wall_seconds']:.2f} s | {generation['aggressive'][2]['wall_seconds']:.2f} s | {warm['aggressive']:.2f} s |
| Current Safe | {generation['safe'][0]['wall_seconds']:.2f} s | {generation['safe'][1]['wall_seconds']:.2f} s | {generation['safe'][2]['wall_seconds']:.2f} s | {warm['safe']:.2f} s |
| Diagnostic with index retained | {generation['nomemo'][0]['wall_seconds']:.2f} s | {generation['nomemo'][1]['wall_seconds']:.2f} s | {generation['nomemo'][2]['wall_seconds']:.2f} s | {warm['nomemo']:.2f} s |

Safe's repeat mean is {100*(1-warm['safe']/warm['aggressive']):.1f}% below Aggressive;
the diagnostic's is {100*(1-warm['nomemo']/warm['aggressive']):.1f}% below Aggressive.
These are generation-only results. They do not establish faster complete Safe
builds or verified no-op invocations.

The profiled Aggressive generation recorded 76,544 region hits and 3,758,065
misses, approximately a 2% hit rate. In
[incremental_eval.cc](../src/incremental_eval.cc), `Begin`, `AppendScopeIdentity`,
`Fingerprint`, `Read` and `StateRead` construct keys and copy binding identities
while trying to reuse those regions. The experiment attributes a large phase cost
to the memoization subsystem collectively; it does not individually time each
of those functions.

**Do not use `--disable_graph_optimization=evaluation` as the proposed fix.**
[DepBuilder's pattern-variable index](../src/dep.cc) uses that same feature flag.
There are only two pattern scopes among 13,725 target scopes in this build.
Disabling the feature makes dependency resolution scan the much larger set for
every target. That control was stopped after 165.05 s while still resolving
dependencies. The diagnostic separates the two mechanisms and keeps the index.

## Runtime recipes repeatedly restore a large context

The fresh graph contains 4,356 deferred recipes, of which **3,454** reference a
roughly 32.64 MB global context. If each deferred recipe runs once, the references
represent **112.83 GB** of context reads. This is calculated logical input volume,
not physical disk traffic or a syscall trace; the page cache can serve the bytes.

A separate fixture invokes 256 trivial deferred recipes with 32 workers, using
the unchanged binary. The large variant loads the real retained 32.74 MB context
with 4,574 definitions; fixture definitions override its relevant bindings. Four
batches per variant alternate order. All 2,048 timed outputs contain the expected
text. Median results are:

| Context | Wall time per 256 recipes | Aggregate child CPU time |
| --- | ---: | ---: |
| Small fixture context | {runtime_medians['small']['wall_seconds']:.3f} s | {runtime_medians['small']['cpu_seconds']:.2f} CPU-s |
| LibreOffice context | {runtime_medians['libreoffice']['wall_seconds']:.3f} s | {runtime_medians['libreoffice']['cpu_seconds']:.2f} CPU-s |

This isolates context loading, restoration and trivial evaluation, without the
production supervisor and successful-read certificate publication. Its ratio is
not a full-build speedup. Separate instrumented runs confirm substantial time
in metadata reading and variable restoration before evaluating the tiny recipe.

[RunRuntimeRecipe](../src/command.cc) eagerly restores every global definition.
[ReadGraphCache](../src/graph_optimization.cc) reads, copies and checksums the
complete payload. The next prototype should validate the context once, index
definitions, and restore values lazily when used. Preserve computed references,
origin/flavor, exports, automatic variables, local eval effects and corrupt-state
rejection. A shared decoded-context design needs equally strict per-recipe
isolation; a persistent worker service is not the first change to attempt.

## Graph compaction helps memory rather than this speed gap

An offline prototype replaces repeated build/source path prefixes on Ninja
build lines with Ninja variables. Expanding each replacement reproduces its
original line byte for byte. Ninja successfully parses both graphs and emits
identical complete target listings, including order, in all four query runs.

The graph shrinks from **438,672,627 to 249,794,087 bytes**. Ninja target-query peak
RSS falls from approximately **579 MiB to 398 MiB**, but query time rises from
**0.96–0.98 s to 1.10–1.15 s**. The experiment leaves commands and dependencies
intact. It supports a storage/memory improvement, not a speed claim; it does not
address Openmktr's much larger evaluation memory peak.

## Implementation order and acceptance

1. **Separate pattern indexing from memoization policy.** Keep indexing active.
   Add independent cache control and selective admission or a bounded fallback
   when recording and validation cost exceeds useful reuse. Prioritize repeated
   key/fingerprint allocation and cold-region churn. Safe is a useful existing
   profile control, but its full LibreOffice build still needs measurement.
2. **Reduce runtime context loading and restoration.** Use the real-context
   fixture as a regression benchmark. Compare CPU time and allocation as well as
   wall time; retain all variable, export, effect, cancellation and jobserver
   semantics. Do not remove checksums or make context inputs order-only to win
   a benchmark.
3. **Measure the remaining execution cost after those changes.** Trace native
   freshness/proof helpers, shell/exec overhead and the post-startup critical
   path. The historical clean run used 1,495 more CPU-seconds and averaged 28.65
   cores versus GNU's 31.19. Both historical clean runs had ample available RAM
   and zero swap. More allocated RAM alone is not the missing optimization.
4. **Qualify a fresh full pair at 32 jobs and equal RAM.** Require the established
   output, repeat-build, Writer/Calc/Impress and source-integrity checks, normal
   and sanitizer gates, and incremental correctness. Measure configuration,
   initial preparation, execution and complete invocation separately. Repeat
   with alternating order before claiming the 15.12% gap closed. Direct mode is
   also a useful control because it avoids Ninja emission and serialized runtime
   contexts, but its full LibreOffice performance is not established here.

The GNU-free Chimera `tests/bench.py` comparison passed with both matching
toolchain binaries. A disposable copy sets every job limit to 32, removes the
one/four-job lanes and uses the raw clock; the patch and all samples are retained.
Its small default-profile workloads show no material change in conversion or
recipe launch time, reinforcing that the LibreOffice result is workload-specific.
This investigation does not replace the production normal/sanitizer gates or CI.

## Retained exclusions and reproduction

The complete controller scripts live in the evidence archive and in
`/root/openmktr-speed-20261030` on this PC. They use fixed retained campaign paths
and fresh-directory guards; adapt output names before rerunning. Raw profiler
stacks, binaries, contexts and large graphs remain local and are not packaged.

The sampling run is separate from untraced timings. WSL's perf build lacks
ELF/DWARF unwinding support; leaf addresses were resolved with LLVM where
possible, and unresolved symbols remain marked. An execution probe after
diagnostic regeneration scheduled compiler work and was deliberately interrupted
after 35.36 s. It is not a no-op result or a complete clean result. Changed binary
paths and inherited environment can invalidate generated recipes; WSL_INTEROP
also changed across WSL sessions. No attribution of that probe to a production
correctness defect is made. Setup retries and both stopped controls are retained.
'''
docpath=repo/'docs/openmktr-speed-investigation-2026-10-30.md'
docpath.write_text(doc)
(E/'results-before-archive.json').write_text(json.dumps(report,indent=2))
scripts=E/'scripts';scripts.mkdir(exist_ok=True)
for path in Path('/mnt/c/Users/Harry/AppData/Local/Temp').glob('omktr-speed-*.py'):
    shutil.copy2(path,scripts/path.name)
archive=repo/'validation/evidence/openmktr-speed-investigation-2026-10-30.zip'
manifest={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    selected=[p for p in E.iterdir() if p.is_file() and (p.suffix in ('.json','.log','.stderr','.patch') or p.name.endswith('-perf-raw.txt'))]
    selected += list(scripts.glob('*.py'))
    for p in sorted(selected):
        data=p.read_bytes();name=str(p.relative_to(E));z.writestr(name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    z.writestr('report.md',doc);manifest['report.md']=hashlib.sha256(doc.encode()).hexdigest()
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(archive_hash+'  '+archive.name+'\n')
report['evidence_archive']=dict(path=str(archive.relative_to(repo)),sha256=archive_hash,bytes=archive.stat().st_size,entries=len(manifest)+1,crc_and_entry_hashes_verified=True)
jsonpath=repo/'validation/openmktr-speed-investigation-results.json';jsonpath.write_text(json.dumps(report,indent=2))
print(json.dumps(dict(report=str(docpath),results=str(jsonpath),archive=report['evidence_archive'],warm_means=warm,clean_saving=saving),indent=2))
