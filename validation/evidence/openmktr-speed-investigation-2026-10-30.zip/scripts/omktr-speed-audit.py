from pathlib import Path
import collections,hashlib,json,re,struct,subprocess
E=Path('/root/openmktr-speed-20261030');P=Path('/root/libreoffice-improvements-20261029')
repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
build=P/'final-pair17-clock-controlled/aggressive-v17/build'

def context_path(path):
    with path.open('rb') as f:
        for _ in range(2):f.seek(struct.unpack('<Q',f.read(8))[0],1)
        payload_length=struct.unpack('<Q',f.read(8))[0]
        for _ in range(7):f.seek(struct.unpack('<Q',f.read(8))[0],1)
        return f.read(struct.unpack('<Q',f.read(8))[0]).decode()

result={}
for label,cwd in [('retained',build),('clean-baseline',E/'clean-front-baseline'),('clean-nomemo',E/'clean-front-nomemo')]:
    graph=cwd/'.openmktr/build.ninja'
    active=set()
    with graph.open('rb') as reader:
        for line in reader:active.update(re.findall(rb'\.kati_runtime-([0-9]+)',line))
    contexts=collections.Counter()
    for name in active:
        p=context_path(cwd/'.openmktr'/('.kati_runtime-'+name.decode()))
        context=Path(p) if Path(p).is_absolute() else cwd/p
        contexts[context.stat().st_size]+=1
    result[label]=dict(active_runtime_recipes=len(active),contexts_by_file_bytes=dict(contexts),logical_context_bytes_if_each_executes_once=sum(size*count for size,count in contexts.items()),graph_bytes=graph.stat().st_size)

source_differences=[]
for path in sorted((repo/'src').glob('*')):
    frozen=P/'candidate-v17-source/src'/path.name
    if frozen.is_file() and path.is_file() and path.read_bytes().replace(b'\r\n',b'\n')!=frozen.read_bytes().replace(b'\r\n',b'\n'):
        source_differences.append(path.name)
result['working_source_differences_from_frozen_baseline']=source_differences
configs=[]
for label in ('baseline','nomemo'):
    cwd=E/('clean-front-'+label)
    config=(cwd/'config_host.mk').read_text().replace(str(cwd),'<BUILD>')
    configs.append(hashlib.sha256(config.encode()).hexdigest())
result['clean_normalized_config_sha256']=configs
result['clean_configurations_match']=len(set(configs))==1
result['retained_graph_sha256']=hashlib.sha256((build/'.openmktr/build.ninja').read_bytes()).hexdigest()
archive=Path('/root/universal-tool-campaign-20260927/sources/libreoffice-25.2.7.2.tar.xz')
command=['python3',str(repo/'validation/verify_release_archive.py'),str(archive),str(build.parent/'libreoffice-25.2.7.2')]
with (E/'source-integrity.log').open('w') as log:
    result['source_integrity_exit_code']=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
(E/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
