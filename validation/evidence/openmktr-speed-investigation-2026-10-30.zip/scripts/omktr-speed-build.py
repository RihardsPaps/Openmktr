from pathlib import Path
import difflib,hashlib,json,shlex,shutil,subprocess
E=Path('/root/openmktr-speed-20261030');P=Path('/root/libreoffice-improvements-20261029')
C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
D=C/'omktr-speed-no-memo'
shutil.copytree(P/'candidate-v17-source',D)
for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
    if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
(D/'out').mkdir(exist_ok=True)
for p in (C/'lo-improvements-candidate/out').glob('*'):
    if p.is_file():shutil.copy2(p,D/'out'/p.name)
for name in ('.ninja_log','.ninja_deps'):
    if (C/'lo-improvements-candidate'/name).exists():shutil.copy2(C/'lo-improvements-candidate'/name,D/name)
source=D/'src/incremental_eval.cc';before=source.read_text()
after=before.replace('enabled_(g_flags.generate_ninja && !g_flags.explain &&','enabled_(false && g_flags.generate_ninja && !g_flags.explain &&',1)
assert before!=after;source.write_text(after)
(E/'diagnostic-no-memo.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='src/incremental_eval.cc',tofile='src/incremental_eval.cc')))
with (E/'diagnostic-no-memo-build.log').open('w') as log:
    subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-no-memo && ninja -j32 omktr'],stdout=log,stderr=subprocess.STDOUT,check=True)
    commands=subprocess.check_output(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-no-memo && ninja -t commands omktr'],text=True).splitlines()
    link=shlex.split(commands[-1]);link=link[:link.index('-o')]+['-Wl,--dynamic-linker='+str(P/'runtime/libc.so'),'-Wl,-rpath,'+str(P/'runtime'),'-o','omktr-no-memo']
    subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-no-memo && '+shlex.join(link)],stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copy2(D/'omktr-no-memo',E/'omktr-no-memo')
(E/'diagnostic-no-memo-build.json').write_text(json.dumps(dict(link=link,binary_sha256=hashlib.sha256((E/'omktr-no-memo').read_bytes()).hexdigest(),diagnostic_only=True),indent=2))
print('diagnostic build complete',flush=True)
