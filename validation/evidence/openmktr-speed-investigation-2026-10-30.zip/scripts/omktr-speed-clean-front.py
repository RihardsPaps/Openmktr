exec(open('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-speed-investigate.py').read().split("if '--inner' not in sys.argv:")[0])
if '--inner' not in sys.argv:
    active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
    try:
        if active:subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
        subprocess.run(['unshare','--mount','--propagation','private',sys.executable,__file__,'--inner'],check=True)
    finally:
        if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
else:
    source=Path(run['environment_overrides']['SRCDIR'])
    subprocess.run(['mount','--bind',str(source),str(source)],check=True)
    subprocess.run(['mount','-o','remount,bind,ro',str(source)],check=True)
    env=dict(os.environ,**R['benchmark']['environment'])
    for key in list(env):
        if key.startswith(('KATI_','OMKTR_')) or key in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):env.pop(key)
    for name,binary in [('nomemo',str(E/'omktr-no-memo')),('baseline',run['command'][0])]:
        cwd=E/('clean-front-'+name);cwd.mkdir()
        execute('clean-front-'+name+'-configure',[str(source/'configure')]+R['benchmark']['configure_options'],env,cwd)
        args=list(R['benchmark']['runs']['aggressive-v17-bootstrap']['command']);args[0]=binary
        args=[('MAKE='+binary) if x.startswith('MAKE=') else x for x in args]
        execute('clean-front-'+name+'-bootstrap',args,env,cwd)
        genenv=dict(env,SRCDIR=str(source),BUILDDIR=str(cwd),WORKDIR=str(cwd/'workdir'))
        command=list(R['phase_profile']['command']);command[0]=binary
        command=[('MAKE='+binary) if x.startswith('MAKE=') else x for x in command]
        execute('clean-front-'+name+'-generate',command,genenv,cwd)
