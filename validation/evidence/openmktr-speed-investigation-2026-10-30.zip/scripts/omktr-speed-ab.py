exec(open('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-speed-investigate.py').read().split("if '--inner' not in sys.argv:")[0])
label=sys.argv[1]
if '--inner' not in sys.argv:
    active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
    try:
        if active: subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
        subprocess.run(['unshare','--mount','--propagation','private',sys.executable,__file__,label,'--inner'],check=True)
    finally:
        if active: subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
else:
    for name in ('upper','work','merged'): (E/(label+'-'+name)).mkdir(exist_ok=True)
    subprocess.run(['mount','-t','overlay','overlay','-o',f'lowerdir={build},upperdir={E}/{label}-upper,workdir={E}/{label}-work',str(E/(label+'-merged'))],check=True)
    subprocess.run(['mount','--bind',str(E/(label+'-merged')),str(build)],check=True)
    env=dict(os.environ,**R['benchmark']['environment'],**run['environment_overrides'])
    for key in list(env):
        if key.startswith(('KATI_','OMKTR_')) or key in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'): env.pop(key)
    cmd=list(R['phase_profile']['command'])
    if 'noeval' in label: cmd.insert(1,'--disable_graph_optimization=evaluation')
    if 'nomemo' in label: cmd[0]=str(E/'omktr-no-memo')
    if 'safe' in label: cmd=[x.replace('--graph_optimizations=aggressive','--graph_optimizations=safe') for x in cmd]
    execute(label,cmd,env,build)
    for repeat in range(2):execute(label+'-warm-'+str(repeat+1),cmd,env,build)
    execute(label+'-explain',[env['PATH'].split(':')[0]+'/ninja','-f','.openmktr/build.ninja','-j32','-n','-d','explain'],env,build)
