from pathlib import Path
import difflib,hashlib,json,subprocess
E=Path('/root/openmktr-speed-20261030');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
    if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
for name in ('bench-j32.json','bench-j32.stderr','bench-j32-status.json'):
    previous=E/name
    if previous.exists():previous.rename(E/('setup-failed-'+name))
before=(repo/'tests/bench.py').read_text()
after=before.replace('"-j4"','"-j32"').replace('for job_count in (1, 4):','for job_count in (32,):')
after=after.replace('[str(binary), "--ninja",','[str(binary), "--ninja", "-j32",')
after=after.replace('time.perf_counter()', 'time.clock_gettime(time.CLOCK_MONOTONIC_RAW)')
target=C/'omktr-speed-no-memo/bench-j32.py';target.write_text(after)
(E/'bench-j32.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='tests/bench.py',tofile='bench-j32.py')))
baseline=C/'lo-improvements-candidate/omktr';candidate=C/'omktr-speed-no-memo/omktr'
command=['chroot',str(C),'/bin/sh','-c','python /omktr-speed-no-memo/bench-j32.py /omktr-speed-no-memo/omktr --baseline /lo-improvements-candidate/omktr --repeats 3']
active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
try:
    if active:subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
    with (E/'bench-j32.json').open('w') as out,(E/'bench-j32.stderr').open('w') as err:
        r=subprocess.run(command,stdout=out,stderr=err)
finally:
    if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
(E/'bench-j32-status.json').write_text(json.dumps(dict(command=command,exit_code=r.returncode,baseline_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest()),indent=2))
raise SystemExit(r.returncode)
