from pathlib import Path
import collections,concurrent.futures,hashlib,json,os,statistics,struct,subprocess,time
E=Path('/root/openmktr-speed-20261030')
P=Path('/root/libreoffice-improvements-20261029')
B=P/'omktr-candidate17'
root=E/'runtime-fixture-v2';root.mkdir()
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
for k in list(env):
    if k.startswith(('KATI_','OMKTR_')) or k in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'): env.pop(k)

def parts(data):
    offset=0;result=[]
    while offset<len(data):
        length=struct.unpack_from('<Q',data,offset)[0];offset+=8
        assert offset+length<=len(data)
        result.append(data[offset:offset+length]);offset+=length
    return result

def pack(fields):return b''.join(struct.pack('<Q',len(x))+x for x in fields)
def read(path):return parts(path.read_bytes())[2]
def write(path,payload):
    h=14695981039346656037
    for c in payload:h=((h^c)*1099511628211)&((1<<64)-1)
    path.write_bytes(pack([b'OMKTR_GRAPH1',str(h).encode(),payload]))

(root/'seed').write_text('ready')
(root/'Makefile').write_text('OMKTR_PROFILE_MACRO = OMKTR_PROFILE_READER\nOMKTR_PROFILE_READER = $(shell cat seed)\nall: '+ ' '.join('out'+str(i) for i in range(256))+'\n'+''.join('out'+str(i)+': seed\n\t@printf %s "$(call $(OMKTR_PROFILE_MACRO))" > $@\n' for i in range(256)))
with (E/'runtime-generate.log').open('w') as log:
    subprocess.run([str(B),'--ninja','-j32','all'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sidecars=sorted(p for p in root.glob('.kati_runtime-*') if not p.name.startswith(('.kati_runtime-context-','.kati_runtime-reads-')))
assert len(sidecars)==256
real=sorted((P/'final-pair17-clock-controlled/aggressive-v17/build/.openmktr').glob('.kati_runtime-context-*'),key=lambda x:x.stat().st_size)[-1]
context=read(real); definitions=parts(context)
stats=collections.Counter()
for d in definitions:
    f=parts(d);stats[f[2].decode()]+=1
variants={k:[] for k in ('small','libreoffice')}
for p in sidecars:
    fields=parts(read(p));assert fields[0]==b'runtime-recipe-v5'
    # Keep fixture bindings as target-local overrides. Only the globals differ.
    fixture_globals=read(root/fields[7].decode())
    for name in variants:
        out=root/(name+'-'+p.name)
        copy=list(fields)
        if name=='libreoffice':
            copy[7]=str(real).encode();copy[8]+=fixture_globals
        write(out,pack(copy));variants[name].append(out)

results=dict(jobs=os.cpu_count(),context_bytes=len(context),context_sha256=hashlib.sha256(real.read_bytes()).hexdigest(),variables=len(definitions),flavors=dict(stats),samples={k:[] for k in variants})
def invoke(p,binary=B):
    out=subprocess.run([str(binary),'--internal-evaluate-recipe',str(p)],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    if out.returncode:raise RuntimeError(out.stderr.decode())
    return out.stderr.decode()
for iteration in range(4):
    for name in (('small','libreoffice') if iteration%2==0 else ('libreoffice','small')):
        before=os.times();t=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
        with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:list(workers.map(invoke,variants[name]))
        wall=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-t;after=os.times()
        assert all((root/('out'+str(i))).read_text()=='ready' for i in range(256))
        result=dict(wall_seconds=wall,cpu_seconds=after.children_user+after.children_system-before.children_user-before.children_system)
        results['samples'][name].append(result);print(iteration,name,result,flush=True)
        (E/'runtime-results.json').write_text(json.dumps(results,indent=2))
for name in variants:
    # Instrumentation is separate from the timed samples and also runs 32-way.
    with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:
        logs=list(workers.map(lambda p:invoke(p,P/'omktr-diagnostic-v17'),variants[name][:32]))
    (E/('runtime-'+name+'-diagnostic.json')).write_text(json.dumps(logs,indent=2))
