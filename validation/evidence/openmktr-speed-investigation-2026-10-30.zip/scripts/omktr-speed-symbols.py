from pathlib import Path
import subprocess,re,struct,collections,json
E=Path('/root/openmktr-speed-20261030')
P=Path('/root/libreoffice-improvements-20261029')
for label in ('generation','execution'):
    raw=subprocess.check_output(['perf','report','-i',str(E/(label+'.perf')),'--stdio','--no-children','--percent-limit','0','--sort','dso,symbol','-g','none'],text=True,stderr=subprocess.DEVNULL)
    (E/(label+'-perf-raw.txt')).write_text(raw)
    groups=collections.defaultdict(list)
    for line in raw.splitlines():
        m=re.match(r'\s*([\d.]+)%\s+(\S+)\s+\[.\]\s+0x([0-9a-f]+)',line)
        if m: groups[m[2]].append((float(m[1]),int(m[3],16)))
    totals=collections.Counter()
    for dso,rows in groups.items():
        binary=P/'omktr-candidate17' if dso.startswith('omktr-candidate') else P/'runtime'/dso
        if not binary.exists():
            totals[dso+' (unresolved)']+=sum(x[0] for x in rows);continue
        data=binary.read_bytes(); phoff=struct.unpack_from('<Q',data,32)[0]; entsize,count=struct.unpack_from('<HH',data,54)
        segments=[struct.unpack_from('<IIQQQQQQ',data,phoff+i*entsize) for i in range(count)]
        addresses=[]
        for weight,offset in rows:
            segment=next((s for s in segments if s[0]==1 and s[2]<=offset<s[2]+s[5]),None)
            addresses.append(offset+segment[3]-segment[2] if segment else offset)
        output=subprocess.check_output(['/usr/bin/llvm-symbolizer-18','--no-inlines','--obj='+str(binary)],input='\n'.join(hex(a) for a in addresses)+'\n',text=True)
        chunks=output.strip().split('\n\n')
        assert len(chunks)==len(rows),(dso,len(chunks),len(rows))
        for (weight,offset),chunk in zip(rows,chunks): totals[dso+': '+chunk.splitlines()[0]]+=weight
    result=totals.most_common()
    (E/(label+'-symbols.json')).write_text(json.dumps(result,indent=2))
    print(label,json.dumps(result[:25],indent=2))
