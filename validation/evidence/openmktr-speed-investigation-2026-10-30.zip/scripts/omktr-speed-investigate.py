from pathlib import Path
import hashlib, json, os, subprocess, sys, time

E = Path('/root/openmktr-speed-20261030')
OLD = Path('/root/libreoffice-improvements-20261029')
REPO = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
R = json.loads((REPO/'validation/libreoffice-improvements-results.json').read_text())
run = R['benchmark']['runs']['aggressive-v17-build']
build = Path(run['cwd'])
E.mkdir(exist_ok=True)

def execute(label, command, env, cwd):
    start = time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
    with (E/(label+'.log')).open('w') as log:
        p = subprocess.Popen(command, env=env, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
        _, status, usage = os.wait4(p.pid, 0)
    result = dict(command=command, cwd=str(cwd), exit_code=os.waitstatus_to_exitcode(status),
                  wall_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,
                  user_seconds=usage.ru_utime, system_seconds=usage.ru_stime,
                  maxrss_kib=usage.ru_maxrss)
    (E/(label+'.json')).write_text(json.dumps(result,indent=2))
    print(label, json.dumps(result), flush=True)
    if result['exit_code']: raise RuntimeError(label)

if '--inner' not in sys.argv:
    original_service = subprocess.check_output(['systemctl','is-active','systemd-timesyncd'],text=True).strip()
    metadata = dict(cpus=os.cpu_count(), meminfo=Path('/proc/meminfo').read_text(),
                    binary_sha256=hashlib.sha256(Path(run['command'][0]).read_bytes()).hexdigest(),
                    original_service=original_service, original_graph_sha256=hashlib.sha256((build/'.openmktr/build.ninja').read_bytes()).hexdigest())
    try:
        if original_service == 'active': subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
        subprocess.run(['unshare','--mount','--propagation','private',sys.executable,__file__,'--inner'],check=True)
    finally:
        if original_service == 'active': subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
        metadata['restored_service']=subprocess.check_output(['systemctl','is-active','systemd-timesyncd'],text=True).strip()
        metadata['final_original_graph_sha256']=hashlib.sha256((build/'.openmktr/build.ninja').read_bytes()).hexdigest()
        (E/'environment.json').write_text(json.dumps(metadata,indent=2))
else:
    for name in ('upper','work','merged'): (E/name).mkdir(exist_ok=True)
    subprocess.run(['mount','-t','overlay','overlay','-o',f'lowerdir={build},upperdir={E}/upper,workdir={E}/work',str(E/'merged')],check=True)
    subprocess.run(['mount','--bind',str(E/'merged'),str(build)],check=True)
    env=dict(os.environ,**R['benchmark']['environment'],**run['environment_overrides'])
    for key in list(env):
        if key.startswith(('KATI_','OMKTR_')) or key in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):
            env.pop(key)
    cmd=R['phase_profile']['command']
    execute('generation-perf', ['/usr/lib/linux-tools/6.18.54.1-microsoft-standard-WSL2/bin/perf','record','-e','cpu-clock','-F','99','--call-graph','dwarf,4096','--no-inherit','-o',str(E/'generation.perf'),'--']+cmd,env,build)
    execute('execution-perf', ['/usr/lib/linux-tools/6.18.54.1-microsoft-standard-WSL2/bin/perf','record','-e','cpu-clock','-F','49','--call-graph','dwarf,4096','-o',str(E/'execution.perf'),'--','sh','.openmktr/ninja.sh','-j32'],env,build)
    execute('generation-untraced',cmd,env,build)
    execute('execution-untraced',['sh','.openmktr/ninja.sh','-j32'],env,build)
