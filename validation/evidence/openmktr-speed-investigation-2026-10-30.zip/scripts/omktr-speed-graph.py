from pathlib import Path
import hashlib,json,os,subprocess,time
E=Path('/root/openmktr-speed-20261030')
build=Path('/root/libreoffice-improvements-20261029/final-pair17-clock-controlled/aggressive-v17/build')
source=build.parent/'libreoffice-25.2.7.2'
original=build/'.openmktr/build.ninja';compact=E/'compact-paths.ninja'
prefixes=[(str(build).encode()+b'/',b'${omktr_profile_build}/'),(str(source).encode()+b'/',b'${omktr_profile_source}/')]
counts=[0,0]
with original.open('rb') as reader,compact.open('wb') as writer:
    writer.write(b'omktr_profile_build = '+str(build).encode()+b'\nomktr_profile_source = '+str(source).encode()+b'\n')
    for line in reader:
        if line.startswith(b'build '):
            old=line
            for i,(prefix,variable) in enumerate(prefixes):counts[i]+=line.count(prefix);line=line.replace(prefix,variable)
            reconstructed=line
            for prefix,variable in prefixes:reconstructed=reconstructed.replace(variable,prefix)
            assert reconstructed==old
        writer.write(line)
results=dict(original_bytes=original.stat().st_size,compact_bytes=compact.stat().st_size,prefix_replacements=counts,identity_reconstruction_passed=True,queries={})
for label,graph in [('original',original),('compact',compact),('compact-repeat',compact),('original-repeat',original)]:
    cmd=['/root/omktr-graph-optimizations/ninja-1.13.2/ninja','-j32','-f',str(graph),'-t','targets','all']
    t=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
    with (E/(label+'-targets.txt')).open('wb') as out,(E/(label+'-targets.stderr')).open('wb') as err:
        p=subprocess.Popen(cmd,cwd=build,stdout=out,stderr=err)
        _,status,usage=os.wait4(p.pid,0)
    assert os.waitstatus_to_exitcode(status)==0
    results['queries'][label]=dict(wall_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-t,maxrss_kib=usage.ru_maxrss,sha256=hashlib.sha256((E/(label+'-targets.txt')).read_bytes()).hexdigest())
assert len({r['sha256'] for r in results['queries'].values()})==1
(E/'graph-compaction.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
