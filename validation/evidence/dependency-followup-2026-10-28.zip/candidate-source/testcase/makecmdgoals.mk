test:
	echo $(MAKECMDGOALS)
