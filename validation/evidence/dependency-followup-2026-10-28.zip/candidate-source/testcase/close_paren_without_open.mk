$(info }#)
test:
	echo OK
