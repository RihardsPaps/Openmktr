test:
	$(error foo)
