test:;echo foo\
bar
