foo=FAIL

$$:
	echo "$@"
