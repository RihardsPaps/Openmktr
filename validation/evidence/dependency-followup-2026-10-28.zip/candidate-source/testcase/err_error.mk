
$(error foo)

test:
