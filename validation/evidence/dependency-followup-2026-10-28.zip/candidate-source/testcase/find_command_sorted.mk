# TODO(ninja): This test is only for omktr. ninja: fix $(sort $(shell $(1)))
# ninja: $(sort $(shell "find .")) becomes "$( .) find"

define run_find
@echo $$ '$(strip $(1))'
@echo $(sort $(shell $(1)))
endef

test1:
	$(call run_find, find .)
