#!/bin/sh
# FORK MODIFICATION NOTICE (2026)
# Changed by the Openmktr fork, maintained by Rihards Paps and
# Haralds Paps. Adapted regression fixtures for fork behavior and GNU-free testing.
# Upstream material retains its Apache-2.0 terms. Fork modifications are
# covered by Mozilla Public License 2.0; see docs/LICENSING.md and NOTICE
# at the repository root. Original notices below remain applicable.

#
# Copyright 2015 Google Inc. All rights reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http:#www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -e

mk="$@"
build() {
  # Remove once regen works with different args
  rm -f build.ninja .kati_stamp ninja.sh
  ${mk} $@
  if [ -e ninja.sh ]; then ./ninja.sh -j1 $@; fi
}

cat <<EOF > Makefile
.PHONY: a b
b:
	echo \$@
a:
	echo \$@
EOF

echo "==="
build
echo "---"
build a
echo "---"
build b
echo "==="
