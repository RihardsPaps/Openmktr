ifdef a b
endif
