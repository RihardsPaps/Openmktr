@ := replaced

test:
	@echo "target=[$@]"
