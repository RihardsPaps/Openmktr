#!/bin/sh
# FORK MODIFICATION NOTICE (2026)
# Changed by the Openmktr fork, maintained by Rihards Paps and
# Haralds Paps. Adapted regression fixtures for fork behavior and GNU-free testing.
# Upstream material retains its Apache-2.0 terms. Fork modifications are
# covered by Mozilla Public License 2.0; see docs/LICENSING.md and NOTICE
# at the repository root. Original notices below remain applicable.

#
# Copyright 2018 Google Inc. All rights reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http:#www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -e
mk="$@"

cat <<EOF >Makefile
all: secondary_dep

secondary_dep: secondary
	@touch \$@
	@echo Made \$@

primary: .KATI_IMPLICIT_OUTPUTS := secondary
primary:
	@touch primary secondary
	@echo Made primary+secondary
EOF

${mk} -j1
./ninja.sh -j1 -w dupbuild=err
sleep 1
touch secondary
./ninja.sh -j1 -w dupbuild=err
sleep 1
echo Nothing to do
touch primary
./ninja.sh -j1 -w dupbuild=err
