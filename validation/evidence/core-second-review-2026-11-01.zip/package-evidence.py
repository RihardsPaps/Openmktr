#!/usr/bin/env python3
"""Package completed second-review evidence; never run during timed stages."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('/workspace/review2-evidence')
repo = Path('/workspace/Openmktr')
name = 'core-second-review-2026-11-01'
destination = repo / 'validation/evidence'

def read(name):
    return json.loads((root / name).read_text())

plan = read('performance-plan.json')
identities = read('identities.json')
assert plan['runtime_revision'] == identities['runtime_revision']
assert subprocess.check_output(['git', 'diff', plan['runtime_revision'], '--',
                               'src', 'tests', 'build.ninja', 'tools'], cwd=repo) == b''
normal = read('normal/gates.json')
sanitizers = read('sanitizers/sanitizers.json')
incremental = read('incremental/report.json')
assert len(normal) == 28 and all(r['exit_code'] == 0 for r in normal)
assert len(sanitizers) == 17 and all(r['exit_code'] == 0 for r in sanitizers)
assert len(incremental['runs']) == 27 and not incremental['errors']
assert not incremental['release_blocked'] and not incremental['performance_defects']
matrix = read('performance/paired/report.json')
assert matrix['failure'] is None
cells = []
for metric, key in [('wall', 'no_regression'), ('rss', 'memory')]:
    for c in matrix[key]:
        cells.append(dict(suite='paired-matrix', case=c['entrypoint'] + '/' + c['scenario'],
                          metric=metric, pairs=c['pairs'], median_ratio=c['median_ratio'],
                          interval=[1 - c['bootstrap_95_percent'][1] / 100,
                                    c['ratio_upper_95']], passed=c['parity_passed']))
for suite, path in [('clean', 'clean'), ('phases', 'phases'),
                    ('standard-paired', 'standard-paired')]:
    for c in read('performance/' + path + '/summary.json'):
        cells.append(dict(suite=suite, case=c.get('case', c.get('phase')),
                          **{k: c[k] for k in ('metric', 'pairs', 'median_ratio',
                                              'interval', 'passed')}))
assert len(cells) == 60
for c in cells:
    assert c['passed'] == (c['median_ratio'] <= 1 and c['interval'][1] <= 1.05)
    expected = 101
    if c['case'] in ('incremental_noop', 'direct_recipe_launch_j1'):
        expected = 301
    elif c['case'] in ('end_to_end_clean', 'end_to_end_graph_change',
                       'parallel_exec', 'nested_parallel_exec'):
        expected = 1001
    assert c['pairs'] == expected, c
measured = read('performance/binary-sha256.json')
assert measured['/workspace/omktr'] == identities['binaries']['/workspace/Openmktr/omktr']
assert measured['/baseline/omktr'] == identities['binaries']['/workspace/openmktr-baseline/omktr']
performance_passed = all(c['passed'] for c in cells)
assert all(r['exit_code'] == 0 for r in read('qualification.json') if r['name'] != 'performance')
assert read('performance-recovery-qualification.json')['exit_code'] == 0

# Include raw observations and logs, not rebuildable synthetic trees or binaries.
paths = [p for p in root.iterdir() if p.is_file() and p.name != 'before-omktr']
for directory in ('normal', 'sanitizers', 'attempt-68946f5', 'attempt-8070519'):
    paths.extend(p for p in (root / directory).rglob('*') if p.is_file())
for directory in ('incremental', 'performance'):
    for p in (root / directory).rglob('*'):
        if p.is_file() and not p.is_symlink() and p.suffix in ('.json', '.jsonl', '.log'):
            paths.append(p)
paths = sorted(set(paths))
manifest = {str(p.relative_to(root)): dict(bytes=p.stat().st_size,
            sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths}
archive = destination / (name + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in paths:
        z.write(p, str(p.relative_to(root)))
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path, row in manifest.items():
        assert hashlib.sha256(z.read(path)).hexdigest() == row['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n')
report = dict(schema=1, date='2026-11-01',
    generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    identities=identities, environment=read('environment.json'),
    review=read('reviews-final.json'), ci=read('ci-final.json'),
    source_review='review-ledger.md and source-review.patch inside the raw archive',
    portable=dict(passed=True, groups=normal, correctness_cases_per_profile=192,
                  architecture_tests=22, snapshots_per_profile=858, quarantined_crashes=0),
    sanitizers=dict(passed=True, groups=sanitizers,
                    leak_detection='session unit enabled; remaining groups disabled'),
    external_incremental=dict(scenarios=len(incremental['runs']),
        release_blocked=incremental['release_blocked'],
        performance_defects=incremental['performance_defects'], errors=incremental['errors']),
    performance=dict(plan=plan, recovery=read('performance-recovery-plan.json'),
                     passed=performance_passed, passed_cells=sum(c['passed'] for c in cells), cells=cells,
                     standard_benchmark_repeats=7, commands=read('performance/commands.json')),
    earlier_attempts=[dict(revision='68946f507155def3f4967281619e14a7b9a78b61',
        result='26/28 portable groups pass; two extra command echoes fail both snapshot profiles.',
        resolution='97b6788 preserves the prior static/runtime display distinction; snapshots unchanged.',
        path='attempt-68946f5'),
        dict(revision='8070519f46da4f7cd93320a374f1ac8b5185afb9',
             result='26/28 portable groups pass; suppressing all deferred command echoes fails three snapshots per profile.',
             resolution='97b6788 narrows suppression to groups newly deferred for freshness.',
             path='attempt-8070519'),
        dict(result='Development reproductions and rejected low-resolution input rounding retained.',
             note='Focused intermediate build logs do not qualify the final binary.'),
        dict(result='Initial main performance matrix stopped at saved-graph sample 58 with exhausted inodes.',
             path='performance/paired-inode-failure',
             resolution='Repeat the entire 30-cell matrix with identical sample counts and thresholds, retiring fixtures between entry points. Completed clean gate retained.')],
    archive=dict(path=archive.name, sha256=digest, bytes=archive.stat().st_size,
                 entries=len(manifest) + 1),
    limits=['Synthetic cloud results compare this runtime with original baseline 77a397f, not GNU Make.',
            'Real PC release qualification for Linux 7.3, FFmpeg 9.0.2 and LibreOffice 26.8.2.2 remains unrun.',
            'Peak RSS is per-process high water, not aggregate process-tree memory; the parent/exec floor can mask small workloads.',
            'Finite tests and code review do not establish absolute optimality or universal absence of regressions.'])
(destination / (name + '.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(archive=report['archive'], cells=len(cells),
                      performance_passed=performance_passed), indent=2))
