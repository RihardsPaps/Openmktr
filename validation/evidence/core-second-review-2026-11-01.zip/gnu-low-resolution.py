import ast,json,os,subprocess,tempfile
from pathlib import Path
module=ast.parse(Path('/workspace/tests/architecture.py').read_text())
method=next(n for n in ast.walk(module) if isinstance(n,ast.FunctionDef) and n.name=='test_low_resolution_freshness_and_newer_inputs')
cases=ast.literal_eval(next(n.value for n in method.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets)))
rows=[]
for i,(listed,inputs,high,low,output,expected) in enumerate(cases):
 for colon in (':','::'):
  for jobs in (1,4):
   with tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    (d/'Makefile').write_text(f".LOW_RESOLUTION_TIME: {listed}\n.PHONY: force\nforce:\nall: output\noutput{colon} {inputs}\n\t@printf '%s' '$?' > $@\n")
    base=1700000000000000000
    for name,offset in [('high',high),('low',low),('output',output)]:
     (d/name).write_text('old');os.utime(d/name,ns=(base+offset,base+offset))
    r=subprocess.run(['gmake','-j'+str(jobs),'all'],cwd=d,capture_output=True,timeout=10)
    actual=(d/'output').read_text()
    rows.append(dict(case=i,colon=colon,jobs=jobs,expected=expected,actual=actual,passed=r.returncode==0 and actual==expected,stderr=r.stderr.decode()))
Path('/evidence/gnu-low-resolution.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(total=len(rows),failed=[r for r in rows if not r['passed']]),indent=2))
raise SystemExit(any(not r['passed'] for r in rows))
