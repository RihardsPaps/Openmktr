import json,os,subprocess,tempfile
from pathlib import Path
rows=[]
tools=['gmake'] if os.environ.get('ONLY_GNU') else ['/baseline/omktr','/workspace/omktr']
for tool in tools:
 for case,prereqs,colon in [('mixed-high-first','high low',':'),('mixed-low-first','low high',':'),('low-only','low',':'),('double-low-only','low','::')]:
  for mode in (['direct'] if tool=='gmake' else ['direct','build','legacy']):
   for jobs in (1,4):
    with tempfile.TemporaryDirectory(prefix='omktr-review-freshness-') as temp:
     d=Path(temp)
     (d/'Makefile').write_text('.LOW_RESOLUTION_TIME: low\nall: output\noutput'+colon+' '+prereqs+'\n\t@printf rebuilt > output\n')
     for name in ('high','low','output'):(d/name).write_text('old')
     base=1_700_000_000_000_000_000
     for name,delta in [('high',600_000_000),('low',900_000_000),('output',400_000_000)]:os.utime(d/name,ns=(base+delta,base+delta))
     if mode=='legacy':
      gen=subprocess.run([tool,'--ninja','all'],cwd=d,capture_output=True,timeout=10);assert gen.returncode==0,gen.stderr
     cmd=([tool,'build'] if mode=='build' else ['sh','ninja.sh'] if mode=='legacy' else [tool])+['-j'+str(jobs),'all']
     r=subprocess.run(cmd,cwd=d,capture_output=True,timeout=10)
     rows.append(dict(tool=tool,case=case,mode=mode,jobs=jobs,status=r.returncode,output=(d/'output').read_text(),stderr=r.stderr.decode(errors='replace')))
 for jobs in (1,4):
  with tempfile.TemporaryDirectory(prefix='omktr-review-dryrun-') as temp:
   d=Path(temp);(d/'Makefile').write_text('all: output\noutput:\n\t-+@printf partial > output; kill -TERM $$$$\n')
   r=subprocess.run([tool,'-n','-j'+str(jobs),'all'],cwd=d,capture_output=True,timeout=10)
   rows.append(dict(tool=tool,case='forced-dryrun-signal',jobs=jobs,status=r.returncode,output=(d/'output').read_text() if (d/'output').exists() else None,stderr=r.stderr.decode(errors='replace')))
print(json.dumps(rows,indent=2))
