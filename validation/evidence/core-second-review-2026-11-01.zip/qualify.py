import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/workspace/review2-evidence');rows=[]
def run(name,cmd):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start))
 (root/'qualification.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('normal',['docker','exec','--user','1000:1000','openmktr-review2','python','/evidence/normal-gates.py'])
run('sanitizers',['docker','exec','--user','1000:1000','openmktr-review2','python','/evidence/sanitizer-gates.py'])
run('incremental',['docker','run','--rm','--network','none','--user','1000:1000','--entrypoint','python','-v','/workspace/Openmktr:/workspace','-v','/workspace/review2-evidence:/evidence','-w','/workspace','openmktr-external:latest','validation/incremental.py','--make','gmake','--omktr','/workspace/omktr','--output','/evidence/incremental'])
run('performance',['docker','exec','--user','1000:1000','openmktr-review2','python','/evidence/performance-gates.py'])
