import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
root=Path('/evidence/performance')
plan=json.loads(Path('/evidence/performance-plan.json').read_text())
os.sched_setaffinity(0,{0,1,2,3})
(root/'cpu-affinity.json').write_text(json.dumps(sorted(os.sched_getaffinity(0)))+'\n')
(root/'binary-sha256.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('/baseline/omktr'),Path('/workspace/omktr')]},indent=2)+'\n')
rows=[]
def run(name,cmd):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start))
 (root/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if r.returncode not in (0,3):raise SystemExit(r.returncode)
run('clean',['python','/evidence/clean-gate.py'])
# Every sample asserts the expected output contents. Completed fixtures can be
# reconstructed from these retained scripts; remove them outside timed stages.
retired=[]
for repeat in (root/'clean/end_to_end_clean').iterdir():
 if not repeat.name.isdecimal() or int(repeat.name)<3:continue
 for d in repeat.iterdir():
  assert d.name in ('b','c') and 'out31: src31 config.mk' in (d/'Makefile').read_text()
  assert not list(d.glob('*.log'))
  retired.append(str(d.relative_to(root)));shutil.rmtree(d)
 repeat.rmdir()
(root/'retired-clean.json').write_text(json.dumps(retired,indent=2)+'\n')
run('paired-matrix',['python','validation/benchmark_ninja.py','--project','synthetic','--root',str(root/'paired'),'--baseline','/baseline/omktr','--baseline-revision',plan['baseline_revision'],'--candidate','/workspace/omktr','--candidate-revision',plan['runtime_revision'],'--entrypoints','direct','build','legacy','--jobs','4','--samples','101','--warmups','2','--require-no-regression'])
retired=[]
for d in (root/'paired').iterdir():
 if not d.is_dir() or not re.fullmatch(r'(direct|build|legacy)-j4-r\d+-(baseline|candidate)',d.name):continue
 assert 'out511.o: src511 config.mk' in (d/'Makefile').read_text()
 logs=[]
 for log in d.glob('*.log'):
  destination=root/'fixture-logs'/d.name/log.name;destination.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(log,destination);checksum=hashlib.sha256(log.read_bytes()).hexdigest()
  assert checksum==hashlib.sha256(destination.read_bytes()).hexdigest()
  logs.append(dict(path=str(destination.relative_to(root)),sha256=checksum))
 retired.append(dict(tree=d.name,logs=logs));shutil.rmtree(d)
(root/'retired-paired.json').write_text(json.dumps(retired,indent=2)+'\n')
run('phases',['python','/evidence/phases.py','performance/phases'])
run('phase-analysis',['python','/evidence/analyze-phases.py',str(root/'phases')])
run('standard',['python','tests/bench.py','/workspace/omktr','--baseline','/baseline/omktr','--repeats','7'])
run('paired-standard',['python','/evidence/paired-standard.py'])
