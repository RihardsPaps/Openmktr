import json,os,subprocess,tempfile
from pathlib import Path
rows=[]
for tool in ('/baseline/omktr','/workspace/omktr'):
 for closed in ((),(0,),(1,),(0,1),(0,1,2)):
  with tempfile.TemporaryDirectory(prefix='omktr-closed-parent-') as temp:
   d=Path(temp)
   (d/'Makefile').write_text('VALUE := $(shell printf expected)\n$(file >result,$(VALUE))\n.PHONY: all\nall:\n')
   def close_descriptors():
    for fd in closed:
     os.close(fd)
   r=subprocess.run([tool,'-j1','all'],cwd=d,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=close_descriptors,timeout=10)
   rows.append(dict(tool=tool,closed=closed,status=r.returncode,result=(d/'result').read_text() if (d/'result').exists() else None,stderr=r.stderr.decode(errors='replace')))
print(json.dumps(rows,indent=2))
