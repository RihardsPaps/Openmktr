import json,os,subprocess,tempfile
from pathlib import Path
rows=[]
for tool in ['/evidence/before-omktr','/workspace/omktr']:
 with tempfile.TemporaryDirectory() as temp:
  d=Path(temp);(d/'Makefile').write_text('all:\n\t@touch result\n');(d/'.openmktr').mkdir();os.mkfifo(d/'.openmktr/build.ninja')
  try:
   r=subprocess.run([tool,'build','all'],cwd=d,capture_output=True,timeout=2)
   rows.append(dict(tool=tool,timeout=False,status=r.returncode,stderr=r.stderr.decode()))
  except subprocess.TimeoutExpired:rows.append(dict(tool=tool,timeout=True))
Path('/evidence/nonregular-graph-before.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
