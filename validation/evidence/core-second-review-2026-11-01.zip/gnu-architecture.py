import importlib,subprocess,sys,shutil,unittest
from pathlib import Path
sys.path.insert(0,'/workspace/tests')
module=importlib.import_module('architecture')
module.BINARY=Path(shutil.which('gmake'))
original=subprocess.run
def run(command,*args,**kwargs):
 if command[0]==str(module.BINARY):
  if '--ninja' in command:return subprocess.CompletedProcess(command,0,stdout='',stderr='')
  command=[x for x in command if x!='build']
 elif command[:2]==['sh','ninja.sh']:
  command=[str(module.BINARY),*command[2:]]
 return original(command,*args,**kwargs)
subprocess.run=run
names=['test_low_resolution_freshness_and_newer_inputs','test_low_resolution_double_colon_groups_keep_independent_freshness','test_unconditional_double_colon_runs_beside_current_and_order_only_groups','test_double_colon_automatic_inputs_keep_vpath_providers','test_runtime_groups_keep_recipe_less_vpath_aliases','test_runtime_groups_keep_lexical_phony_and_logical_metadata']
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(module.Architecture(name) for name in names))
raise SystemExit(not result.wasSuccessful())
