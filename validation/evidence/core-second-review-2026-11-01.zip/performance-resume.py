import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path

root=Path('/evidence/performance')
plan=json.loads(Path('/evidence/performance-plan.json').read_text())
os.sched_setaffinity(0,{0,1,2,3})
expected=json.loads((root/'binary-sha256.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in expected.items())
rows=json.loads((root/'commands.json').read_text())

def run(name,cmd):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start))
 (root/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if r.returncode not in (0,3):raise SystemExit(r.returncode)

assert not (root/'paired').exists()
(root/'paired').mkdir()
reports=[]
for entry in ('direct','build','legacy'):
 directory=root/'paired'/entry
 run('paired-'+entry,['python','validation/benchmark_ninja.py','--project','synthetic',
     '--root',str(directory),'--baseline','/baseline/omktr',
     '--baseline-revision',plan['baseline_revision'],'--candidate','/workspace/omktr',
     '--candidate-revision',plan['runtime_revision'],'--entrypoints',entry,
     '--jobs','4','--samples','101','--warmups','2','--require-no-regression'])
 report=json.loads((directory/'report.json').read_text());assert report['failure'] is None
 reports.append(report)
 # Only rebuildable completed fixtures are retired, outside measured stages.
 # Command logs remain at their original paths; no samples or reports removed.
 retired=[]
 for d in directory.iterdir():
  if not d.is_dir() or not re.fullmatch(entry+r'-j4-r\d+-(baseline|candidate)',d.name):continue
  assert 'out511.o: src511 config.mk' in (d/'Makefile').read_text()
  for p in d.iterdir():
   if p.name=='Makefile' or p.suffix=='.log':continue
   if p.is_dir() and not p.is_symlink():shutil.rmtree(p)
   else:p.unlink()
  retired.append(d.name)
 (directory/'retired-fixtures.json').write_text(json.dumps(retired,indent=2)+'\n')

combined=dict(metadata=[r['metadata'] for r in reports],failure=None,
              no_regression_passed=all(r['no_regression_passed'] for r in reports),
              recovery='Fresh full matrix after inode exhaustion; fixtures retired between entry points.')
for key in ('summary','no_regression','memory'):
 combined[key]=[cell for report in reports for cell in report[key]]
assert len(combined['no_regression'])==15 and len(combined['memory'])==15
(root/'paired/report.json').write_text(json.dumps(combined,indent=2)+'\n')
run('phases',['python','/evidence/phases.py','performance/phases'])
run('phase-analysis',['python','/evidence/analyze-phases.py',str(root/'phases')])
run('standard',['python','tests/bench.py','/workspace/omktr','--baseline','/baseline/omktr','--repeats','7'])
run('paired-standard',['python','/evidence/paired-standard.py'])
