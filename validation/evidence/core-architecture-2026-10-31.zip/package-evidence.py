import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path('/workspace/architecture-evidence')
REPO = Path('/workspace/Openmktr')
DEST = REPO / 'validation/evidence'
NAME = 'core-architecture-2026-10-31'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

paired = read(ROOT / 'paired/report.json')
normal = read(ROOT / 'final-normal/gates.json')
sanitizers = read(ROOT / 'final-sanitizers/sanitizers.json')
incremental = read(ROOT / 'incremental-final/report.json')
assert all(row['exit_code'] == 0 for row in normal + sanitizers)
assert paired['failure'] is None and not paired['source_changes']

report = dict(
    schema=1, date='2026-10-31',
    scope='Completed core architecture; real PC release qualification remains unrun',
    baseline_revision='77a397ffd7a1cc5f48e406f8cf9052a50cc0d150',
    runtime_revision='62a7200a3e9cca138e5cbd157dbb17e665f92bdf',
    full_gate_revision='7fdb57300075271160b82de3c11bb03091fbd87b',
    environment_object_fix_revision='82e76839651286b28823722405bd1644aa3ee64b',
    cancellation_fixture_revision='e2869be28a71453f4ded41ec560ba92524dfeb26',
    benchmark_fixture_revision='b8422a257b00e8c2a1c4a7eaa79187442443329f',
    sealed_fault_injection_fixture_revision='967903f7a579959b2d63035fd99d799604ec3311',
    toolchain_image='sha256:6cfc9578e451296d6d699dff8d6cc9bbbd18cd05906e6a3d7defe679d94aabc2',
    toolchain_lock_sha256=sha(REPO / 'tools/chimera-packages.lock'),
    candidate_binary_sha256=sha(REPO / 'omktr'),
    sanitizer_binary_sha256=sha(REPO / 'omktr-sanitized'),
    portable_gate=normal, sanitizer_gate=sanitizers,
    final_runtime_rechecks=dict(
        normal=dict(logs=['final-runtime-normal.log', 'final-runtime-normal-corrected.log'], user='1000:1000',
            suites={'session_unit': 1, 'architecture': 10, 'graph_optimizations': 58, 'generated_recipe_reads': 45, 'correctness': 187},
            note='Session, architecture and graph suites pass in the first log; permission failures in its later corruption fixtures are superseded by the corrected runtime/correctness recheck.'),
        sanitizers=dict(log='final-runtime-sanitizers.log', suites={'session_unit_with_leaks': 1, 'architecture': 10, 'graph_optimizations': 58, 'generated_recipe_reads': 45, 'correctness': 187}),
        description='Final runtime rechecks supplement the full portable and sanitizer gates; final PR CI independently rebuilds the head.'),
    snapshots=dict(safe='858/858', aggressive='858/858',
        normalization='Canonicalize only the unordered three-word root-directory listing in find_command.mk:test2; changed newer-input expectation is independently checked with external GNU Make.'),
    external_incremental=incremental,
    benchmark_environment=paired['metadata'],
    synthetic_paired_timing=paired['summary'],
    synthetic_paired_memory=paired['memory'],
    phase_and_launch_benchmark=read(ROOT / 'bench.json'),
    preceding_measurements=dict(runtime_revision='82e76839651286b28823722405bd1644aa3ee64b',
        phase_report='bench-before-batching.json', paired_report='paired-before-batching/report.json',
        reason='Per-object durability barriers regressed generated-build timings; replaced with bounded write batches before publication. Original results retained.'),
    intermediate_batch_measurements=dict(runtime_revision='6ef9b6086306de60b371fda88cce38bfd6cee4b8',
        phase_report='bench-batching-without-seals.json', paired_report='paired-batching-without-seals/report.json',
        reason='Batching reduced fresh-generation overhead but repeatedly synced existing objects; a durable owner-read-only seal avoids these repeated barriers.'),
    retained_failures=[
        dict(log='bench-initial-failure.log', resolution='Timestamp barrier now observes known workload outputs instead of optional cache aliases.'),
        dict(log='environment-fix-sanitizers.log', resolution='Cancellation fixture now orders its failure after an explicit startup prerequisite; normal and sanitizer rechecks pass.'),
        dict(logs=['sealed-normal.log', 'sealed-sanitizers.log'], resolution='Seal immutable object metadata before recording regeneration identities; this preserves recursive-import no-op behavior.'),
        dict(logs=['final-runtime-normal.log', 'final-runtime-normal-recheck.log'], resolution='Unprivileged corruption fixtures explicitly make sealed objects writable before fault injection; corrected syntax and all 45 runtime / 187 correctness cases pass in final-runtime-normal-corrected.log.'),
        dict(log='leak-checks.log', resolution='Optional find-unit LeakSanitizer tracer failure. Isolated retry passed in leak-check-retry.log; whole-program leak detection is not claimed.')],
    boundaries=[
        'Cloud synthetic timings do not establish real-project performance or memory parity.',
        'ASan/UBSan integration gates use detect_leaks=0; session lifetime tests use detect_leaks=1.',
        'Memory samples measure wait4 peak individual-process RSS, not aggregate concurrent tree RSS.',
        'Shared immutable objects and recursive imports are retained for saved/raw Ninja graphs; only generation bundles are collected automatically.',
        'Persistent resolution caches pure implicit-chain feasibility, not a mutable evaluator or complete resolved graphs.',
        'No third-party release sources were patched and no NAS was accessed.'],
    pc_qualification=dict(executed=False, release_qualified=False,
        projects=['Linux 7.3', 'FFmpeg 9.0.2', 'LibreOffice 26.8.2.2'],
        entrypoints=['direct', 'build'], example_jobs=[8, 16],
        warmup_pairs=2, measured_pairs=7,
        scenarios=['clean', 'noop', 'source', 'missing', 'graph'],
        driver='validation/qualify_core.py', config='validation/core-qualification.example.json',
        generated_plan='pc-matrix.json',
        gate='Every timing and memory cell: median ratio <= 1.00 and bootstrap 95% upper ratio <= 1.05, complete correctness/artifact/source checks.'))

files = {}
for path in ROOT.iterdir():
    if path.is_file() and path.suffix in ('.log', '.json', '.py'):
        files[path.name] = path
for folder in ('final-normal', 'final-sanitizers', 'incremental-final', 'paired', 'paired-before-batching', 'paired-batching-without-seals'):
    for directory, _, names in os.walk(ROOT / folder):
        for name in names:
            path = Path(directory) / name
            if path.suffix in ('.log', '.json', '.jsonl') and not path.is_symlink():
                files[str(path.relative_to(ROOT))] = path
archive = DEST / (NAME + '.zip')
manifest = {}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        output.writestr(name, data)
        manifest[name] = hashlib.sha256(data).hexdigest()
    data = (json.dumps(report, indent=2) + '\n').encode()
    output.writestr('REPORT.json', data)
    manifest['REPORT.json'] = hashlib.sha256(data).hexdigest()
    output.writestr('SHA256SUMS', ''.join(value + '  ' + name + '\n' for name, value in sorted(manifest.items())))
report['archive'] = dict(path=archive.name, sha256=sha(archive), entries=len(manifest))
(DEST / (NAME + '.json')).write_text(json.dumps(report, indent=2) + '\n')
(DEST / (NAME + '.zip.sha256')).write_text(sha(archive) + '  ' + archive.name + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, checksum in manifest.items():
        assert hashlib.sha256(check.read(name)).hexdigest() == checksum
print(json.dumps(report['archive']))
