from pathlib import Path

source = Path('/benchmark.py').read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace('release.extractall(root / "sources", filter="data")',
        'pass  # Reuse audited release sources; never patch their contents.')
replace('source = root / "sources" / version',
        'source = Path("/reports/pr74-linux-final/sources") / version')
replace('build = root / (f"{entrypoint}-j{jobs}-retained-{variant}" if args.retained',
        'build = Path("/reports/pr74-linux-final") / (f"{entrypoint}-j{jobs}-retained-{variant}" if args.retained')
replace('logs = build / ".benchmark-logs" / str(sample) if args.retained else build',
        'logs = root / variant / str(sample) if args.retained else build')
replace('build_state="retained incremental only" if args.retained else "fresh clean per pair",',
        'build_state="retained incremental retry from verified Linux clean trees",\n'
        '                    build_tree_provenance=dict(report="/reports/pr74-linux-final/report.json",\n'
        '                                               clean_candidate_revision="3d97db3dbd9f25656d5466731cd2801989bbf3d7",\n'
        '                                               clean_builds_are_not_retimed=True),')
Path('/benchmark-retained-retry.py').write_text(source)
driver = Path('/run-linux-final.py').read_text()
driver = driver.replace("'/benchmark.py'", "'/benchmark-retained-retry.py'")
driver = driver.replace("'/reports/pr74-linux-final'", "'/reports/pr74-linux-retained-v2'")
driver = driver.replace('3d97db3dbd9f25656d5466731cd2801989bbf3d7',
                        '69bc79909134f5bbfba2144284875966f354a2be')
Path('/run-linux-retained-retry.py').write_text(driver)
