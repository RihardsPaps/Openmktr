import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/reports/pr74-linux-final')
metadata = json.loads((root / 'metadata.json').read_text())
env = dict(metadata['environment'], HOME='/root', USER='benchmark', LOGNAME='benchmark', SHELL='/bin/sh')
build = root / 'build-j8-retained-candidate'
source = root / 'sources/linux-6.12/init/main.c'
stamp = source.stat()
command = ['/final-omktr', 'build', '-j8', '-f', str(source.parents[1] / 'Makefile'),
           'LLVM=1', 'LLVM_IAS=1', 'ARCH=x86', 'all', '--kati_stats', *metadata['candidate_options']]
try:
    for label in (('prime', 'source', 'missing', 'graph', 'noop') if len(sys.argv) > 2
                  else ('prime', 'source', 'noop')):
        if label == 'source':
            os.utime(source, None)
        elif label == 'missing':
            (build / 'init/main.o').unlink()
        elif label == 'graph':
            os.utime(build / 'Makefile', None)
        with (root / ((sys.argv[1] if len(sys.argv) > 1 else 'diagnostic') + '-' + label + '.log')).open('wb') as output:
            subprocess.run(command, cwd=build, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
finally:
    os.utime(source, ns=(stamp.st_atime_ns, stamp.st_mtime_ns))
