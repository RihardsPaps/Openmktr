import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

root = Path('/reports/pr74-linux-final')
report = json.loads(Path('/reports/pr74-linux-retained-v4/report.json').read_text())
assert report['failure'] is None
metadata = report['metadata']
build = root / 'build-j8-retained-candidate'
header = root / 'sources/linux-6.12/init/do_mounts.h'
expected = []
for path in build.rglob('.*.cmd'):
    content = path.read_text()
    if str(header) in content:
        owner = re.search(r'^source_(.+?)\s*:=', content, re.M)
        if owner:
            expected.append(owner.group(1))
assert expected
def objects():
    return {str(p.relative_to(build)): (p.stat().st_mtime_ns, p.stat().st_size)
            for p in build.rglob('*.o')}
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
artifacts = {p: digest(build / p) for p in ('vmlinux', 'arch/x86/boot/bzImage')}
before = objects()
stamp = header.stat()
env = dict(metadata['environment'], HOME='/root', USER='benchmark', LOGNAME='benchmark', SHELL='/bin/sh')
command = ['/final-omktr', 'build', '-j8', '-f', str(root / 'sources/linux-6.12/Makefile'),
           'LLVM=1', 'LLVM_IAS=1', 'ARCH=x86', 'all', '--kati_stats',
           *metadata['candidate_options']]
start = time.monotonic()
try:
    os.utime(header, None)
    with (root / 'header-touch.log').open('wb') as output:
        subprocess.run(command, cwd=build, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
finally:
    os.utime(header, ns=(stamp.st_atime_ns, stamp.st_mtime_ns))
after = objects()
changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
assert set(expected) <= set(changed), (expected, changed)
assert 'kernel/fork.o' not in changed, changed
assert artifacts == {p: digest(build / p) for p in artifacts}
result = dict(command=command, seconds=time.monotonic()-start, header=str(header),
              expected_owners=sorted(expected), changed_objects=changed,
              unrelated_unchanged='kernel/fork.o', artifacts_unchanged=artifacts)
(root / 'header-touch.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
