import hashlib
import json
from pathlib import Path
import zipfile

paths = {}
for name in ('pr74-ffmpeg', 'pr74-linux', 'pr74-linux-clang22', 'pr74-linux-final',
             'pr74-linux-retained-v2', 'pr74-linux-retained-v3', 'pr74-linux-retained-v4'):
    root = Path('/reports') / name
    for p in sorted(root.glob('*')):
        if p.is_file() and p.suffix in ('.json', '.jsonl', '.log', '.txt'):
            paths[name + '/' + p.name] = p
    for p in sorted(root.glob('build-*/.benchmark-logs/*/*')):
        if p.is_file():
            paths[name + '/' + str(p.relative_to(root))] = p
for p in Path('/evidence-local').rglob('*'):
    if p.is_file():
        paths['local/' + str(p.relative_to('/evidence-local'))] = p
for name in ('benchmark.py', 'benchmark-retained-retry.py', 'prepare-linux-retry.py',
             'run-linux-final.py', 'run-linux-retained-retry.py', 'run-linux-retained-v3.py',
             'run-linux-retained-v4.py', 'probe-linux-validation.py', 'inspect-linux-tree.py',
             'check-linux-header.py'):
    p = Path('/') / name
    paths['controllers/' + name] = p
paths['toolchain/manifest.json'] = Path('/opt/pr74-toolchain/manifest.json')
paths['toolchain/reproducible-date'] = Path('/opt/pr74-toolchain/bin/date')
manifest = {}
destination = Path('/pr74-followup-evidence.zip')
with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(paths.items()):
        data = path.read_bytes()
        manifest[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(archive=str(destination), bytes=destination.stat().st_size,
                     sha256=hashlib.file_digest(destination.open('rb'), 'sha256').hexdigest(),
                     entries=len(manifest)), indent=2))
