import hashlib
import json
from pathlib import Path

def load(path):
    return json.loads(Path(path).read_text())

def summary(name):
    report = load('/reports/' + name + '/report.json')
    return {key: report.get(key) for key in ('metadata', 'failure', 'source_changes',
             'summary', 'memory', 'no_regression_passed', 'parity_passed')}

def clean_setup(name):
    rows = [json.loads(line) for line in Path('/reports/' + name + '/commands.jsonl').read_text().splitlines()]
    return [row for row in rows if row['log'].endswith('setup-clean.log')]

archive = Path('/pr74-followup-evidence.zip')
result = dict(
    date='2026-11-06', pull_request='https://github.com/RihardsPaps/Openmktr/pull/74',
    baseline_revision='e466d484059e29f641142acd0fbcf81376b2ecc1',
    final_code_revision='a5e84b1b59648e1392904bbbbc9044dfdeea1323',
    location='User PC, Docker Desktop local containers and local volumes; no NAS',
    core_toolchain='Chimera Clang 22.1.8, musl, libc++, Ninja 1.13.2; matching baseline/candidate flags',
    release_sources_patched=False,
    ffmpeg=summary('pr74-ffmpeg'), linux=summary('pr74-linux-retained-v4'),
    diagnostic_clean_setup=dict(ffmpeg=clean_setup('pr74-ffmpeg'), linux=clean_setup('pr74-linux-final')),
    linux_header=load('/reports/pr74-linux-final/header-touch.json'),
    tests=dict(graph_normal=89, graph_asan_ubsan=89, correctness_safe=210,
               correctness_aggressive=210, snapshots_safe=860, snapshots_aggressive=860,
               new_crash_quarantines=0, changed_snapshots=0,
               cpp_shared_index_round_trip_and_scope='passed normally and under ASan/UBSan',
               portable_complete_gate='passed during implementation; final code reran both correctness and snapshot profiles',
               complete_sanitizer_suite='passed during implementation; final code reran expanded graph and C++ index checks',
               gentoo='full local compatibility script passed at 3d97db3; final CI status linked on PR'),
    codex_review=dict(final_code='a5e84b1', final_has_findings=False,
                      actionable_findings_fixed=5, resolved_threads=5),
    retained_attempts={name: summary(name) for name in ('pr74-linux', 'pr74-linux-clang22',
                       'pr74-linux-final', 'pr74-linux-retained-v2', 'pr74-linux-retained-v3')},
    qualification=dict(default_profile='safe', promote_aggressive=False,
                       ffmpeg_clean='single diagnostic setup pair, not repeated clean qualification',
                       linux_clean='verified earlier baseline/3d97db3 clean artifacts, reused for retained retry; not final-code clean timing',
                       linux_retained='two warmups, seven alternating measured pairs with exact current binary identity',
                       synthetic='15-repeat tests/bench.py comparison at a072b23; raw samples in archive',
                       limits=['FFmpeg strict combined gate fails its missing-object RSS median criterion.',
                               'Linux conservative missing-object ownership refresh remains costly; use reported timing intervals.',
                               'Measurements apply only to recorded versions, profile, configuration and toolchain.']),
    evidence=dict(path='validation/evidence/pr74-followup-2026-11-06.zip',
                  sha256=hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
                  bytes=archive.stat().st_size, per_entry_manifest='manifest.json'))
Path('/pr73-followup-results.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: [dict(scenario=x['scenario'], baseline=x['baseline_median_seconds'],
                           candidate=x['candidate_median_seconds'], improvement=x['median_improvement_percent'],
                           interval=x['bootstrap_95_percent']) for x in result[key]['summary']]
                  for key in ('ffmpeg','linux')}, indent=2))
