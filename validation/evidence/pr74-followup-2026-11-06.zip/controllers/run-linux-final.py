# SPDX-License-Identifier: MPL-2.0
import subprocess
import sys

options = [
    '--graph_optimizations=aggressive', '--use_ninja_phony_output',
    'KCFLAGS=-Wno-error=default-const-init-var-unsafe -Wno-error=default-const-init-field-unsafe -Wno-error=unterminated-string-initialization',
    'KBUILD_BUILD_TIMESTAMP=2024-11-18T00:00:00Z',
]
command = [sys.executable, '/benchmark.py', '--root', '/reports/pr74-linux-final',
           '--archives', '/previous/input', '--baseline', '/baseline-omktr',
           '--candidate', '/final-omktr', '--baseline-revision',
           'e466d484059e29f641142acd0fbcf81376b2ecc1', '--candidate-revision',
           '3d97db3dbd9f25656d5466731cd2801989bbf3d7', '--project', 'linux',
           '--entrypoints', 'build', '--jobs', '8', '--samples', '7',
           '--warmups', '2', '--retained', '--toolchain-dir', '/opt/pr74-toolchain/bin']
for variant in ('baseline', 'candidate'):
    command.extend('--' + variant + '-option=' + option for option in options)
subprocess.run(command, check=True)
