# SPDX-License-Identifier: MPL-2.0
from pathlib import Path
import struct

def strings(data):
    result = []
    while data:
        length = struct.unpack('<Q', data[:8])[0]
        result.append(data[8:8+length])
        data = data[8+length:]
    return result

root = Path('/reports/pr74-linux-final/build-j8-retained-candidate/.openmktr')
files = sorted(root.glob('.kati-kbuild-tree-*'), key=lambda p:p.stat().st_mtime_ns)[-5:]
previous = None
for file in files:
    payload = strings(file.read_bytes())[2]
    records = strings(payload)[1:]
    current = {records[i].decode(): set(strings(records[i+2])) for i in range(0,len(records),3)}
    print(file.name, file.stat().st_mtime_ns, len(current))
    if previous:
        for directory in previous.keys() | current.keys():
            before, after = previous.get(directory,set()), current.get(directory,set())
            if before != after:
                print(directory, 'added', sorted(after-before)[:15], 'removed', sorted(before-after)[:15])
    previous = current
