import json
from pathlib import Path
import subprocess
import time

root = Path('/workspace/performance-fix-evidence/cleanup-review/metadata')
rows = []

def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=result.returncode,
               seconds=time.monotonic() - start)
    rows.append(row)
    (root / 'qualification-commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

normal = json.loads((root / 'normal/gates.json').read_text())
assert len(normal) == 28 and all(row['exit_code'] == 0 for row in normal)
run('sanitizers', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/metadata/sanitizer-gates.py'])
run('incremental', ['docker', 'run', '--rm', '--network', 'none', '--user', '1000:1000',
    '--entrypoint', 'python', '-v', '/workspace/Openmktr:/workspace',
    '-v', '/workspace/performance-fix-evidence:/evidence', '-w', '/workspace',
    'sha256:46ee6c75beb340c8524090e83306c34fb0f17e398568be896489545a8325f713',
    'validation/incremental.py', '--make', 'gmake', '--omktr', '/workspace/omktr',
    '--output', '/evidence/cleanup-review/metadata/incremental'])
run('phony-smoke', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/metadata/phony-smoke.py'])
run('performance', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/metadata/performance-gates.py'])
