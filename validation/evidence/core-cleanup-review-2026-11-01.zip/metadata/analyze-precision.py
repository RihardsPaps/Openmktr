import json
from pathlib import Path
import random
import statistics

root = Path('/workspace/performance-fix-evidence/cleanup-review/metadata')
plan = json.loads((root / 'precision-plan.json').read_text())
summary = []
for case in plan['cases']:
    pairs = {}
    counts = {}
    for origin in ('standard-paired', 'precision'):
        for line in (root / origin / 'samples.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['case'] == case and not row['warmup']:
                pairs.setdefault((origin, row['repeat']), {})[row['variant']] = row
        counts[origin] = sum(key[0] == origin for key in pairs)
    assert counts == {'standard-paired': 101, 'precision': 900}, counts
    assert len(pairs) == 1001 and all(set(pair) == {'b', 'c'} for pair in pairs.values())
    for metric in ('wall', 'rss'):
        ratios = [pair['c'][metric] / pair['b'][metric] for pair in pairs.values()]
        rng = random.Random(0)
        boot = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
        median = statistics.median(ratios)
        row = dict(case=case, metric=metric, pairs=len(pairs), original_pairs=101,
                   additional_pairs=900, median_ratio=median,
                   interval=[boot[249], boot[9749]],
                   passed=median <= 1 and boot[9749] <= 1.05)
        summary.append(row)
        print(json.dumps(row), flush=True)
(root / 'precision-pooled.json').write_text(json.dumps(summary, indent=2) + '\n')
