from pathlib import Path
import subprocess

root = Path('/evidence/cleanup-review/metadata/publication-traces')
for name, tool in [('before', '/evidence/cleanup-review/metadata-omktr'), ('after', '/workspace/omktr')]:
    directory = root / name
    directory.mkdir(parents=True)
    (directory / 'config.mk').write_text('CONFIG := initial\n')
    (directory / 'Makefile').write_text('include config.mk\n.PHONY: all\nall: ' + ' '.join(f'out{i}' for i in range(32)) + '\n' + ''.join(f'out{i}: src{i} config.mk\n\t@cp src{i} $@\n' for i in range(32)))
    for i in range(32):
        (directory / f'src{i}').write_text(f'input {i}\n')
    for phase in ('first', 'regenerate'):
        subprocess.run(['strace', '-c', '-e', 'trace=fsync,symlink,rename,unlink,mkdir,readlink', '-o', str(root / f'{name}-{phase}.log'), tool, '--ninja', '-j4', 'all'], cwd=directory, check=True, stdout=subprocess.DEVNULL)
