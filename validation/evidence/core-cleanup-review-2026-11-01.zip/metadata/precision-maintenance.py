import ctypes
import json
import os
from pathlib import Path
import signal
import time

root = Path('/evidence/cleanup-review')
stage = root / 'metadata'
log = stage / 'precision.log'
script = b'/evidence/cleanup-review/metadata/precision.py'
pids = []
for process in Path('/proc').iterdir():
    if not process.name.isdecimal():
        continue
    try:
        if script in (process / 'cmdline').read_bytes().split(b'\0'):
            pids.append(int(process.name))
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
assert len(pids) == 1, pids
pid = pids[0]
libc = ctypes.CDLL(None, use_errno=True)
watch = libc.inotify_init1(os.O_CLOEXEC)
assert watch >= 0
assert libc.inotify_add_watch(watch, os.fsencode(log), 2 | 8) >= 0
while 'completed nested_parallel_exec' not in log.read_text():
    os.read(watch, 4096)
os.close(watch)
os.kill(pid, signal.SIGSTOP)
try:
    # Only the clean-stage warmups may be paused. No measured pair spans
    # maintenance, and all completed nested samples remain untouched.
    rows = [json.loads(line) for line in (stage / 'precision/samples.jsonl').read_text().splitlines()]
    clean = [r for r in rows if r['case'] == 'end_to_end_clean']
    assert all(r['warmup'] for r in clean), clean[-1:]
    nested = [r for r in rows if r['case'] == 'nested_parallel_exec']
    assert len(nested) == 1804
    record = dict(pid=pid, nested_rows=len(nested), clean_rows=len(clean),
                  clean_measured_rows=0, reason='Release completed synthetic main fixtures between precision stages; retain and verify their command logs. Only clean-stage warmup timing can include the pause.')
    start = time.monotonic()
    source = (root / 'retire-fixtures.py').read_text()
    source = source.replace('/workspace/performance-fix-evidence/cleanup-review', '/evidence/cleanup-review')
    source = source.replace("'noop/paired'):", "'noop/paired', 'metadata/paired'):")
    exec(compile(source, 'retire-fixtures.py', 'exec'), {})
    record['maintenance_seconds'] = time.monotonic() - start
    (stage / 'precision-maintenance.json').write_text(json.dumps(record, indent=2) + '\n')
finally:
    os.kill(pid, signal.SIGCONT)
