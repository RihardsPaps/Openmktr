import hashlib,json,os,statistics,subprocess,time,random
from pathlib import Path
root=Path('/evidence/cleanup-review/publication/clean');root.mkdir(exist_ok=False)
os.sched_setaffinity(0, {0, 1, 2, 3})
(root/'cpu-affinity.json').write_text(json.dumps(sorted(os.sched_getaffinity(0)))+'\n')
tools={'b':'/baseline/omktr','c':'/workspace/omktr'}
env=dict(PATH='/usr/bin:/bin',HOME='/root',LC_ALL='C',TZ='UTC')
rows=[]
def run(command,cwd):
 start=time.perf_counter()
 p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 assert p.returncode==0,(command,p.returncode)
 return dict(wall=time.perf_counter()-start,rss=usage.ru_maxrss,user=usage.ru_utime,system=usage.ru_stime)
def retain(case,repeat,variant,result):
 row=dict(case=case,repeat=repeat,warmup=repeat<2,variant=variant,**result);rows.append(row)
 with (root/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
def tree(case,variant,makefile):
 d=root/case/variant;d.mkdir(parents=True);(d/'Makefile').write_text(makefile);return d
for case in []:
 dirs={};commands={};before={}
 for v,tool in tools.items():
  if case=='incremental_noop':
   source='all: link99\nlink0:\n\t@touch $@\n'+''.join(f'link{i}: link{i-1}\n\t@touch $@\n' for i in range(1,100))
   d=tree(case,v,source);command=[tool,'-j4','all'];run(command,d)
   before[v]={p.name:p.stat().st_mtime_ns for p in d.glob('link*')}
  elif case=='parallel_exec':
   source='.PHONY: all\nall: '+' '.join(f'job{i}' for i in range(16))+'\n'+''.join(f'job{i}:\n\t@sleep 0.05; touch $@\n' for i in range(16))
   d=tree(case,v,source);command=[tool,'-j4','-f','Makefile','all']
  elif case=='nested_parallel_exec':
   source='all: '+' '.join(f'group{i}' for i in range(4))+'\n'+''.join(f'group{g}: '+' '.join(f'nested{g}-{i}' for i in range(4))+'\n' for g in range(4))+''.join(f'nested{g}-{i}:\n\t@sleep 0.05; touch $@\n' for g in range(4) for i in range(4))
   d=tree(case,v,source);command=[tool,'-j4','all']
  else:
   jobs=' '.join(f'launch{i}' for i in range(2000));d=tree(case,v,f'.PHONY: all {jobs}\nall: {jobs}\n{jobs}:\n\t@:\n');run([tool,'--ninja','all'],d)
   command=([tool] if case.startswith('direct') else ['sh','./ninja.sh'])+['-j'+case[-1]]
  dirs[v]=d;commands[v]=command
 for repeat in range(1003):
  for v in ('bc' if repeat%2==0 else 'cb'):
   d=dirs[v]
   if case in ('parallel_exec','nested_parallel_exec'):
    for p in d.glob('job[0-9]*' if case=='parallel_exec' else 'nested[0-9]*'):p.unlink()
   result=run(commands[v],d)
   if case=='incremental_noop':assert before[v]=={p.name:p.stat().st_mtime_ns for p in d.glob('link*')}
   if case in ('parallel_exec','nested_parallel_exec'):assert len(list(d.glob('job[0-9]*' if case=='parallel_exec' else 'nested[0-9]*')))==16
   retain(case,repeat,v,result)
 print('completed',case,flush=True)
# Same 32-copy fixture and timed phases as tests/bench.py. Nanosecond ordering
# is checked directly on this filesystem; no fixed one-second setup delay.
for scenario in ['clean']:
 case='end_to_end_'+scenario
 for repeat in range(1003):
  for v in ('bc' if repeat%2==0 else 'cb'):
   d=root/case/str(repeat)/v;d.mkdir(parents=True)
   (d/'configure.py').write_text("from pathlib import Path\nPath('config.mk').write_text('CONFIG := initial\\n')\n")
   (d/'Makefile').write_text('include config.mk\n.PHONY: all\nall: '+' '.join(f'out{i}' for i in range(32))+'\n'+''.join(f'out{i}: src{i} config.mk\n\t@cp src{i} $@\n' for i in range(32)))
   for i in range(32):(d/f'src{i}').write_text(f'input {i}\n')
   configure=['python3','configure.py'];generate=[tools[v],'--ninja','--regen','-j4','all'];execute=['sh','./ninja.sh','-j4']
   before={}
   if scenario!='clean':
    for cmd in (configure,generate,execute):run(cmd,d)
    before={i:(d/f'out{i}').stat().st_mtime_ns for i in range(32)}
    graph_before=(d/'build.ninja').stat().st_mtime_ns
    latest=max(before.values())
    while time.time_ns()<=latest:time.sleep(.001)
    if scenario=='single_file_change':(d/'src0').write_text('changed input\n')
    if scenario=='graph_change':(d/'config.mk').write_text('CONFIG := changed\n')
   start=time.perf_counter();phases=[]
   for cmd in ([configure] if scenario=='clean' else [])+[generate,execute]:phases.append(run(cmd,d))
   result=dict(wall=time.perf_counter()-start,rss=max(x['rss'] for x in phases),user=sum(x['user'] for x in phases),system=sum(x['system'] for x in phases))
   if scenario in ('noop','single_file_change'):assert (d/'build.ninja').stat().st_mtime_ns==graph_before
   elif scenario=='graph_change':assert (d/'build.ninja').stat().st_mtime_ns>graph_before
   for i in range(32):
    assert (d/f'out{i}').read_bytes()==(d/f'src{i}').read_bytes()
    if scenario=='noop' or (scenario=='single_file_change' and i):assert (d/f'out{i}').stat().st_mtime_ns==before[i]
    elif scenario!='clean':assert (d/f'out{i}').stat().st_mtime_ns>before[i]
   retain(case,repeat,v,result)
 print('completed',case,flush=True)
summary=[]
for case in dict.fromkeys(r['case'] for r in rows):
 pairs={}
 for r in rows:
  if r['case']==case and not r['warmup']:pairs.setdefault(r['repeat'],{})[r['variant']]=r
 for metric in ['wall','rss']:
  ratios=[p['c'][metric]/p['b'][metric] for p in pairs.values()];rng=random.Random(0)
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
  summary.append(dict(case=case,metric=metric,pairs=len(pairs),baseline=statistics.median(p['b'][metric] for p in pairs.values()),candidate=statistics.median(p['c'][metric] for p in pairs.values()),median_ratio=statistics.median(ratios),interval=[boot[249],boot[9749]],passed=statistics.median(ratios)<=1 and boot[9749]<=1.05))
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
