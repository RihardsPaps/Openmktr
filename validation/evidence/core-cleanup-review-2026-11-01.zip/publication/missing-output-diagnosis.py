import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path('/evidence/cleanup-review/publication/missing-output-diagnosis')
root.mkdir()
os.sched_setaffinity(0, {0, 1, 2, 3})
tools = {'original': '/baseline/omktr', 'prior': '/evidence/cleanup-review/publication-omktr', 'current': '/workspace/omktr'}
env = dict(PATH='/usr/bin:/bin', HOME='/root', LC_ALL='C', TZ='UTC')
rows = []
orders = [('original', 'prior', 'current'), ('current', 'prior', 'original'),
          ('prior', 'current', 'original'), ('original', 'current', 'prior'),
          ('current', 'original', 'prior'), ('prior', 'original', 'current')]
(root / 'plan.json').write_text(json.dumps(dict(purpose='Diagnostic phase isolation, not an acceptance rerun', measured_rounds=51, warmups=2, tools=tools, orders=orders, cpu_affinity=[0, 1, 2, 3]), indent=2) + '\n')
for repeat in range(53):
    for name in orders[repeat % len(orders)]:
        directory = root / str(repeat) / name
        directory.mkdir(parents=True)
        (directory / 'configure.py').write_text("from pathlib import Path\nPath('config.mk').write_text('CONFIG := initial\\n')\n")
        (directory / 'Makefile').write_text('include config.mk\n.PHONY: all\nall: ' + ' '.join(f'out{i}' for i in range(32)) + '\n' + ''.join(f'out{i}: src{i} config.mk\n\t@cp src{i} $@\n' for i in range(32)))
        for i in range(32):
            (directory / f'src{i}').write_text(f'input {i}\n')
        phases = {}
        start = time.perf_counter()
        for phase, command in [('configure', ['python3', 'configure.py']),
                               ('generate', [tools[name], '--ninja', '--regen', '-j4', 'all']),
                               ('execute', ['sh', './ninja.sh', '-j4'])]:
            began = time.perf_counter()
            result = subprocess.run(command, cwd=directory, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            assert result.returncode == 0
            phases[phase] = time.perf_counter() - began
        row = dict(repeat=repeat, warmup=repeat < 2, variant=name, total=time.perf_counter() - start, phases=phases)
        for i in range(32):
            assert (directory / f'out{i}').read_bytes() == (directory / f'src{i}').read_bytes()
        rows.append(row)
        with (root / 'samples.jsonl').open('a') as output:
            output.write(json.dumps(row) + '\n')
summary = {}
for name in tools:
    selected = [row for row in rows if row['variant'] == name and not row['warmup']]
    summary[name] = {'total': statistics.median(row['total'] for row in selected)}
    summary[name].update({phase: statistics.median(row['phases'][phase] for row in selected) for phase in ('configure', 'generate', 'execute')})
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
