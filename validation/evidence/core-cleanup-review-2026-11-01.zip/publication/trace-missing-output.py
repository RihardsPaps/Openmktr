import json
from pathlib import Path
import re
import subprocess

root = Path('/evidence/cleanup-review/publication/missing-output-traces')
counts = {}
for name, tool in [('before', '/evidence/cleanup-review/publication-omktr'), ('after', '/workspace/omktr')]:
    directory = root / name
    directory.mkdir(parents=True)
    (directory / 'Makefile').write_text('.PHONY: all\nall: ' + ' '.join(f'out{i}' for i in range(32)) + '\n' + ''.join(f'out{i}: src{i}\n\t@cp $< $@\n' for i in range(32)))
    for i in range(32):
        (directory / f'src{i}').write_text(f'input {i}\n')
    subprocess.run([tool, '--ninja', 'all'], cwd=directory, check=True, stdout=subprocess.DEVNULL)
    log = root / f'{name}.log'
    subprocess.run(['strace', '-f', '-e', 'trace=execve', '-s', '16384', '-o', str(log), 'sh', './ninja.sh', '-j4'], cwd=directory, check=True, stdout=subprocess.DEVNULL)
    counts[name] = len(re.findall(r'execve\([^,]+, \["[^"]+", "--internal-low-resolution-up-to-date"', log.read_text()))
    for i in range(32):
        assert (directory / f'out{i}').read_bytes() == (directory / f'src{i}').read_bytes()
assert counts == {'before': 32, 'after': 0}, counts
(root / 'summary.json').write_text(json.dumps(counts, indent=2) + '\n')
print(counts)
