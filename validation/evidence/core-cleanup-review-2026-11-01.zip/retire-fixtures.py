import hashlib
import json
from pathlib import Path
import re
import shutil

root = Path('/workspace/performance-fix-evidence/cleanup-review')
prior = root / 'retired-fixtures.json'
retired = json.loads(prior.read_text())['fixtures'] if prior.exists() else []
previous_count = len(retired)
for name in ('inode-exhausted-paired', 'paired', 'cleanup-control', 'fixed/paired', 'noop/paired'):
    for tree in (root / name).iterdir():
        if not tree.is_dir() or not re.fullmatch(r'(direct|build|legacy)-j4-r\d+-(baseline|candidate)', tree.name):
            continue
        makefile = tree / 'Makefile'
        if not makefile.is_file() or 'out511.o: src511 config.mk' not in makefile.read_text():
            continue
        logs = []
        for log in tree.glob('*.log'):
            destination = root / 'fixture-logs' / name / tree.name / log.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(log, destination)
            digest = hashlib.sha256(log.read_bytes()).hexdigest()
            assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
            logs.append(dict(path=str(destination.relative_to(root)), sha256=digest))
        retired.append(dict(tree=str(tree.relative_to(root)), logs=logs))
        shutil.rmtree(tree)
(root / 'retired-fixtures.json').write_text(json.dumps(dict(
    reason='Make inode capacity available for the larger fixed-head campaign. Only completed or invalidated synthetic fixtures are removed. Raw samples, command journals, reports and verified copies of command logs remain.',
    fixtures=retired), indent=2) + '\n')
print('Retired', len(retired) - previous_count, 'additional reconstructable fixtures; command logs preserved.')
