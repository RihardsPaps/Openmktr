import json
from pathlib import Path
import shutil
import sys

root = Path(sys.argv[1])
names = [
    'metadata/standard-paired/end_to_end_clean',
    'metadata/standard-paired/end_to_end_noop',
    'metadata/standard-paired/end_to_end_single_file_change',
    'metadata/standard-paired/end_to_end_graph_change',
    'metadata/precision/end_to_end_clean',
    'metadata/clean-diagnosis',
    'metadata/migration-diagnosis',
    'metadata/publication-diagnosis',
    'publication/clean/end_to_end_clean',
    'publication/missing-output-diagnosis',
]
if len(sys.argv) > 2 and sys.argv[2] == 'include-publication-clean':
    names.append('publication/clean/end_to_end_clean')
if len(sys.argv) > 2 and sys.argv[2] == 'include-freshness-clean':
    names.append('freshness/clean/end_to_end_clean')
record = root / 'retired-clean-fixtures.json'
retired = json.loads(record.read_text()) if record.exists() else []
added = 0
for name in names:
    directory = root / name
    if not directory.exists():
        continue
    for repeat in directory.iterdir():
        if not repeat.is_dir() or not repeat.name.isdecimal():
            continue
        for fixture in repeat.iterdir():
            if not fixture.is_dir() or fixture.name not in ('b', 'c', 'original', 'prior', 'current'):
                continue
            makefile = fixture / 'Makefile'
            assert makefile.is_file() and 'out31: src31 config.mk' in makefile.read_text(), fixture
            assert not list(fixture.glob('*.log')), fixture
            shutil.rmtree(fixture)
            retired.append(str(fixture.relative_to(root)))
            added += 1
        if not any(repeat.iterdir()):
            repeat.rmdir()
record.write_text(json.dumps(retired, indent=2) + '\n')
print('Retired', added, 'completed reconstructable clean fixtures; parent plans, samples and summaries retained.')
