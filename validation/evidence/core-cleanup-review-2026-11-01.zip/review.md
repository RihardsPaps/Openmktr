# Core cleanup review

Final code revision: `fdff3e56aecf8dbfbde1cc55253347b101c0db42`.
All 28 portable groups, 17 sanitizer groups, 27 external incremental scenarios,
and all 60 predeclared timing/memory acceptance cells pass. Both snapshot
profiles pass 858/858 with zero quarantined crashes. All three CI workflows
pass for this code commit. Codex's final review has no findings or unresolved
findings: https://github.com/RihardsPaps/Openmktr/pull/65#issuecomment-6551227449.

The fresh paired campaign compares the final exact binary with original
baseline 77a397f using the same pinned Chimera toolchain. Build-mode clean
execution on 512 targets improves 32.0%, small end-to-end clean improves 9.4%,
and 10,000-target conversion improves 9.0% with 2.1% less peak process RSS.
Direct clean and parallel sleep controls remain near parity. Every cell passes
median ratio <= 1.00 and bootstrap 95% upper <= 1.05 independently. The final
report retains all sample counts, limits and historical failures below.
Real PC qualification remains unrun.

The following sections retain the detailed review and investigation history.

Reviewed the refactor against original baseline `77a397f` and the previously
qualified runtime `fd7573b` (PR head before this pass: `edfae36`). The cleanup
runtime is `88602d27260c33b6efa0c6b8acf5d708b6c80bc8`. The subsequent Codex
correctness fix is `20580cd3819e83b86a2be576b0f9798d2aad0f79`.

## Findings addressed

- `exec.cc`: the old scheduling wait loop now ran once, and completed-node
  updates repeatedly looked up the same map entry to derive the logical update
  flag. Remove the loop and obsolete scheduler headers, centralize completion
  under the existing state mutex, and compare the supplied timestamp directly.
  Simplify conditions whose failure case had already returned.
- `jobserver.cc`: a macro repeatedly locked and searched the thread connection
  map during one token acquisition. All accesses already hold the reader mutex.
  Retain one reference, remove the second mutex and macros, and store noncopyable
  connections directly in the map. Per-thread descriptors still live until
  joined-worker session teardown; release still returns the acquired token.
- `process.cc`: remove error checks repeated around the common error-checking
  helper. Remove duplicate temporary-script unlinks while preserving explicit
  successful-run unlink failure reporting and exception cleanup.
- `ninja_launcher.cc`: append export/unset fields directly instead of copying
  their strings into temporary initializer lists. The wire format is unchanged.
- `main.cc`: share generation pinning and collection-race recovery between the
  current native launcher and the saved-graph compatibility launcher. Destroy
  the failed reader before retrying, preserving the prior session binding.
- `file.h`/`file.cc`: remove the timestamp that was assigned but never read,
  default the empty destructor, and document borrowed AST ownership at storage.
- `fileutil.h`/`log.h`: remove process-only dependencies and a self-include.

## Detailed review coverage and retained contracts

- Invocation ownership: session service publication, borrowed TLS pointers,
  arena size/alignment and free lists, constructor rollback, early deletion,
  teardown ordering, nested sessions and worker bindings; parser, expression,
  statement, variable, symbol, file-cache and find-emulator migrations.
- Scheduling/execution: ready dependencies, cycle handling, caller participation,
  lazy worker creation, cancellation before joins, serial traversal, ignored
  intermediate edges, failure outcomes, logical updates, phony and double-colon
  targets, evaluator serialization, recursive admission and output cleanup.
- Processes/jobserver: POSIX spawn setup failure, temporary long recipes,
  stdout pipe ownership, child reaping, process groups, output streaming,
  inherited reservations, FIFO descriptors, load slots and token return.
- Publication: immutable object bytes and collision handling, bounded packs and
  descriptor reads, durability barriers, reader leases, generation manifests,
  alias publication, corruption recovery and collection. Saved/raw graphs still
  require retained objects and the legacy launcher, so those are not dead code.
- Caching/freshness: exact nanosecond and logical timestamps, positive/negative
  observations, effect epochs, include and regeneration checks, bounded pure
  implicit-resolution reuse, and symbol-order replay. Existing invalidation
  checks and ordinary-resolution fallbacks remain necessary.
- Diagnostics/qualification: structured monotonic timing, counters, separate
  process-memory metric, strict paired acceptance criteria and the remaining
  real-PC boundary. Historical evidence is not relabeled for this cleanup.

This is a correctness, maintainability and performance review of the refactor,
not a claim that every possible Makefile or external project has been tested.
Validation results and the separate Codex PR review request are recorded with
the final report.

## Codex review finding and repair

Codex completed the requested PR review at 88602d2 and reported that the
deferred double-colon `$?` helper dropped missing logical prerequisites. The
regression test reproduced missing outputs in build and legacy generated modes;
direct execution passed. An existing file marked phony also disappeared from
`$?` on repeat builds.

Commit 20580cd carries each prerequisite's physical/logical/phony kind and
low-resolution flag into a versioned deferred probe. The helper uses the shared
FileStamp comparison and retains the old saved-graph argument format. It keeps
normal-input ordering and deduplication and excludes order-only inputs. Focused
checks cover direct/build/legacy at one and four jobs, first and repeat builds,
missing logical files, existing phony files, low-resolution timestamps, a file
named `--`, malformed metadata and saved-graph helper compatibility. Both tests
pass after the fix; full validation is recorded separately.

## Performance investigation

The 88602d2 campaign passed 55/60 cells, including all memory checks. Five timing
cells failed the unchanged strict acceptance rule; these remain failures in the
retained report. A 31-pair direct/build control compared the preserved fd7573b
binary against the preserved 88602d2 binary in the same current environment.
None of its ten timing cells showed a statistically supported regression, but
several intervals remained wide. It does not replace baseline acceptance.

The fixed-head plan declares 101 measured pairs for the main and standard
matrices, retaining 301 for the two short standard cases and 101 for large graph
phases. Both binaries inherit affinity to CPUs 0–3, matching the workspace's
four-CPU quota within its five-CPU affinity set. This is an explicit measurement
control, not a claim that CPU throttling caused the earlier failures. Thresholds
are unchanged. Earlier samples and failed attempts remain separately identified.

## Silent phony no-op shell launches

The 20580cd campaign passed 57/60 cells: all main and large-graph cells, all
memory cells, but not three standard timing cells. Parallel sleep execution was
near parity (1.000126, interval 0.999501–1.001127). Generated 2,000-recipe launch
ratios were 1.007048 at one job and 1.009378 at four jobs, with intervals above 1.

A 31-pair disposable-graph ablation shortened the environment guard to an
equivalent AND/OR expression. It did not improve timing and was rejected; the
existing environment fallback remains unchanged. Raw graphs and measurements
are retained under guard-control.

Commit 5302d4f instead removes actual unnecessary work: a silent phony `@:`
recipe with default `/bin/sh -c`, no deferred evaluation, no command environment
changes and no explicit recursive prefix needs no shell process. Its phony
dependency edge and always-dirty prerequisite remain intact. Custom shells,
flags, exports, deferred reads and visible commands continue to execute. The
new regression test checks a physical file declared phony, repeated downstream
rebuilds, prerequisites, inherited export side effects, custom interpreters,
shell tracing flags and visible commands in all three execution modes.

The first test draft incorrectly expected one export expansion: the prerequisite
inherits its target-specific export too. The corrected expectation passes on
the pre-optimization binary and the new binary. This was a test expectation
correction, not a fixed runtime failure or a recorded compatibility exemption.

The final runtime receives a fresh campaign with unchanged thresholds. All main
and large-graph cells and ordinary standard controls retain 101 pairs, the two
short standard cases retain 301, and the near-parity parallel sleep control is
predeclared at 1001 pairs. All prior measurements remain separately identified.


## Explicit Ninja metadata regression and repair

Follow-up manual review found that command elimination bypassed rule metadata.
On 5302d4f, an explicit depfile was never loaded into Ninja's dependency log, and
an explicit `.KATI_RESTAT` on a physical phony output no longer suppressed an
unnecessary downstream rebuild. Both focused cases pass on pre-optimization
20580cd, fail on 5302d4f, and pass on f1ee1a2. They inspect actual dependency-log
inputs and downstream file contents after repeated builds.

The initial depfile test draft expected an evaluation-time `$(file ...)` write,
but Ninja generation defers I/O; that expectation failed even on 20580cd. The
corrected test uses a literal depfile and checks Ninja's recorded input and its
normal depfile removal. Both drafts and the corrected before/after logs remain
retained; the test correction is not presented as a runtime fix.

Commit f1ee1a23eb7da8e4f34696c1d5f1aca19a25e04b retains commands for explicit
restat, depfiles, pools, tags, implicit outputs, serialization, default pools
and the alternative Ninja phony-output option. Plain silent no-op fixtures still
avoid shells. The 5302d4f campaign completed its main 30-cell matrix successfully,
then was deliberately interrupted before remaining stages to fix correctness.
Its main results remain valid for that revision but do not qualify the final
code. The fresh final campaign retains all predeclared counts and thresholds.

## Confirmed small clean-build regression and publication cleanup

Runtime f1ee1a2 initially passed 58/60 cells. One fixed precision extension
retained all 101 original pairs and added 900 for nested parallel execution
and the small end-to-end clean case. Nested execution passed at a pooled ratio
of 0.999799; clean failed at 1.032774, with interval 1.026153–1.039445. The
extension was not repeated. Completed main fixtures were retired at the stage
boundary with verified log copies; no measured clean pair crossed maintenance.

Phase isolation found that graph preparation added fixed overhead while recipe
execution improved. Commit d4dca5f removes the empty legacy snapshot on fresh
generation and preserves public symlinks already pointing through current.
New links use atomic creation; replacement of different entries retains atomic
rename. Artifact, generation-root, parent and publication durability barriers
remain. The migration test now removes the current pointer to exercise actual
first migration from standalone files, and passes before and after the change.
The unused fstream include was removed.

A syscall trace of the 32-output fixture records first-generation renames
falling from 15 to 6, fsync calls from 16 to 15, and regeneration renames from
14 to 7. These are diagnostic syscall counts, not an elapsed-time speed claim.
The publication-only runtime still failed its 1,001-pair clean gate at ratio
1.021035 (interval 1.014070–1.026020). Its remaining campaign stages were not
run, and its failure remains retained.

## Missing-output freshness probes

Commit fdff3e5 removes another unnecessary process boundary. Ordinary generated
recipes previously started the native timestamp helper even when their output
was missing. The existing recipe shell now rejects that case with an existence
check before starting the helper. Existing outputs retain native nanosecond
checks; intermediate-consumer closure proofs retain the previous path. The
emitted command remains stable across first, repeat and deleted-output builds.

The corrected current/stale-output regression now also checks rebuilding a
deleted output. Diagnostic correctness passes all 192 cases in both profiles
and the Make compatibility suite. An execution trace verifies 32 freshness
helper processes before the change and zero afterward in the clean fixture,
with correct output contents. The final exact binary receives a fresh complete
predeclared campaign, starting with 1,001 clean pairs. Parallel, nested and
graph-change controls also use 1,001; short cases use 301, and the remaining
main/large-graph/standard cases use 101. Prior failed candidates and all samples
remain retained. Final acceptance is recorded in the report, not inferred from
the diagnostics or syscall counts.
