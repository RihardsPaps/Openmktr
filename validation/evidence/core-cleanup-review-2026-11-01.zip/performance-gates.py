import json
import subprocess
import time
from pathlib import Path

root = Path('/evidence/cleanup-review')
results = []

def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=result.returncode,
               seconds=time.monotonic() - start)
    results.append(row)
    (root / 'performance-commands.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)

run('paired-matrix', ['python', 'validation/benchmark_ninja.py',
    '--project', 'synthetic', '--root', str(root / 'paired'),
    '--baseline', '/baseline/omktr',
    '--baseline-revision', '77a397ffd7a1cc5f48e406f8cf9052a50cc0d150',
    '--candidate', '/workspace/omktr',
    '--candidate-revision', '88602d27260c33b6efa0c6b8acf5d708b6c80bc8',
    '--entrypoints', 'direct', 'build', 'legacy', '--jobs', '4',
    '--samples', '31', '--warmups', '2', '--require-no-regression'])
run('phases', ['python', str(root / 'phases.py'), 'cleanup-review/phases'])
run('phase-analysis', ['python', str(root / 'analyze-phases.py'), str(root / 'phases')])
run('standard-benchmark', ['python', 'tests/bench.py', '/workspace/omktr',
    '--baseline', '/baseline/omktr', '--repeats', '7'])
# Predeclare 301 pairs for the two short cases that needed the same precision
# in the prior qualification. All other standard controls retain 31 pairs.
run('paired-standard', ['python', str(root / 'paired-standard.py')])
raise SystemExit(any(row['exit_code'] for row in results))
