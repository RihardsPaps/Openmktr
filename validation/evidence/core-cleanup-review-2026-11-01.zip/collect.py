import datetime
import hashlib
import json
import re
import zipfile
from pathlib import Path

root = Path('/workspace/performance-fix-evidence/cleanup-review')
fixed = root / 'freshness'
destination = Path('/workspace/Openmktr/validation/evidence')
stem = 'core-cleanup-review-2026-11-01'

def read(path):
    return json.loads(path.read_text())

def cells(directory):
    paired = read(directory / 'paired/report.json')
    assert not paired['failure'] and not paired['source_changes']
    assert not paired['monitor_cleanup_errors']
    result = []
    for metric, rows in [('wall', paired['no_regression']), ('rss', paired['memory'])]:
        for row in rows:
            result.append(dict(suite='entrypoints', case=row['entrypoint'] + '/' + row['scenario'],
                metric=metric, pairs=row['pairs'], median_ratio=row['median_ratio'],
                upper_95=row['ratio_upper_95'], passed=row['parity_passed']))
    summaries = [('large_graph', 'phases/summary.json', 'phase'), ('standard', 'standard-paired/summary.json', 'case')]
    if (directory / 'clean/summary.json').exists():
        summaries.append(('standard', 'clean/summary.json', 'case'))
    for suite, file, key in summaries:
        for row in read(directory / file):
            result.append(dict(suite=suite, case=row[key], metric=row['metric'], pairs=row['pairs'],
                median_ratio=row['median_ratio'], lower_95=row['interval'][0],
                upper_95=row['interval'][1], passed=row['passed']))
    assert len(result) == 60
    assert all(row['passed'] == (row['median_ratio'] <= 1 and row['upper_95'] <= 1.05) for row in result)
    return result

normal = read(fixed / 'normal/gates.json')
sanitizers = read(fixed / 'sanitizers/sanitizers.json')
incremental = read(fixed / 'incremental/report.json')
assert len(normal) == 28 and all(row['exit_code'] == 0 for row in normal)
assert len(sanitizers) == 17 and all(row['exit_code'] == 0 for row in sanitizers)
assert len(incremental['runs']) == 27 and not incremental['release_blocked']
assert not incremental['performance_defects'] and not incremental['errors']
current_cells = cells(fixed)
assert len({(r['suite'], r['case'], r['metric']) for r in current_cells}) == 60
assert {suite: sum(r['suite'] == suite for r in current_cells)
        for suite in ('entrypoints', 'large_graph', 'standard')} == {
            'entrypoints': 30, 'large_graph': 8, 'standard': 22}
standard_pairs = dict(incremental_noop=301, direct_recipe_launch_j1=301,
    parallel_exec=1001, nested_parallel_exec=1001,
    end_to_end_clean=1001, end_to_end_graph_change=1001)
for row in current_cells:
    expected = standard_pairs.get(row['case'], 101) if row['suite'] == 'standard' else 101
    assert row['pairs'] == expected, row
metadata_initial_cells = cells(root / 'metadata')
metadata_cells = [dict(row) for row in metadata_initial_cells]
precision = read(root / 'metadata/precision-pooled.json')
for refined in precision:
    assert refined['pairs'] == 1001 and refined['original_pairs'] == 101 and refined['additional_pairs'] == 900
    matches = [r for r in metadata_cells if r['suite'] == 'standard' and r['case'] == refined['case'] and r['metric'] == refined['metric']]
    assert len(matches) == 1
    matches[0].update(pairs=refined['pairs'], median_ratio=refined['median_ratio'], lower_95=refined['interval'][0], upper_95=refined['interval'][1], passed=refined['passed'], evidence_source='All original 101 pairs plus the one fixed 900-pair precision extension.')
initial_cells = cells(root)
previous_fixed_cells = cells(root / 'fixed')
performance_passed = all(row['passed'] for row in current_cells)
identities = read(fixed / 'identities.json')
for path, identity in identities['binaries'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == identity['sha256']
reviews = read(root / 'reviews.json')
assert reviews['latest_review']['commit_sha'] == identities['runtime_revision']
assert reviews['latest_review']['status'] == 'completed'
assert not reviews['latest_review']['has_unresolved_findings']
ci = read(fixed / 'ci.json')
assert ci['runtime_revision'] == identities['runtime_revision']
assert len(ci['workflow_runs']) == 3
assert all(run['status'] == 'completed' and run['conclusion'] == 'success' for run in ci['workflow_runs'])
commands = read(fixed / 'performance-commands.json')
assert len(commands) == 6
commands_by_name = {row['name']: row for row in commands}
assert all(row['exit_code'] == 0 for row in commands if row['name'] != 'paired-matrix')
assert commands_by_name['paired-matrix']['exit_code'] == (0 if read(fixed / 'paired/report.json')['no_regression_passed'] else 3)

selected = set()
for directory in (root, root / 'fixed', root / 'noop', root / 'metadata', root / 'publication', fixed):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.py', '.json', '.jsonl', '.log', '.md', '.patch', '.txt'):
            selected.add(path)
    for name in ('normal', 'sanitizers', 'incremental', 'phony-smoke'):
        for path in (directory / name).rglob('*'):
            if path.is_file() and not path.is_symlink() and path.suffix in ('.json', '.jsonl', '.log', '.stdout', '.stderr'):
                selected.add(path)
    for name in ('paired', 'inode-exhausted-paired', 'cleanup-control'):
        where = directory / name
        if where.exists():
            for path in where.iterdir():
                if path.is_file() and path.suffix in ('.json', '.jsonl', '.log'):
                    selected.add(path)
            for tree in where.iterdir():
                if tree.is_dir():
                    selected.update(p for p in tree.glob('*.log') if p.is_file() and not p.is_symlink())
    for name, files in [('phases', ['times.json', 'summary.json']),
                        ('standard-paired', ['samples.jsonl', 'summary.json']),
                        ('precision', ['samples.jsonl', 'summary.json', 'cpu-affinity.json']),
                        ('clean', ['samples.jsonl', 'summary.json', 'cpu-affinity.json']),
                        ('clean-diagnosis', ['samples.jsonl', 'summary.json', 'plan.json']),
                        ('migration-diagnosis', ['samples.jsonl', 'summary.json', 'plan.json']),
                        ('publication-diagnosis', ['samples.jsonl', 'summary.json', 'plan.json']),
                        ('missing-output-diagnosis', ['samples.jsonl', 'summary.json', 'plan.json'])]:
        selected.update(directory / name / file for file in files if (directory / name / file).exists())
    for name in ('publication-traces', 'missing-output-traces'):
        where = directory / name
        if where.exists():
            selected.update(p for p in where.iterdir() if p.is_file() and p.suffix in ('.log', '.json'))
selected.update(p for p in (root / 'fixture-logs').rglob('*.log') if p.is_file())
selected.update(p for p in (root / 'guard-control').iterdir() if p.is_file())
credential = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
manifest = []
archive = destination / (stem + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(selected):
        data = path.read_bytes()
        if credential.search(data):
            raise RuntimeError('Credential pattern in ' + str(path.relative_to(root)))
        name = str(path.relative_to(root))
        output.writestr(name, data)
        manifest.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    output.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for entry in manifest:
        assert hashlib.sha256(output.read(entry['path'])).hexdigest() == entry['sha256']
checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / (stem + '.zip.sha256')).write_text(checksum + '  ' + archive.name + '\n')
report = dict(schema=1, date='2026-11-01', campaign_start_date='2026-10-31', generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), identities=identities,
    review=read(root / 'reviews.json'), source_review='Detailed analysis and retained contracts: review.md inside the raw archive.',
    changes=[
        'Consolidated completed-node bookkeeping and removed the one-iteration scheduler loop and unused headers.',
        'Removed repeated jobserver connection lookups, an unnecessary mutex and per-connection heap allocation.',
        'Centralized spawn error checks and removed duplicate temporary recipe unlinks.',
        'Removed temporary launch-plan string copies without changing its wire format.',
        'Shared generation pinning/retry logic while preserving the saved-graph launcher.',
        'Removed unused Makefile timestamps, empty out-of-line destruction, obsolete includes and a self-include.',
        'Fixed the Codex-reported double-colon deferred $? bug, with logical/phony metadata and saved-graph compatibility.',
        'Elided silent phony no-op shell launches while retaining dependency freshness, exports, custom shells/flags, visible commands and explicit Ninja metadata.',
        'Removed empty first-generation legacy migration and redundant alias replacement while retaining all required durability barriers and atomic replacement of changed aliases.',
        'Skipped native freshness probes for missing ordinary outputs in the existing recipe shell, preserving native checks for existing outputs and intermediate-consumer proof handling.'
    ],
    portable=dict(passed=True, commands=normal, snapshots=dict(safe='858/858', aggressive='858/858', quarantined_crashes=0)),
    sanitizers=dict(passed=True, commands=sanitizers,
        leak_detection='Session ownership unit uses detect_leaks=1; other suites use detect_leaks=0.'),
    external_incremental=dict(scenarios=27, release_blocked=False, performance_defects=False, errors=[]),
    ci=ci,
    performance=dict(passed=performance_passed, plan=read(fixed / 'performance-plan.json'), cells=current_cells,
        required_standard_command=commands_by_name['standard-benchmark'],
        previous_metadata_run=dict(runtime='f1ee1a23eb7da8e4f34696c1d5f1aca19a25e04b',passed=False,initial_cells=metadata_initial_cells,cells=metadata_cells,precision_plan=read(root / 'metadata/precision-plan.json'),precision_maintenance=read(root / 'metadata/precision-maintenance.json')),
        previous_publication_clean_gate=dict(runtime='d4dca5fd9a282a596d867e16781863fbc2665471',passed=False,cells=read(root / 'publication/clean/summary.json'),remaining_stages='Not run after the first clean gate failed.'),
        previous_fixed_run=dict(runtime='20580cd3819e83b86a2be576b0f9798d2aad0f79',passed=False,cells=previous_fixed_cells),
        rejected_guard_experiment=read(root / 'guard-control/summary.json'),
        previous_cleanup_run=dict(runtime='88602d27260c33b6efa0c6b8acf5d708b6c80bc8',passed=False,cells=initial_cells),
        cleanup_control=dict(baseline='fd7573bdd7e0166d3f97fa5d41e29b0e2613ae3f',candidate='88602d27260c33b6efa0c6b8acf5d708b6c80bc8',
            supported_regressions=[dict(entrypoint=r['entrypoint'],scenario=r['scenario']) for r in read(root/'cleanup-control/report.json')['no_regression'] if r['supported_regression']],
            interpretation='No supported timing regression in the same-environment control; wide intervals prevent using it as strict acceptance.'),
        incomplete_noop_run=dict(runtime='5302d4f989608f090b0eb32ca4cbbb5e6a50d16f', main_matrix_passed=read(root / 'noop/paired/report.json')['no_regression_passed'], interruption=read(root / 'noop/interrupted-qualification.json')),
        incomplete_attempt=read(root / 'restart.json')),
    archive=dict(file=archive.name, sha256=checksum, bytes=archive.stat().st_size, entries=len(manifest)+1),
    limits=[
        'Synthetic cloud measurements against original baseline 77a397f; real PC qualification remains unrun.',
        'RSS is peak individual-process memory, not simultaneous process-tree memory; small cases can be masked by the parent/exec high-water floor.',
        'The first benchmark attempt exhausted workspace inodes and is retained as incomplete evidence. Emergency inode recovery removed one warmup fixture and its per-fixture logs; its recorded samples and command journal remain. Subsequent fixture retirement preserved samples, reports and surviving command logs.',
        'The initial external-container startup for the fixed runtime used the wrong entrypoint and failed before any test ran; its log is retained alongside the completed explicit-entrypoint campaign.',
        'The first no-op test draft omitted the inherited export expansion on its prerequisite. The corrected expectation was verified against the pre-optimization binary before testing the change.',
        'The first depfile test draft incorrectly expected evaluation-time file I/O during Ninja generation. The corrected dependency-log test passes before optimization, fails on 5302d4f and passes after the metadata fix. Its original and corrected reproduction logs are retained.',
        'The 5302d4f performance campaign completed its 30-cell main matrix and was intentionally stopped before remaining stages after manual review reproduced metadata regressions; it does not qualify the final runtime.',
        'Prior runtime f1ee1a2 initially passed 58/60 cells. Its one fixed precision extension retained the original samples and confirmed a 3.3% small clean regression, leaving 59/60 passing cells. Publication-only runtime d4dca5f still failed its clean gate at +2.1%; both failures remain retained. The final runtime receives a fresh predeclared campaign after removing missing-output probe processes.',
        'Completed synthetic main-matrix fixtures were retired between precision stages with verified command-log copies. Only clean-stage warmup timing can include the maintenance pause; no measured pair spans it.',
        'Earlier runtime results remain historical and do not qualify subsequent code. No per-cell threshold was relaxed.'
    ])
(destination / (stem + '.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(archive=report['archive'], passing_performance_cells=sum(r['passed'] for r in current_cells),
    normal_checks=len(normal), sanitizer_checks=len(sanitizers)), indent=2))
