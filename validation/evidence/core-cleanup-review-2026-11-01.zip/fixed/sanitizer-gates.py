import json,os,subprocess,time
from pathlib import Path
root=Path('/evidence/cleanup-review/fixed/sanitizers'); root.mkdir(exist_ok=True); results=[]
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',OMKTR_BINARY='/workspace/omktr-sanitized')
def run(name,cmd,extra=None):
    start=time.monotonic(); runenv=dict(env); runenv.update(extra or {})
    with (root/('sanitized-'+name+'.log')).open('w') as log:
        p=subprocess.run(cmd,env=runenv,stdout=log,stderr=subprocess.STDOUT)
    row=dict(name=name,command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start)
    results.append(row); (root/'sanitizers.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(row),flush=True)
    return p.returncode
run('session_unit', ['out/sanitized/session_test'], {'ASAN_OPTIONS':'detect_leaks=1'})
for name in ('ready_queue','timeutil','find','ninja','strutil','load_limit'):
    run(name+'_unit',['out/sanitized/'+name+'_test'])
for name in ('architecture','portage','load_limits','correctness','generated_recipe_reads','graph_optimizations','workspace','ninja_jobserver','make_compat_regressions'):
    run(name,['python','tests/'+name+'.py'])
run('correctness_aggressive',['python','tests/correctness.py'],{'OMKTR_TEST_GRAPH_PROFILE':'aggressive'})

raise SystemExit(any(row['exit_code'] for row in results))
