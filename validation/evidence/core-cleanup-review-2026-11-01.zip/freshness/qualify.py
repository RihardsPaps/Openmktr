import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path('/workspace/performance-fix-evidence/cleanup-review/freshness')
rows = []

def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=result.returncode,
               seconds=time.monotonic() - start)
    rows.append(row)
    (root / 'qualification-commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

assert all(row['passed'] for row in json.loads((root / 'clean/summary.json').read_text()))
run('build', ['docker', 'exec', '-e', 'OMKTR_SOURCE_REVISION=fdff3e5', 'openmktr-diagnostics',
    'sh', '-c', 'python tools/gen_version.py out/version_generated.cc && python tools/gen_sanitizer_build.py && python tools/gen_version.py out/sanitized/version_generated.cc && ninja -j4 omktr tests && ninja -f build.sanitizer.ninja -j4 omktr-sanitized tests'])
assert hashlib.sha256(Path('/workspace/Openmktr/omktr').read_bytes()).hexdigest() == (root / 'clean-binary-sha256.txt').read_text().strip()
run('normal', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/freshness/normal-gates.py'])
run('sanitizers', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/freshness/sanitizer-gates.py'])
run('incremental', ['docker', 'run', '--rm', '--network', 'none', '--user', '1000:1000',
    '--entrypoint', 'python', '-v', '/workspace/Openmktr:/workspace',
    '-v', '/workspace/performance-fix-evidence:/evidence', '-w', '/workspace',
    'sha256:46ee6c75beb340c8524090e83306c34fb0f17e398568be896489545a8325f713',
    'validation/incremental.py', '--make', 'gmake', '--omktr', '/workspace/omktr',
    '--output', '/evidence/cleanup-review/freshness/incremental'])
run('phony-smoke', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/freshness/phony-smoke.py'])
run('performance-remaining', ['docker', 'exec', '--user', '1000:1000', 'openmktr-diagnostics',
    'python', '/evidence/cleanup-review/freshness/performance-gates.py', 'remaining'])
