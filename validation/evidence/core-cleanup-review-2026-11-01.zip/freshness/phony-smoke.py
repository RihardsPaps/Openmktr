import json
from pathlib import Path
import subprocess

root = Path('/evidence/cleanup-review/freshness/phony-smoke')
counts = {}
jobs = ' '.join(f'launch{i}' for i in range(2000))
for name, tool in [('baseline', '/baseline/omktr'), ('candidate', '/workspace/omktr')]:
    directory = root / name
    directory.mkdir(parents=True)
    (directory / 'Makefile').write_text(f'.PHONY: all {jobs}\nall: {jobs}\n{jobs}:\n\t@:\n')
    subprocess.run([tool, '--ninja', 'all'], cwd=directory, check=True)
    commands = subprocess.check_output(['ninja', '-t', 'commands', 'all'], cwd=directory, text=True)
    (directory / 'commands.log').write_text(commands)
    counts[name] = len(commands.splitlines())
assert counts == {'baseline': 2000, 'candidate': 0}
(root.parent / 'phony-smoke-summary.json').write_text(json.dumps(counts, indent=2) + '\n')
print(counts)
