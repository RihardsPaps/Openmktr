import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/evidence/cleanup-review/freshness')
os.sched_setaffinity(0, {0, 1, 2, 3})
(root / 'cpu-affinity.json').write_text(json.dumps(sorted(os.sched_getaffinity(0))) + '\n')
mode = sys.argv[1] if len(sys.argv) > 1 else 'all'
results = json.loads((root / 'performance-commands.json').read_text()) if mode == 'remaining' else []

def run(name, command):
    start = time.monotonic()
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=result.returncode,
               seconds=time.monotonic() - start)
    results.append(row)
    (root / 'performance-commands.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode and not (name == 'paired-matrix' and result.returncode == 3):
        raise SystemExit(result.returncode)

if mode != 'remaining':
    (root / 'clean-binary-sha256.txt').write_text(hashlib.sha256(Path('/workspace/omktr').read_bytes()).hexdigest() + '\n')
    run('clean-gate', ['python', str(root / 'clean-gate.py')])
    if not all(row['passed'] for row in json.loads((root / 'clean/summary.json').read_text())):
        raise SystemExit(3)
    if mode == 'clean-only':
        raise SystemExit(0)
else:
    assert len(results) == 1 and results[0]['name'] == 'clean-gate' and results[0]['exit_code'] == 0
    assert all(row['passed'] for row in json.loads((root / 'clean/summary.json').read_text()))
    assert (root / 'clean-binary-sha256.txt').read_text().strip() == hashlib.sha256(Path('/workspace/omktr').read_bytes()).hexdigest()

# Capacity maintenance runs only between benchmark stages. Raw samples and
# verified copies of command logs remain in the evidence tree.
with (root / 'retire-clean.log').open('w') as log:
    subprocess.run(['python', '/evidence/cleanup-review/retire-clean-fixtures.py',
                    '/evidence/cleanup-review', 'include-freshness-clean'],
                   stdout=log, stderr=subprocess.STDOUT, check=True)
run('paired-matrix', ['python', 'validation/benchmark_ninja.py', '--project', 'synthetic',
    '--root', str(root / 'paired'), '--baseline', '/baseline/omktr',
    '--baseline-revision', '77a397ffd7a1cc5f48e406f8cf9052a50cc0d150',
    '--candidate', '/workspace/omktr', '--candidate-revision', 'fdff3e56aecf8dbfbde1cc55253347b101c0db42',
    '--entrypoints', 'direct', 'build', 'legacy', '--jobs', '4', '--samples', '101',
    '--warmups', '2', '--require-no-regression'])
source = Path('/evidence/cleanup-review/retire-fixtures.py').read_text()
source = source.replace('/workspace/performance-fix-evidence/cleanup-review', '/evidence/cleanup-review')
source = source.replace("'noop/paired'):", "'noop/paired', 'freshness/paired'):")
exec(compile(source, 'retire-fixtures.py', 'exec'), {})
run('phases', ['python', str(root / 'phases.py'), 'cleanup-review/freshness/phases'])
run('phase-analysis', ['python', str(root / 'analyze-phases.py'), str(root / 'phases')])
run('standard-benchmark', ['python', 'tests/bench.py', '/workspace/omktr', '--baseline', '/baseline/omktr', '--repeats', '7'])
run('paired-standard', ['python', str(root / 'paired-standard.py')])
