import json, os, random, re, statistics, subprocess, time
from pathlib import Path
os.sched_setaffinity(0, {0, 1, 2, 3})
root = Path('/evidence/cleanup-review/guard-control'); root.mkdir(exist_ok=False)
cwd = Path('/evidence/cleanup-review/fixed/standard-paired/ninja_recipe_launch_j1/c')
original = (cwd/'build.ninja').read_text()
compact, count = re.subn(r'if \[ -r ([^;\n]+) \]; then \. \1; fi; ', r'[ ! -r \1 ] || . \1; ', original)
assert count == 2000, count
for variant, graph in [('original', original), ('compact', compact)]:
 (cwd/('guard-'+variant+'.ninja')).write_text(graph)
env=dict(PATH='/usr/bin:/bin', HOME='/root', LC_ALL='C', TZ='UTC')
rows=[]
for jobs in [1,4]:
 for repeat in range(33):
  for variant in (['original','compact'] if repeat%2==0 else ['compact','original']):
   command=['sh','./ninja.sh',f'-j{jobs}','-f',f'guard-{variant}.ninja']
   start=time.perf_counter()
   child=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
   error=child.stderr.read().decode();child.stderr.close()
   assert child.returncode==0,(command,error)
   row=dict(jobs=jobs,repeat=repeat,warmup=repeat<2,variant=variant,wall=time.perf_counter()-start,user=usage.ru_utime,system=usage.ru_stime,rss=usage.ru_maxrss)
   rows.append(row)
   with (root/'samples.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
 print('completed',jobs,flush=True)
summary=[]
for jobs in [1,4]:
 pairs={}
 for r in rows:
  if r['jobs']==jobs and not r['warmup']:pairs.setdefault(r['repeat'],{})[r['variant']]=r
 ratios=[p['compact']['wall']/p['original']['wall'] for p in pairs.values()];rng=random.Random(0)
 boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
 summary.append(dict(jobs=jobs,pairs=len(pairs),median_ratio=statistics.median(ratios),interval=[boot[249],boot[9749]]))
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
