"""Preserve cancelled diagnostics without treating them as build failures or wins."""
import collections
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path('/root/openmktr-libreoffice-fullblast-20261029')
repo = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
export = repo / 'validation/logs/libreoffice-fullblast-20261029'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

report = json.loads((root / 'report.json').read_text())
report['status'] = 'stopped-at-user-request-with-documented-issues'
report['date'] = '2026-10-29'
report['runs']['aggressive-direct-build']['outcome'] = 'cancelled-at-user-request'
report['runs']['aggressive-direct-build']['cancellation'] = 'SIGTERM sent to the benchmark process group after a short GDB attachment; recipe Error 143 and supervisor exit 1 are expected cancellation effects.'
for name, run in report['runs'].items():
    if name.startswith('initial-failed-'):
        run['log'] = str(root / (name + '.log'))
report.pop('comparison', None)
report['speed_comparison_available'] = False
report['speed_comparison_reason'] = 'GNU completed; Aggressive Ninja generation crashed; direct Aggressive was intentionally cancelled before completion.'
report['gnu_soffice_version'] = 'LibreOfficeDev 25.2.7.2'
report['gnu_configuration_bootstrap_build_seconds'] = sum(report['runs'][name]['wall_seconds'] for name in ['gnu-configure', 'gnu-bootstrap', 'gnu-build'])
report['host'] = {'physical_ram_bytes': 34130411520, 'windows_logical_processors': 32, 'cpu': 'Intel Core i9-14900KF', 'linux_native_storage_initial_available_gib_approx': 690, 'nas_accessed': False}
report['resource_cleanup'] = {'benchmark_processes_remaining': [], 'wslconfig_restored': 'memory=24GB, swap=16GB, processors=32', 'wslconfig_backup': 'C:/Users/Harry/.wslconfig.libreoffice-20261029.bak', 'note': 'The restored configuration takes effect on the next WSL restart; no system restart was forced during finalization.'}
report['tool_build'] = {'compiler': 'Chimera Clang 22.1.8', 'runtime': 'musl and LLVM libc++ libc++abi libunwind', 'optimization': 'checked-in C++17 O2 ThinLTO graph', 'linking': 'dynamic; absolute private musl interpreter and RUNPATH added to disposable build graph for WSL execution', 'source_edits': False, 'initial_static_link_attempt': 'failed because static C/C++ runtime archives were unavailable; resolved with dynamic musl linking', 'binary_path': str(root / 'omktr'), 'runtime_sha256': {p.name:digest(p) for p in (root / 'runtime').iterdir() if p.is_file()}}
report['observations'] = {}
for lane in ['gnu', 'initial-failed-aggressive', 'aggressive', 'aggressive-direct']:
    log = root / (lane + '-build.log')
    text = log.read_text(errors='replace')
    tree_lane = 'initial-failed-aggressive' if lane == 'initial-failed-aggressive' else lane
    objects = list((root / tree_lane / 'build/workdir').rglob('*.o'))
    report['observations'][lane] = {'cxx_build_messages': text.count('[build CXX]'), 'circular_dependency_messages': text.count('Circular '), 'missing_file_messages': text.count('No such file or directory'), 'git_metadata_messages': text.count('fatal: not a git repository'), 'warning_messages': text.count('warning:'), 'retained_object_files': len(objects)}
    if lane in ['aggressive', 'initial-failed-aggressive']:
        report['observations'][lane]['objects_created_during_generation'] = [str(p.relative_to(root / tree_lane / 'build')) for p in objects]
    if lane == 'aggressive-direct':
        report['observations'][lane]['circular_dependency_lines'] = [line for line in text.splitlines() if line.startswith('Circular ')]
        report['observations'][lane]['gdb_attachment_invalidates_clean_benchmark_interpretation'] = True
configs = {}
for lane in ['gnu', 'aggressive', 'aggressive-direct']:
    text = (root / lane / 'build/config_host.mk').read_text().replace(str(root / lane), '<LANE>')
    configs[lane] = hashlib.sha256(text.encode()).hexdigest()
report['normalized_config_host_sha256'] = configs
report['normalized_config_host_equal'] = len(set(configs.values())) == 1
snapshot = json.loads((root / 'direct-stop-process-snapshot.json').read_text())[0]
report['direct_stop_wait_channels'] = dict(collections.Counter(snapshot['thread_wait_channels'].values()))
report['direct_stack_limitations'] = 'Host GDB attachment did not unwind musl worker stacks into scheduler functions. Wait-channel counts establish futex/poll waits but do not identify the exact lock or dependency.'
report['limits'] += ['Neither failed-generation durations nor the cancelled direct duration are full build performance samples.', 'Single successful GNU clean build; no paired samples or confidence interval.', 'Direct diagnostic includes a brief debugger attachment immediately before cancellation.', 'No Safe/off profile control, sanitizer replay, or reduced crash reproducer was run.', 'Bootstrap and generated-include/helper work can compile before Ninja starts; one concat-deps object was present after each failed generation.']
report['limits'] = list(dict.fromkeys(report['limits']))
for name in ['soffice.bin', 'libswlo.so', 'libsclo.so', 'libsdlo.so', 'libvcllo.so']:
    artifact = root / 'gnu/build/instdir/program' / name
    if artifact.exists():
        report['gnu_artifacts'][str(artifact.relative_to(root / 'gnu/build'))] = {'bytes':artifact.stat().st_size, 'sha256':digest(artifact)}
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(root / 'report.json', export / 'report.json')
shutil.copy2(export / 'run_benchmark.py', root / 'run_benchmark.py')
shutil.copy2(export / 'finalize_evidence.py', root / 'finalize_evidence.py')
files = [p for p in root.iterdir() if p.is_file() and p.suffix in ['.json', '.jsonl', '.log', '.txt', '.py']]
manifest = {p.name:{'bytes':p.stat().st_size, 'sha256':digest(p)} for p in sorted(files)}
archive_path = repo / 'validation/evidence/libreoffice-benchmark-2026-10-29.zip'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
report['evidence_archive'] = {'path':'validation/evidence/libreoffice-benchmark-2026-10-29.zip', 'sha256':digest(archive_path), 'entries':len(files), 'note':'Archive report is the final measurement record before this outer archive descriptor was added. No binaries or release trees are included.'}
(repo / 'validation/libreoffice-benchmark-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archive':report['evidence_archive'], 'configurations_match':report['normalized_config_host_equal'], 'gnu_total_seconds':report['gnu_configuration_bootstrap_build_seconds'], 'observations':report['observations'], 'wait_channels':report['direct_stop_wait_channels']}, indent=2))
