"""Local, sequential, clean LibreOffice build comparison; retained raw evidence."""
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import tarfile
import threading
import time
import sys

ROOT = Path('/root/openmktr-libreoffice-fullblast-20261029')
CAMPAIGN = Path('/root/universal-tool-campaign-20260927')
ARCHIVE = CAMPAIGN / 'sources/libreoffice-25.2.7.2.tar.xz'
EXPORT = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool/validation/logs/libreoffice-fullblast-20261029')
OMKTR = ROOT / 'omktr'
JOBS = 32
ENV = dict(os.environ, PATH='/root/omktr-graph-optimizations/ninja-1.13.2:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', CC='/usr/bin/clang-18', CXX='/usr/bin/clang++-18', CCACHE_DISABLE='1', LC_ALL='C', TZ='UTC')
for key in list(ENV):
    if key.startswith(('KATI_', 'OMKTR_', 'MAKEFLAGS', 'MFLAGS', 'MAKELEVEL')) or key == 'MAKE':
        ENV.pop(key)
OPTIONS = ['--with-system-libs', '--without-system-libcmis', '--without-system-orcus', '--without-system-mdds', '--without-system-dragonbox', '--without-system-frozen', '--without-system-libfixmath', '--without-system-lpsolve', '--disable-skia', '--without-java', '--without-help', '--without-myspell-dicts', '--disable-ccache', '--disable-compiler-plugins', '--with-parallelism=32', '--with-external-tar=' + str(CAMPAIGN / 'lo-downloads'), '--with-vendor=OpenmktrBenchmark']
REPORT = {'status': 'preparing', 'revision': '38ddf6d0e4c8bee9e5449992ed1c412205d6e56c', 'jobs': JOBS, 'wsl_memory_limit_gib': 28, 'wsl_swap_limit_gib': 16, 'compiler_cache': 'disabled', 'filesystem_caches': 'warm/uncontrolled; no cache dropping', 'order': ['aggressive', 'gnu'], 'configure_options': OPTIONS, 'runs': {}, 'limits': ['One clean build per tool; no confidence interval.', 'Both use Clang 18; GNU means GNU Make, not a compiler change.', 'Selected desktop configuration excludes Java, Skia, help and bundled dictionaries.', 'Build timer includes Openmktr graph generation and recursive build work; configure and verification measured separately.']}
RETRY = '--retry-aggressive' in sys.argv
DIRECT = '--direct-aggressive' in sys.argv
if DIRECT:
    REPORT = json.loads((ROOT / 'report.json').read_text())
    shutil.copy2(ROOT / 'report.json', ROOT / 'report-before-direct-attempt.json')
    resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
    REPORT['direct_attempt'] = 'Fresh tree; direct executor with --graph_optimizations=aggressive -j32 and unlimited stack. Ninja failures retained separately.'
    REPORT['actual_execution_order'].append('aggressive-direct')
if RETRY:
    REPORT = json.loads((ROOT / 'report.json').read_text())
    shutil.copy2(ROOT / 'report.json', ROOT / 'report-before-stack-retry.json')
    for key in list(REPORT['runs']):
        if key.startswith('aggressive-'):
            REPORT['runs']['initial-failed-' + key] = REPORT['runs'].pop(key)
    for name in ['aggressive-configure', 'aggressive-bootstrap', 'aggressive-build', 'aggressive-source-integrity']:
        for suffix in ['.log', '.resources.jsonl']:
            path = ROOT / (name + suffix)
            if path.exists():
                path.rename(ROOT / ('initial-failed-' + name + suffix))
    (ROOT / 'aggressive').rename(ROOT / 'initial-failed-aggressive')
    resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
    REPORT['stack_retry'] = 'Fresh Aggressive tree with unlimited stack; original default-stack failure retained.'
    REPORT['actual_execution_order'] = ['top-level-aborted-diagnostic', 'aggressive-default-stack-failed', 'gnu', 'aggressive-unlimited-stack-retry']

def digest(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save():
    data = json.dumps(REPORT, indent=2)
    (ROOT / 'report.json').write_text(data)
    (EXPORT / 'report.json').write_text(data)

def memory():
    vals = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key, value = line.split(':', 1)
        vals[key] = int(value.strip().split()[0])
    return {key: vals[key] for key in ['MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree']}

def run(label, command, cwd, env=ENV):
    REPORT['status'] = label
    save()
    before = memory()
    done = threading.Event()
    samples = []
    started = time.monotonic()
    def monitor():
        with (ROOT / (label + '.resources.jsonl')).open('w') as stream:
            while not done.is_set():
                sample = {'elapsed_seconds': time.monotonic() - started, **memory(), 'loadavg': Path('/proc/loadavg').read_text().strip()}
                samples.append(sample)
                stream.write(json.dumps(sample) + '\n')
                stream.flush()
                done.wait(2)
    with (ROOT / (label + '.log')).open('w') as log:
        log.write(json.dumps(command) + '\n')
        log.flush()
        child = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        thread = threading.Thread(target=monitor)
        thread.start()
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
        elapsed = time.monotonic() - started
        done.set()
        thread.join()
    result = {'command': command, 'cwd': str(cwd), 'exit_code': child.returncode, 'wall_seconds': elapsed, 'user_seconds': usage.ru_utime, 'system_seconds': usage.ru_stime, 'average_cpu_cores': (usage.ru_utime + usage.ru_stime) / elapsed, 'peak_single_process_rss_kib': usage.ru_maxrss, 'memory_before_kib': before, 'memory_after_kib': memory(), 'minimum_mem_available_kib': min(s['MemAvailable'] for s in samples), 'maximum_swap_used_kib': max(s['SwapTotal'] - s['SwapFree'] for s in samples), 'log': str(ROOT / (label + '.log'))}
    REPORT['runs'][label] = result
    shutil.copy2(ROOT / (label + '.log'), EXPORT / (label + '.log'))
    save()
    print(label, result['exit_code'], round(elapsed, 2), flush=True)
    return result

def main():
    REPORT['archive_sha256'] = digest(ARCHIVE)
    assert REPORT['archive_sha256'] == '21b38b7f429d305b229fb70f3294dd6ccd803f52dad0463d0923cdf143e9c8bd'
    REPORT['binary_sha256'] = digest(OMKTR)
    REPORT['versions'] = {name: subprocess.check_output(cmd, env=ENV, text=True, stderr=subprocess.STDOUT) for name, cmd in {'omktr': [str(OMKTR), '--version'], 'make': ['/usr/bin/make', '--version'], 'clang': ['/usr/bin/clang-18', '--version'], 'ninja': ['ninja', '--version'], 'kernel': ['uname', '-a'], 'cpu': ['lscpu']}.items()}
    REPORT['initial_memory_kib'] = memory()
    save()
    for lane in (['aggressive-direct'] if DIRECT else ['aggressive'] if RETRY else REPORT['order']):
        base = ROOT / lane
        base.mkdir(exist_ok=False)
        REPORT['status'] = lane + '-extract'
        save()
        with tarfile.open(ARCHIVE) as archive:
            archive.extractall(base, filter='data')
        source = base / 'libreoffice-25.2.7.2'
        build = base / 'build'
        build.mkdir()
        configured = run(lane + '-configure', [str(source / 'configure')] + OPTIONS, build)
        if configured['exit_code']:
            continue
        REPORT[lane + '_config_sha256'] = digest(build / 'config_host.mk')
        langs = re.search(r'^ALL_LANGS=(.*)$', (build / 'config_host_lang.mk').read_text(), re.M).group(1)
        tool = str(OMKTR) if lane != 'gnu' else '/usr/bin/make'
        prepared = run(lane + '-bootstrap', [tool, '-j32', 'MAKE=' + tool, 'ALL_LANGS=' + langs, 'bootstrap', 'fetch', 'install-gdb-printers'], build)
        if prepared['exit_code']:
            continue
        command = [tool] + (['build', '--graph_optimizations=aggressive'] if lane == 'aggressive' else ['--graph_optimizations=aggressive'] if lane == 'aggressive-direct' else []) + ['-j32', '-rs', '-f', str(source / 'Makefile.gbuild'), 'MAKE=' + tool, 'ALL_LANGS=' + langs, 'build']
        build_env = dict(ENV, SRCDIR=str(source), BUILDDIR=str(build), WORKDIR=str(build / 'workdir'))
        built = run(lane + '-build', command, build, build_env)
        if built['exit_code'] == 0:
            run(lane + '-noop', command, build, build_env)
            smoke = base / 'smoke'
            smoke.mkdir()
            (smoke / 'input.txt').write_text('Openmktr LibreOffice full-blast benchmark smoke test\n')
            soffice = build / 'instdir/program/soffice'
            check = run(lane + '-smoke', ['timeout', '120', str(soffice), '-env:UserInstallation=file://' + str(smoke / 'profile'), '--headless', '--convert-to', 'pdf', '--outdir', str(smoke), str(smoke / 'input.txt')], build)
            REPORT[lane + '_pdf_valid'] = check['exit_code'] == 0 and (smoke / 'input.pdf').exists() and (smoke / 'input.pdf').read_bytes().startswith(b'%PDF-')
            REPORT[lane + '_artifacts'] = {str(p.relative_to(build)): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in [build / 'instdir/program/soffice.bin', build / 'instdir/program/libmergedlo.so'] if p.exists()}
        run(lane + '-source-integrity', ['python3', str(EXPORT.parent.parent / 'verify_archive.py'), str(ARCHIVE), str(source)], build)
    candidate = 'aggressive-direct' if DIRECT else 'aggressive'
    good = all(REPORT['runs'].get(lane + '-build', {}).get('exit_code') == 0 and REPORT.get(lane + '_pdf_valid') and REPORT['runs'].get(lane + '-source-integrity', {}).get('exit_code') == 0 for lane in [candidate, 'gnu'])
    REPORT['status'] = ('complete-direct-only' if DIRECT else 'complete') if good else 'incomplete-or-failed'
    if good:
        aggressive = REPORT['runs'][candidate + '-build']['wall_seconds']
        gnu = REPORT['runs']['gnu-build']['wall_seconds']
        REPORT['comparison'] = {'candidate': candidate, 'aggressive_speedup_vs_gnu': gnu / aggressive, 'aggressive_time_reduction_percent': (gnu - aggressive) / gnu * 100}
    save()

if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        REPORT['status'] = 'harness-error'
        REPORT['error'] = repr(exc)
        save()
        raise
