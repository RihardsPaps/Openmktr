// FORK MODIFICATION NOTICE (2026)
// Track and validate incremental evaluation, include proofs and imported Ninja
// graphs. Changed by the Openmktr fork, maintained by Rihards Paps and Haralds
// Paps. Check stamp integrity before accepting regeneration state.
// Changed build execution, evaluation, or portability for this fork.
// Validate recursive reuse, regeneration inputs, and shared recipe budgets.
// Keep explanation checks from refreshing the regeneration stamp.
// Upstream material retains its Apache-2.0 terms. Fork modifications are
// covered by Mozilla Public License 2.0; see docs/LICENSING.md and NOTICE
// at the repository root. Original notices below remain applicable.

// Copyright 2016 Google Inc. All rights reserved
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// +build ignore

#include "regen.h"

#include <sys/stat.h>

#include <algorithm>
#include <future>
#include <memory>
#include <mutex>
#include <vector>

#include "fileutil.h"
#include "find.h"
#include "func.h"
#include "graph_optimization.h"
#include "io.h"
#include "log.h"
#include "monitor.h"
#include "native_observation.h"
#include "ninja.h"
#include "stats.h"
#include "strutil.h"

namespace {

#define RETURN_TRUE              \
  do {                           \
    if (g_flags.dump_kati_stamp) \
      needs_regen_ = true;       \
    else                         \
      return true;               \
  } while (0)

bool ShouldIgnoreDirty(std::string_view s) {
  Pattern pat(g_flags.ignore_dirty_pattern ? g_flags.ignore_dirty_pattern : "");
  Pattern nopat(
      g_flags.no_ignore_dirty_pattern ? g_flags.no_ignore_dirty_pattern : "");
  return pat.Match(s) && !nopat.Match(s);
}

class StampChecker {
  struct GlobResult {
    std::string pat;
    std::vector<std::string> result;
  };

  struct ShellResult {
    CommandOp op;
    std::string shell;
    std::string shellflag;
    std::string cmd;
    std::string result;
    std::vector<std::string> missing_dirs;
    std::vector<std::string> files;
    std::vector<std::string> read_dirs;
  };

 public:
  StampChecker() : needs_regen_(false) {}

  ~StampChecker() {
    for (GlobResult* gr : globs_) {
      delete gr;
    }
    for (ShellResult* sr : commands_) {
      delete sr;
    }
  }

  bool NeedsRegen(double start_time, const std::string& orig_args) {
    if (IsMissingOutputs())
      RETURN_TRUE;

    COLLECT_STATS("stamp validation");
    if (CheckStep1(orig_args))
      RETURN_TRUE;

    if (CheckStep2())
      RETURN_TRUE;

    if (!monitor_checkpoint_.empty() &&
        !MonitorCheckpointValid(monitor_checkpoint_)) {
      LOG_STAT("monitor fallback: changes during stamp validation");
      RETURN_TRUE;
    }

    if (!needs_regen_ && !g_flags.explain) {
      FILE* fp = OpenGraphStamp(GetNinjaStampFilename(), true);
      if (!fp)
        return true;
      ScopedFile sfp(fp);
      if (fseek(fp, 0, SEEK_SET) < 0)
        PERROR("fseek");
      size_t r = fwrite(&start_time, sizeof(start_time), 1, fp);
      CHECK(r == 1);
    }
    return needs_regen_;
  }

 private:
  bool IsMissingOutputs() {
    if (!Exists(GetNinjaFilename())) {
      fprintf(stderr, "%s is missing, regenerating...\n",
              GetNinjaFilename().c_str());
      return true;
    }
    if (!Exists(GetNinjaShellScriptFilename())) {
      fprintf(stderr, "%s is missing, regenerating...\n",
              GetNinjaShellScriptFilename().c_str());
      return true;
    }
    if (!Exists(GetEnvScriptFilename())) {
      fprintf(stderr, "%s is missing, regenerating...\n",
              GetEnvScriptFilename().c_str());
      return true;
    }
    return false;
  }

  bool CheckStep1(const std::string& orig_args) {
#define LOAD_INT(fp)                                               \
  ({                                                               \
    int v = LoadInt(fp);                                           \
    if (v < 0 || v > 1000000) {                                    \
      fprintf(stderr, "incomplete kati_stamp, regenerating...\n"); \
      RETURN_TRUE;                                                 \
    }                                                              \
    v;                                                             \
  })

#define LOAD_STRING(fp, s)                                         \
  ({                                                               \
    if (!LoadString(fp, s)) {                                      \
      fprintf(stderr, "incomplete kati_stamp, regenerating...\n"); \
      RETURN_TRUE;                                                 \
    }                                                              \
  })

    const std::string& stamp_filename = GetNinjaStampFilename();
    FILE* fp = OpenGraphStamp(stamp_filename);
    if (!fp) {
      if (g_flags.regen_debug)
        printf("%s: %s\n", stamp_filename.c_str(), strerror(errno));
      return true;
    }
    ScopedFile sfp(fp);

    double gen_time = 0;
    size_t r = fread(&gen_time, sizeof(gen_time), 1, fp);
    gen_time_ = gen_time;
    if (r != 1) {
      fprintf(stderr, "incomplete kati_stamp, regenerating...\n");
      RETURN_TRUE;
    }
    char magic[4];
    if (fread(magic, 1, sizeof(magic), fp) != sizeof(magic) ||
        memcmp(magic, "KAT4", sizeof(magic)) != 0) {
      fprintf(stderr, "obsolete kati_stamp, regenerating...\n");
      RETURN_TRUE;
    }
    if (g_flags.regen_debug)
      printf("Generated time: %f\n", gen_time);

    int requires_evaluation = LOAD_INT(fp);
    if (requires_evaluation == 2) {
      std::string proof, configuration, arguments, path, identity;
      if (!g_flags.GraphOptimizationEnabled("includes") ||
          !ReadGraphCache(GetNinjaStampFilename() + ".includes", &proof))
        RETURN_TRUE;
      std::string_view view(proof);
      if (!ConsumeGraphString(&view, &configuration) ||
          !ConsumeGraphString(&view, &arguments) || arguments != orig_args ||
          configuration != g_flags.GraphOptimizationIdentity())
        RETURN_TRUE;
      while (!view.empty()) {
        if (!ConsumeGraphString(&view, &path) ||
            !ConsumeGraphString(&view, &identity) || identity == "unreadable" ||
            GetFileIdentity(path) != identity)
          RETURN_TRUE;
      }
    } else if (requires_evaluation != 0) {
      if (g_flags.explain)
        printf(
            "Makefile evaluation has observable effects or generated inputs; "
            "regenerating...\n");
      RETURN_TRUE;
    }

    std::string s, s2;
    if (LOAD_INT(fp) != 3)
      RETURN_TRUE;
    for (int i = 0; i < 3; ++i) {
      LOAD_STRING(fp, &s);
      LOAD_STRING(fp, &s2);
      if (s2 == "missing" || s2 == "unreadable" || GetFileIdentity(s) != s2) {
        if (g_flags.regen_debug)
          printf("generation artifact %s changed, regenerating...\n",
                 s.c_str());
        RETURN_TRUE;
      }
    }
    int num_files = LOAD_INT(fp);
    std::vector<std::string> paths(num_files), recorded(num_files);
    for (int i = 0; i < num_files; i++) {
      LOAD_STRING(fp, &paths[i]);
      LOAD_STRING(fp, &recorded[i]);
    }
    std::vector<std::string> identities;
    std::vector<double> timestamps;
    bool monitored =
        MonitorSnapshot(paths, &identities, &timestamps, &monitor_checkpoint_);
    if (!monitored)
      monitor_checkpoint_.clear();
    if (g_flags.GraphOptimizationEnabled("monitor"))
      LOG_STAT("monitor snapshots: %d accepted, %d ordinary fallbacks",
               monitored ? 1 : 0, monitored ? 0 : 1);
    if (g_flags.regen_debug && g_flags.GraphOptimizationEnabled("monitor"))
      printf("monitor: %s\n",
             monitored ? "validated snapshot" : "ordinary validation fallback");
    for (int i = 0; i < num_files; i++) {
      s = paths[i];
      s2 = recorded[i];
      const bool generated_artifact = s2.compare(0, 10, "generated:") == 0;
      if (generated_artifact)
        s2.erase(0, 10);
      struct stat st;
      const bool exists = !monitored && stat(s.c_str(), &st) == 0;
      const int stat_error = exists ? 0 : errno;
      double ts = monitored ? timestamps[i]
                  : exists  ? GetTimestampFromStat(st)
                            : -1;
      const std::string identity = monitored ? identities[i]
                                   : exists  ? GetFileIdentityFromStat(st)
                                   : stat_error == ENOENT ? "missing"
                                                          : "unreadable";
      // GetTimestamp returns < 0 when there's an error reading the file, like
      // when its been removed.
      const bool unchanged_missing = s2 == "missing" && identity == "missing";
      if (!unchanged_missing &&
          ((!generated_artifact && gen_time < ts) || ts < 0 || identity != s2 ||
           s2 == "unreadable")) {
        if (g_flags.regen_ignoring_kati_binary) {
          if (s == GetExecutablePath()) {
            fprintf(stderr, "%s was modified, ignored.\n", s.c_str());
            continue;
          }
        }
        if (ShouldIgnoreDirty(s)) {
          if (g_flags.regen_debug)
            printf("file %s: ignored (%f)\n", s.c_str(), ts);
          continue;
        }
        if (g_flags.dump_kati_stamp)
          printf("file %s: dirty (%f)\n", s.c_str(), ts);
        else
          fprintf(stderr, "%s was modified, regenerating...\n", s.c_str());
        RETURN_TRUE;
      } else if (g_flags.dump_kati_stamp) {
        printf("file %s: clean (%f)\n", s.c_str(), ts);
      }
    }

    int num_undefineds = LOAD_INT(fp);
    for (int i = 0; i < num_undefineds; i++) {
      LOAD_STRING(fp, &s);
      if (getenv(s.c_str())) {
        if (g_flags.dump_kati_stamp) {
          printf("env %s: dirty (unset => %s)\n", s.c_str(), getenv(s.c_str()));
        } else {
          fprintf(stderr, "Environment variable %s was set, regenerating...\n",
                  s.c_str());
        }
        RETURN_TRUE;
      } else if (g_flags.dump_kati_stamp) {
        printf("env %s: clean (unset)\n", s.c_str());
      }
    }

    int num_envs = LOAD_INT(fp);
    for (int i = 0; i < num_envs; i++) {
      LOAD_STRING(fp, &s);
      const char* val_c_str = getenv(s.c_str());
      std::string_view val(val_c_str ? val_c_str : "");
      LOAD_STRING(fp, &s2);
      if (val != s2) {
        if (g_flags.dump_kati_stamp) {
          printf("env %s: dirty (%s => %.*s)\n", s.c_str(), s2.c_str(),
                 SPF(val));
        } else {
          fprintf(stderr,
                  "Environment variable %s was modified (%s => %.*s), "
                  "regenerating...\n",
                  s.c_str(), s2.c_str(), SPF(val));
        }
        RETURN_TRUE;
      } else if (g_flags.dump_kati_stamp) {
        printf("env %s: clean (%.*s)\n", s.c_str(), SPF(val));
      }
    }

    int num_globs = LOAD_INT(fp);
    std::string pat;
    for (int i = 0; i < num_globs; i++) {
      GlobResult* gr = new GlobResult;
      globs_.push_back(gr);

      LOAD_STRING(fp, &gr->pat);
      int num_files = LOAD_INT(fp);
      gr->result.resize(num_files);
      for (int j = 0; j < num_files; j++) {
        LOAD_STRING(fp, &gr->result[j]);
      }
    }

    int num_crs = LOAD_INT(fp);
    for (int i = 0; i < num_crs; i++) {
      ShellResult* sr = new ShellResult;
      commands_.push_back(sr);
      sr->op = static_cast<CommandOp>(LOAD_INT(fp));
      LOAD_STRING(fp, &sr->shell);
      LOAD_STRING(fp, &sr->shellflag);
      LOAD_STRING(fp, &sr->cmd);
      LOAD_STRING(fp, &sr->result);

      std::string file;
      // Ignore debug info
      LOAD_STRING(fp, &file);
      LOAD_INT(fp);

      if (sr->op == CommandOp::FIND) {
        int num_missing_dirs = LOAD_INT(fp);
        for (int j = 0; j < num_missing_dirs; j++) {
          LOAD_STRING(fp, &s);
          sr->missing_dirs.push_back(s);
        }
        int num_files = LOAD_INT(fp);
        for (int j = 0; j < num_files; j++) {
          LOAD_STRING(fp, &s);
          sr->files.push_back(s);
        }
        int num_read_dirs = LOAD_INT(fp);
        for (int j = 0; j < num_read_dirs; j++) {
          LOAD_STRING(fp, &s);
          sr->read_dirs.push_back(s);
        }
      }
    }

    LoadString(fp, &s);
    if (orig_args != s) {
      fprintf(stderr, "arguments changed, regenerating...\n");
      RETURN_TRUE;
    }

    return needs_regen_;
  }

  bool CheckGlobResult(const GlobResult* gr, std::string* err) {
    COLLECT_STATS("glob time (regen)");
    const auto& files = Glob(gr->pat);
    bool needs_regen = files.size() != gr->result.size();
    for (size_t i = 0; i < gr->result.size(); i++) {
      if (!needs_regen) {
        if (files[i] != gr->result[i]) {
          needs_regen = true;
          break;
        }
      }
    }
    if (needs_regen) {
      if (ShouldIgnoreDirty(gr->pat)) {
        if (g_flags.dump_kati_stamp) {
          printf("wildcard %s: ignored\n", gr->pat.c_str());
        }
        return false;
      }
      if (g_flags.dump_kati_stamp) {
        printf("wildcard %s: dirty\n", gr->pat.c_str());
      } else {
        *err = StringPrintf("wildcard(%s) was changed, regenerating...\n",
                            gr->pat.c_str());
      }
    } else if (g_flags.dump_kati_stamp) {
      printf("wildcard %s: clean\n", gr->pat.c_str());
    }
    return needs_regen;
  }

  bool CheckShellResult(const ShellResult* sr, std::string* err) {
    if (sr->op == CommandOp::READ_MISSING) {
      struct stat metadata;
      if (stat(sr->cmd.c_str(), &metadata) == 0 || errno != ENOENT) {
        if (g_flags.dump_kati_stamp)
          printf("file %s: dirty\n", sr->cmd.c_str());
        else
          *err = StringPrintf("$(file <%s) was changed, regenerating...\n",
                              sr->cmd.c_str());
        return true;
      }
      if (g_flags.dump_kati_stamp)
        printf("file %s: clean\n", sr->cmd.c_str());
      return false;
    }

    if (sr->op == CommandOp::READ) {
      double ts = GetTimestamp(sr->cmd);
      if (ts < 0 || gen_time_ < ts) {
        if (g_flags.dump_kati_stamp)
          printf("file %s: dirty\n", sr->cmd.c_str());
        else
          *err = StringPrintf("$(file <%s) was changed, regenerating...\n",
                              sr->cmd.c_str());
        return true;
      }
      if (g_flags.dump_kati_stamp)
        printf("file %s: clean\n", sr->cmd.c_str());
      return false;
    }

    if (sr->op == CommandOp::WRITE || sr->op == CommandOp::APPEND) {
      FILE* f =
          fopen(sr->cmd.c_str(), (sr->op == CommandOp::WRITE) ? "wb" : "ab");
      if (f == NULL) {
        PERROR("fopen");
      }

      if (!sr->result.empty() && fwrite(sr->result.data(), 1, sr->result.size(),
                                        f) != sr->result.size()) {
        PERROR("fwrite");
      }

      if (fclose(f) != 0) {
        PERROR("fclose");
      }

      if (g_flags.dump_kati_stamp)
        printf("file %s: clean (write)\n", sr->cmd.c_str());
      return false;
    }

    FindCommand fc;
    if (fc.Parse(sr->cmd) && !fc.chdir.empty() && ShouldIgnoreDirty(fc.chdir)) {
      if (g_flags.dump_kati_stamp)
        printf("shell %s: ignored\n", sr->cmd.c_str());
      return false;
    }

    COLLECT_STATS_WITH_SLOW_REPORT("shell time (regen)", sr->cmd.c_str());
    std::string result;
    if (sr->op == CommandOp::FIND) {
      // Reexecute only the native interpreter. Directory timestamps cannot
      // certify negative matches, top-level membership or symlink searches.
      std::string packet;
      std::unique_ptr<FindCommand> descriptor;
      if (!QueryNativeFind(sr->cmd, &packet) ||
          !DecodeNativeFind(sr->cmd, packet, &result, &descriptor)) {
        *err = "native find validation uncertain, regenerating...\n";
        return true;
      }
    } else {
      RunCommand(sr->shell, sr->shellflag, sr->cmd, RedirectStderr::DEV_NULL,
                 &result);
      FormatForCommandSubstitution(&result);
    }
    if (sr->result != result) {
      if (g_flags.dump_kati_stamp) {
        printf("shell %s: dirty\n", sr->cmd.c_str());
      } else {
        *err = StringPrintf("$(shell %s) was changed, regenerating...\n",
                            sr->cmd.c_str());
        //*err += StringPrintf("%s => %s\n", expected.c_str(), result.c_str());
      }
      return true;
    } else if (g_flags.regen_debug) {
      printf("shell %s: clean (rerun)\n", sr->cmd.c_str());
    }
    return false;
  }

  bool CheckStep2() {
    auto glob_future = std::async([this]() {
      std::string err;
      // TODO: Make glob cache thread safe and create a task for each glob.
      for (GlobResult* gr : globs_) {
        if (CheckGlobResult(gr, &err)) {
          std::unique_lock<std::mutex> lock(mu_);
          if (!needs_regen_) {
            needs_regen_ = true;
            msg_ = err;
          }
          break;
        }
      }
    });

    auto shell_future = std::async([this]() {
      for (ShellResult* sr : commands_) {
        std::string err;
        if (CheckShellResult(sr, &err)) {
          std::unique_lock<std::mutex> lock(mu_);
          if (!needs_regen_) {
            needs_regen_ = true;
            msg_ = err;
          }
        }
      }
    });

    glob_future.wait();
    shell_future.wait();
    if (needs_regen_) {
      fprintf(stderr, "%s", msg_.c_str());
    }
    return needs_regen_;
  }

 private:
  double gen_time_;
  std::vector<GlobResult*> globs_;
  std::vector<ShellResult*> commands_;
  std::mutex mu_;
  bool needs_regen_;
  std::string msg_;
  std::string monitor_checkpoint_;
};

}  // namespace

bool NeedsRegen(double start_time, const std::string& orig_args) {
  return StampChecker().NeedsRegen(start_time, orig_args);
}
