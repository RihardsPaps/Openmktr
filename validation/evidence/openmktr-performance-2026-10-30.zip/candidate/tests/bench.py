#!/usr/bin/env python3
"""Repeatable conversion, regeneration, and execution measurements on Linux."""

import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import time


def end_to_end(binary: Path, repeats: int) -> dict:
    """Time complete invocations and retain paired phase samples.

    This is a synthetic copy workload, not a compiler or release benchmark.
    Setup, controlled edits, and output validation are outside the timers.
    """
    results = {}
    for scenario in ("clean", "noop", "single_file_change", "graph_change"):
        samples = []
        for _ in range(repeats + 2):
            with tempfile.TemporaryDirectory(prefix="omktr-e2e-") as temp:
                cwd = Path(temp)
                (cwd / "configure.py").write_text(
                    "from pathlib import Path\n"
                    "Path('config.mk').write_text('CONFIG := initial\\n')\n")
                (cwd / "Makefile").write_text(
                    "include config.mk\n.PHONY: all\nall: " +
                    " ".join(f"out{i}" for i in range(32)) + "\n" +
                    "".join(f"out{i}: src{i} config.mk\n\t@cp src{i} $@\n"
                            for i in range(32)))
                for i in range(32):
                    (cwd / f"src{i}").write_text(f"input {i}\n")
                configure = ["python3", "configure.py"]
                generate = [str(binary), "--ninja", "--regen", "-j4", "all"]
                execute = ["sh", "./ninja.sh", "-j4"]
                if scenario != "clean":
                    for command in (configure, generate, execute):
                        run(command, cwd)
                    # Advance beyond every output on coarse timestamp filesystems.
                    # Waiting and edits are deliberately excluded from measurement.
                    if scenario != "noop":
                        latest = max(p.stat().st_mtime_ns for p in cwd.iterdir())
                        while time.time_ns() <= latest + 1_000_000_000:
                            time.sleep(0.01)
                        if scenario == "single_file_change":
                            (cwd / "src0").write_text("changed input\n")
                        else:
                            (cwd / "config.mk").write_text("CONFIG := changed\n")
                before = {i: (cwd / f"out{i}").stat().st_mtime_ns
                          for i in range(32)} if scenario != "clean" else {}
                graph_before = ((cwd / "build.ninja").stat().st_mtime_ns
                                if scenario != "clean" else None)
                phases = {}
                start = time.perf_counter()
                if scenario == "clean":
                    phases["configuration"] = run(configure, cwd)[0]
                phases["graph_generation" if scenario == "clean" else
                       "regeneration"] = run(generate, cwd)[0]
                phases["recipe_execution"] = run(execute, cwd)[0]
                phases["end_to_end"] = time.perf_counter() - start
                graph_after = (cwd / "build.ninja").stat().st_mtime_ns
                if scenario in ("noop", "single_file_change"):
                    assert graph_after == graph_before
                elif scenario == "graph_change":
                    assert graph_after > graph_before
                for i in range(32):
                    assert (cwd / f"out{i}").read_bytes() == (cwd / f"src{i}").read_bytes()
                    if scenario == "noop" or (scenario == "single_file_change" and i):
                        assert (cwd / f"out{i}").stat().st_mtime_ns == before[i]
                    elif scenario != "clean":
                        assert (cwd / f"out{i}").stat().st_mtime_ns > before[i]
                samples.append(phases)
        samples = samples[2:]
        results[scenario] = {
            "samples_seconds": samples,
            "median_seconds": {phase: statistics.median(s[phase] for s in samples)
                               for phase in samples[0]},
        }
    return results


def run(command: list[str], cwd: Path) -> tuple[float, int]:
    start = time.perf_counter()
    env = {k: v for k, v in os.environ.items()
           if not k.startswith("KATI_") and k not in
           ("MAKEFLAGS", "MFLAGS", "MAKEOVERRIDES", "MAKELEVEL")}
    child = subprocess.Popen(command, cwd=cwd, env=env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _, status, usage = os.wait4(child.pid, 0)
    child.returncode = os.waitstatus_to_exitcode(status)
    if child.returncode:
        raise RuntimeError(f"Command failed with status {child.returncode}: {command}")
    return time.perf_counter() - start, usage.ru_maxrss


def measure(binary: Path, repeats: int) -> dict:
    with tempfile.TemporaryDirectory(prefix="kati-bench-") as temp:
        cwd = Path(temp)
        lines = [f"VAR{i} := value{i}\n" for i in range(10000)]
        lines += [f"target{i}:\n\t@:\n" for i in range(10000)]
        lines += ["all: " + " ".join(f"target{i}" for i in range(10000)) + "\n"]
        (cwd / "Makefile").write_text("".join(lines), encoding="utf-8")
        convert = [str(binary), "--ninja", "-f", "Makefile", "all"]
        regen = [str(binary), "--ninja", "--regen", "-f", "Makefile", "all"]
        run(regen, cwd)
        results = {}
        for name, command in (("convert", convert), ("noop_regen", regen)):
            samples = [run(command, cwd) for _ in range(repeats + 2)][2:]
            results[name] = {
                "median_seconds": statistics.median(value[0] for value in samples),
                "peak_rss_kib": max(value[1] for value in samples),
            }

        recipes = [".PHONY: all\nall: " + " ".join(f"job{i}" for i in range(16)) + "\n"]
        recipes += [f"job{i}:\n\t@sleep 0.05; touch $@\n" for i in range(16)]
        (cwd / "Makefile").write_text("".join(recipes), encoding="utf-8")
        execution = []
        for _ in range(repeats + 2):
            for output in cwd.glob("job[0-9]*"):
                output.unlink()
            execution.append(run([str(binary), "-j4", "-f", "Makefile", "all"], cwd))
        execution = execution[2:]
        results["parallel_exec"] = {
            "median_seconds": statistics.median(value[0] for value in execution),
            "peak_rss_kib": max(value[1] for value in execution),
        }

        nested = ["all: " + " ".join(f"group{i}" for i in range(4)) + "\n"]
        for group in range(4):
            nested.append(
                f"group{group}: " +
                " ".join(f"nested{group}-{job}" for job in range(4)) + "\n"
            )
        nested += [
            f"nested{group}-{job}:\n\t@sleep 0.05; touch $@\n"
            for group in range(4) for job in range(4)
        ]
        (cwd / "Makefile").write_text("".join(nested), encoding="utf-8")
        nested_samples = []
        for _ in range(repeats + 2):
            for output in cwd.glob("nested[0-9]*"):
                output.unlink()
            nested_samples.append(run([str(binary), "-j4", "all"], cwd))
        nested_samples = nested_samples[2:]
        results["nested_parallel_exec"] = {
            "median_seconds": statistics.median(value[0] for value in nested_samples),
            "peak_rss_kib": max(value[1] for value in nested_samples),
        }

        # Exclude graph generation and isolate recipe-launch overhead. Phony
        # jobs run on every invocation, including the discarded warmups.
        jobs = " ".join(f"launch{i}" for i in range(2000))
        (cwd / "Makefile").write_text(
            f".PHONY: all {jobs}\nall: {jobs}\n{jobs}:\n\t@:\n",
            encoding="utf-8",
        )
        run([str(binary), "--ninja", "all"], cwd)
        for mode, command in (("ninja", ["sh", "./ninja.sh"]),
                              ("direct", [str(binary)])):
            for job_count in (1, 4):
                samples = [run([*command, f"-j{job_count}"], cwd)
                           for _ in range(repeats + 2)][2:]
                results[f"{mode}_recipe_launch_j{job_count}"] = {
                    "median_seconds": statistics.median(value[0] for value in samples),
                    "peak_rss_kib": max(value[1] for value in samples),
                }

        chain = ["all: link99\n"]
        chain += ["link0:\n\t@touch $@\n"]
        chain += [f"link{i}: link{i - 1}\n\t@touch $@\n" for i in range(1, 100)]
        (cwd / "Makefile").write_text("".join(chain), encoding="utf-8")
        run([str(binary), "-j4", "all"], cwd)
        no_op = [run([str(binary), "-j4", "all"], cwd)
                 for _ in range(repeats + 2)][2:]
        results["incremental_noop"] = {
            "median_seconds": statistics.median(value[0] for value in no_op),
            "peak_rss_kib": max(value[1] for value in no_op),
        }
        results["binary_bytes"] = binary.stat().st_size
        results["end_to_end"] = end_to_end(binary, repeats)
        return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("binary", type=Path)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    binary = args.binary.resolve()
    report = {"current": measure(binary, args.repeats)}
    if args.baseline:
        report["baseline"] = measure(args.baseline.resolve(), args.repeats)
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
