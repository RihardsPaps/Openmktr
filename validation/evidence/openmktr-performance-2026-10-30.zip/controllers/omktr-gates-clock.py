from pathlib import Path
import subprocess,json
E=Path('/root/openmktr-implemented-20261030')
active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 q=subprocess.run(['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-implemented-gates.py'])
finally:
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 (E/'gate-clock-control.json').write_text(json.dumps(dict(original_active=active,restored_active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0)))
raise SystemExit(q.returncode)
