from pathlib import Path
import shutil,subprocess,json
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-speed-implementation'
if not D.exists():shutil.copytree(C/'omktr-speed-no-memo',D)
for p in (R/'src').iterdir():
 if p.is_file():(D/'src'/p.name).write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
for p in (R/'tests').iterdir():
 if p.is_file():shutil.copy2(p,D/'tests'/p.name)
for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
files='src/dep.cc src/flags.cc src/incremental_eval.cc src/incremental_eval.h src/command.cc src/expr.cc src/expr.h src/graph_optimization.cc src/graph_optimization.h src/symtab.cc src/ninja.cc src/exec.cc'
commands=['clang-format -i '+files,'ninja -j32 omktr tests','python tests/generated_recipe_reads.py','python tests/graph_optimizations.py']
results=[]
for i,cmd in enumerate(commands):
 with (D/('speed-check-'+str(i)+'.log')).open('w') as log:r=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && '+cmd],stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':r.returncode});(D/'speed-checks.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True)
 if r.returncode:break
for f in files.split():shutil.copy2(D/f,R/f)