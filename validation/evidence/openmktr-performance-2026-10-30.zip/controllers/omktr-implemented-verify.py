from pathlib import Path
import subprocess,json,sys,os,hashlib,re,time
E=Path('/root/openmktr-implemented-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
sys.path.insert(0,str(R/'validation'))
from compare_libreoffice_outputs import compare
active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
results={}
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 for name in ('pair1','pair2'):
  p=E/name;result=compare(p/'gnu',p/'aggressive');(p/'installed-comparison.json').write_text(json.dumps(result,indent=2))
  print(name,'comparison:',{k:(len(v) if isinstance(v,list) else v) for k,v in result.items() if k!='objects'},flush=True)
  print(name,'objects:',{k:(len(v) if isinstance(v,list) else v) for k,v in result['objects'].items()},flush=True)
  subprocess.run(['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-implemented-output-control.py',name],check=True)
  control=json.loads((p/'gnu-same-path-v18.json').read_text());assert control['pass'] and all(control['measured_tree_intact'].values()) and control['source_pristine_after_control']
  results[name]=dict(comparison_pass=True,control_pass=True)
  (E/'output-verification.json').write_text(json.dumps(results,indent=2))
 # Verify prefix compaction against the same graph with literal paths.
 p=E/'pair1';build=p/'aggressive/build';graph=build/'.openmktr/build.ninja';data=graph.read_bytes()
 prefixes=re.findall(rb'^(omktr_path_[0-9]+) = ([^\n]+)$',data,re.M);assert prefixes
 expanded=data
 for key,value in prefixes:expanded=expanded.replace(b'${'+key+b'}',value)
 plain=p/'graph-expanded.ninja';plain.write_bytes(expanded)
 graphs={}
 for name,path in [('compact',graph),('expanded',plain)]:
  target=p/(name+'-targets.txt');start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
  with target.open('wb') as f:
   child=subprocess.Popen(['/root/omktr-graph-optimizations/ninja-1.13.2/ninja','-j32','-f',str(path),'-t','targets','all'],cwd=build,stdout=f,stderr=subprocess.PIPE)
   _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
   assert child.returncode==0,child.stderr.read()
  graphs[name]=dict(bytes=path.stat().st_size,seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,rss_kib=usage.ru_maxrss,target_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),target_lines=sum(1 for _ in target.open('rb')))
 assert graphs['compact']['target_sha256']==graphs['expanded']['target_sha256']
 (E/'graph-compaction.json').write_text(json.dumps(graphs,indent=2));print('Graph compaction verified',graphs,flush=True)
finally:
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 (E/'verification-clock-control.json').write_text(json.dumps(dict(original_active=active,restored_active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0)))
