from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
E=Path('/root/openmktr-implemented-20261030')/sys.argv[1]
P=E; lane=P/'aggressive'; original=lane/'build'; control=E/'gnu-same-path-control'
comparison=E/'installed-comparison.json'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def record(p):
    s=p.stat();return dict(sha256=sha(p),mtime_ns=s.st_mtime_ns,size=s.st_size,inode=s.st_ino)
if '--inner' not in sys.argv:
    d=json.loads(comparison.read_text()); objects=d['objects']['different']; libraries=d['different']
    if d['missing'] or d['extra'] or d['objects']['missing'] or d['objects']['extra']:raise RuntimeError('Entry sets differ')
    for n in libraries:
        with (original/'instdir'/n).open('rb') as f:
            if f.read(4)!=b'\x7fELF':raise RuntimeError('Unexplained non-ELF: '+n)
    if any(d.get('unsupported_entries',{}).values()):raise RuntimeError('Unsupported installed entries')
    if d.get('mode_differences') or any(d.get('directories',{}).get(k) for k in ('missing','extra','mode_differences')):raise RuntimeError('Installed entry modes or directories differ')
    sys.path.insert(0,'/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool/validation')
    from benchmark_libreoffice import output_state
    tracked_before=output_state(original)
    (E/'gnu-same-path-v18-measured-before.json').write_text(json.dumps(tracked_before,indent=2))
    expected=dict(objects={n:record(original/'workdir'/n) for n in objects},libraries={n:record(original/'instdir'/n) for n in libraries})
    (E/'gnu-same-path-v18-request.json').write_text(json.dumps(expected,indent=2))
    if control.exists():raise RuntimeError('Control exists; refusing overwrite')
    print('Copying candidate build for isolated same-path GNU rebuild',flush=True)
    shutil.copytree(original,control,symlinks=True)
    command=['unshare','-m',sys.executable,__file__,sys.argv[1],'--inner']
    run=subprocess.run(command)
    intact={kind:all(record(original/('workdir' if kind=='objects' else 'instdir')/n)==r for n,r in entries.items()) for kind,entries in expected.items()}
    tracked_after=output_state(original)
    (E/'gnu-same-path-v18-measured-after.json').write_text(json.dumps(tracked_after,indent=2))
    intact['all_tracked_outputs']=tracked_before==tracked_after
    with (E/'gnu-same-path-v18-source-integrity.log').open('w') as f:
        source_check=subprocess.run(['python3','/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool/validation/verify_release_archive.py','/root/universal-tool-campaign-20260927/sources/libreoffice-25.2.7.2.tar.xz',str(lane/'libreoffice-25.2.7.2')],stdout=f,stderr=subprocess.STDOUT)
    result=json.loads((E/'gnu-same-path-v18.json').read_text());result['measured_tree_intact']=intact;result['source_pristine_after_control']=source_check.returncode==0
    assert source_check.returncode==0
    (E/'gnu-same-path-v18.json').write_text(json.dumps(result,indent=2))
    if run.returncode or not all(intact.values()):raise SystemExit(1)
else:
    subprocess.run(['mount','--make-rprivate','/'],check=True)
    subprocess.run(['mount','--bind',str(control),str(original)],check=True)
    expected=json.loads((E/'gnu-same-path-v18-request.json').read_text())
    before={n:record(original/'instdir'/n) for n in expected['libraries']}
    report=json.loads((P/'report.json').read_text()); source=lane/'libreoffice-25.2.7.2'
    langs=next(a for a in report['runs']['gnu-build']['command'] if a.startswith('ALL_LANGS='))
    command=['/usr/bin/make','-j32','-rs','-f',str(source/'Makefile.gbuild'),'MAKE=/usr/bin/make',langs,'build']
    env=dict(os.environ,**report['environment'],SRCDIR=str(source),BUILDDIR=str(original),WORKDIR=str(original/'workdir'))
    for key in list(env):
        if key.startswith(('KATI_','OMKTR_','MAKEFLAGS','MFLAGS','MAKELEVEL')) or key=='MAKE':env.pop(key)
    for name in expected['objects']:
        path=(original/'workdir'/name).resolve()
        if not path.is_relative_to(original/'workdir'):raise RuntimeError('Unsafe object path')
        path.unlink()
    start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
    with (E/'gnu-same-path-v18.log').open('w') as f:
        f.write(json.dumps(command)+'\n');f.flush();run=subprocess.run(command,cwd=original,env=env,stdout=f,stderr=subprocess.STDOUT)
    result=dict(exit_code=run.returncode,command=command,cwd=str(original),wall_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,objects={},libraries={})
    for kind,entries in expected.items():
        folder=original/('workdir' if kind=='objects' else 'instdir')
        for name,wanted in entries.items():
            path=folder/name;actual=record(path) if path.exists() else None
            result[kind][name]=dict(expected=wanted,actual=actual,identical=bool(actual and wanted['sha256']==actual['sha256']))
            if kind=='libraries':result[kind][name]['relinked']=bool(actual and actual['mtime_ns']!=before[name]['mtime_ns'])
    result['pass']=run.returncode==0 and all(v['identical'] and (v.get('relinked',True)) for kind in ('objects','libraries') for v in result[kind].values())
    (E/'gnu-same-path-v18.json').write_text(json.dumps(result,indent=2))
    print('Same-path GNU control:',result['pass'],len(result['objects']),len(result['libraries']),flush=True)
    raise SystemExit(0 if result['pass'] else 1)
