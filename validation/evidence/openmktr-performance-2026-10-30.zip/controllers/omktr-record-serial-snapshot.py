from pathlib import Path
import subprocess,json,shutil
C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-speed-implementation';E=Path('/root/openmktr-implemented-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
for a,b in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/b).is_mount():subprocess.run(['mount','--bind',a,str(C/b)],check=True)
active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
before=json.loads((R/'tests/golden.json').read_text())
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 with (E/'snapshot-record.log').open('w') as f:q=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && python tests/regression.py --record'],stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0
 after=json.loads((D/'tests/golden.json').read_text());changed={k:dict(before=before.get(k),after=after.get(k)) for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
 print(json.dumps(changed,indent=2),flush=True)
 assert set(changed)=={'rule_with_extra_ws.mk:test:direct'}
 assert changed['rule_with_extra_ws.mk:test:direct']['after']==dict(status=0,output='  BUILD   foo\nPASS_foo\n  BUILD   bar\nPASS_foo\n',files=[])
 (E/'snapshot-change.json').write_text(json.dumps(changed,indent=2));shutil.copy2(D/'tests/golden.json',R/'tests/golden.json')
finally:
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
