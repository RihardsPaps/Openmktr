from pathlib import Path
import subprocess,shutil,json,shlex,time,hashlib
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-speed-implementation';E=Path('/root/openmktr-implemented-20261030');E.mkdir(exist_ok=True)
names=subprocess.check_output(['git','ls-files','-z','tests','testcase','tools','validation'],cwd=R).decode().split('\0')
# Include new focused suites that have not been committed yet.
names += [str(p.relative_to(R)) for p in (R/'tests').glob('*.py')]
for name in set(names):
 if not name or '/logs/' in name or '/evidence/' in name:
  continue
 p=R/name
 if p.is_file():
  q=D/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ('README.md','CONTRIBUTING.md','Dockerfile','clang-format-check'):
 shutil.copy2(R/name,D/name)
for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
normal=['out/'+n+'_test' for n in ('find','ninja','strutil','load_limit')]
normal += ['python tests/'+n+'.py' for n in ('version_generator','correctness','generated_recipe_reads','graph_optimizations','make_compat_regressions','portage','manager','manager_terminal','load_limits','portage_validation','cross_version_cache','ninja_benchmark','workspace','ninja_jobserver','release_packaging','regression')]
normal += ['OMKTR_TEST_GRAPH_PROFILE=aggressive python tests/'+n+'.py' for n in ('correctness','regression')]+['sh testcase/dump/run.sh']
normal += ['python tools/gen_sanitizer_build.py','ninja -f build.sanitizer.ninja -j32 omktr-sanitized tests']
commands=normal+['ASAN_OPTIONS=detect_leaks=0 out/sanitized/'+n+'_test' for n in ('find','ninja','strutil','load_limit')]
commands += ['ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY=/omktr-speed-implementation/omktr-sanitized python tests/'+n+'.py' for n in ('portage','load_limits','correctness','generated_recipe_reads','graph_optimizations','workspace','ninja_jobserver','make_compat_regressions')]
commands += ['ASAN_OPTIONS=detect_leaks=0 OMKTR_TEST_GRAPH_PROFILE=aggressive OMKTR_BINARY=/omktr-speed-implementation/omktr-sanitized python tests/correctness.py']
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic()
 with (E/f'check-{i:02}.log').open('w') as log:run=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && '+cmd],stdout=log,stderr=subprocess.STDOUT)
 result=dict(command=cmd,exit_code=run.returncode,seconds=time.monotonic()-start,log=f'check-{i:02}.log');results.append(result);(E/'checks.json').write_text(json.dumps(results,indent=2));print(result,flush=True)
 if run.returncode:raise SystemExit(run.returncode)
P=Path('/root/libreoffice-improvements-20261029')
lines=subprocess.check_output(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && ninja -t commands omktr'],text=True).splitlines()
link=shlex.split(lines[-1]);link=link[:link.index('-o')]+['-Wl,--dynamic-linker='+str(P/'runtime/libc.so'),'-Wl,-rpath,'+str(P/'runtime'),'-o','omktr-host']
subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && '+shlex.join(link)],check=True)
shutil.copy2(D/'omktr-host',E/'omktr-candidate18')
(E/'binary.json').write_text(json.dumps(dict(link=link,sha256=hashlib.sha256((E/'omktr-candidate18').read_bytes()).hexdigest()),indent=2))
print('ALL GATES PASSED; host binary ready',flush=True)

