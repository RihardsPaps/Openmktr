from pathlib import Path
import subprocess
C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');E=Path('/root/openmktr-implemented-20261030')
for a,b in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/b).is_mount():subprocess.run(['mount','--bind',a,str(C/b)],check=True)
for name,binary in [('before','omktr-sanitized'),('after','omktr')]:
 with (E/('serial-order-'+name+'.log')).open('w') as f:
  q=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-speed-implementation && ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY=/omktr-speed-implementation/'+binary+' python tests/correctness.py -k one_job_preserves'],stdout=f,stderr=subprocess.STDOUT)
 print(name,q.returncode,flush=True)
