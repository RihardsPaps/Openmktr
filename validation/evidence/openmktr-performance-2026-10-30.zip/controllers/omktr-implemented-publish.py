from pathlib import Path
import json,statistics,hashlib,shutil,difflib,zipfile,subprocess,re
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E=Path('/root/openmktr-implemented-20261030');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete/omktr-speed-implementation')
name='openmktr-performance-2026-10-30';reports={k:json.loads((E/k/'report.json').read_text()) for k in ('pair1','pair2')}
verify=json.loads((E/'output-verification.json').read_text());assert len(verify)==2 and all(v['control_pass'] for v in verify.values())
graph=json.loads((E/'graph-compaction.json').read_text());checks=json.loads((E/'checks.json').read_text());assert len(checks)==38 and all(v['exit_code']==0 for v in checks)
controller=json.loads((E/'controller.json').read_text());assert controller['pass'] and controller['restored_timesync_active']
windows=json.loads(Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-implemented-windows-timing.json').read_text());assert windows['exit_code']==0
runtime=json.loads((E/'runtime-ab.json').read_text());runtime_summary={k:{f:statistics.median(s[f] for s in v) for f in ('wall_seconds','cpu_seconds')} for k,v in runtime.items()}
rows=[]
for pair,r in reports.items():
 assert r['lanes']['gnu']['normalized_config_sha256']==r['lanes']['aggressive']['normalized_config_sha256']
 assert all(v['exit_code']==0 and not v['clock_validation']['realtime_discontinuities_seconds'] for v in r['runs'].values())
 for lane in r['lanes'].values():assert len(lane['repeat_checks'])==3 and not any(v['blocking_changes'] for v in lane['repeat_checks'])
 g=r['runs']['gnu-build']['wall_seconds'];o=r['runs']['aggressive-build']['wall_seconds'];rows.append(dict(pair=pair,order=r['comparison_lanes'],gnu_seconds=g,openmktr_seconds=o,gap_percent=100*(o/g-1)))
g=statistics.mean(x['gnu_seconds'] for x in rows);o=statistics.mean(x['openmktr_seconds'] for x in rows);old_g=834.112046784;old_o=960.2232783;old_gap=old_o/old_g-1;gap=o/g-1
aggregate=dict(gnu_mean_seconds=g,openmktr_mean_seconds=o,remaining_gap_seconds=o-g,remaining_gap_percent=gap*100,historical_gap_percent=old_gap*100,percentage_points_closed=100*(old_gap-gap),percentage_gap_closed=100*(old_gap-gap)/old_gap,candidate_seconds_saved_vs_historical=old_o-o,candidate_percent_faster_vs_historical=100*(old_o-o)/old_o)
source_manifest={}
for p in (R/'src').iterdir():
 if p.is_file():
  normalized=p.read_bytes().replace(b'\r\n',b'\n');assert normalized==(C/'src'/p.name).read_bytes(),p
  source_manifest['src/'+p.name]=hashlib.sha256(normalized).hexdigest()
(E/'source-sha256.json').write_text(json.dumps(source_manifest,indent=2))
# Capture the exact changes relative to the qualified v17 source, independent of pre-existing worktree edits.
base=Path('/root/libreoffice-improvements-20261029/candidate-v17-source');diff=[]
for folder in ('src','tests'):
 for p in (R/folder).iterdir():
  q=base/folder/p.name
  if p.is_file() and q.is_file():
   try:a=q.read_text();b=p.read_text()
   except UnicodeError:continue
   if a!=b:diff.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='baseline/'+folder+'/'+p.name,tofile='candidate/'+folder+'/'+p.name))
(E/'implementation.patch').write_text(''.join(diff))
summary=dict(status='verified',date='2026-10-30',jobs=32,wsl_memory_gib=30,wsl_swap_gib=16,baseline_historical=dict(gnu_seconds=old_g,openmktr_seconds=old_o,binary_sha256='e551c7fa3f7e6056d39ebdf864b64cdae1a8ec29d7ae81b3b4451694d0da1d59'),candidate=json.loads((E/'binary.json').read_text()),pairs=rows,aggregate=aggregate,checks=checks,extra_checks=json.loads((E/'extra-checks.json').read_text()),runtime_fixture=dict(jobs=32,recipes_per_batch=256,batches_per_binary=4,verified_outputs=2048,medians=runtime_summary,samples=runtime),graph_compaction=graph,clock=dict(linux_raw_seconds=controller['raw_elapsed_seconds'],windows_stopwatch_seconds=windows['seconds'],difference_seconds=windows['seconds']-controller['raw_elapsed_seconds'],realtime_discontinuities=0),source_manifest=source_manifest,local_evidence=str(E),benchmark={})
for pair,r in reports.items():
 control=json.loads((E/pair/'gnu-same-path-v18.json').read_text());assert control['pass'] and all(control['measured_tree_intact'].values()) and control['source_pristine_after_control']
 comparison=json.loads((E/pair/'installed-comparison.json').read_text())
 summary['benchmark'][pair]=dict(runs=r['runs'],configuration=r['configure_options'],versions=r['versions'],lanes={k:{field:v[field] for field in ('normalized_config_sha256','configure_through_build_seconds','repeat_checks')} for k,v in r['lanes'].items()},artifact_comparison=comparison,same_path_control=control)
summary['synthetic_bench']=json.loads((E/'bench-j32.log').read_text())
summary['restoration']=json.loads((E/'restoration.json').read_text())
assert summary['restoration']['config_sha256']==summary['restoration']['original_config_sha256'] and summary['restoration']['timesync_active']
(R/'validation/openmktr-performance-results.json').write_text(json.dumps(summary,indent=2)+'\n')
repeat_rows='\n'.join('| '+pair+' | '+('GNU' if lane=='gnu' else 'Openmktr')+' | '+' | '.join(f"{r['runs'][lane+'-noop-'+str(i)]['wall_seconds']:.3f}" for i in (1,2,3))+' |' for pair,r in reports.items() for lane in ('gnu','aggressive'))
clean_rows='\n'.join(f"| {x['pair']} ({'GNU first' if x['order'][0]=='gnu' else 'Openmktr first'}) | {x['gnu_seconds']:.3f} | {x['openmktr_seconds']:.3f} | +{x['gap_percent']:.2f}% |" for x in rows)
peak=max(v['peak_individual_rss_kib'] for r in reports.values() for k,v in r['runs'].items() if k.startswith('aggressive-noop'))/1024**2
cpu_g=statistics.mean(r['runs']['gnu-build']['user_seconds']+r['runs']['gnu-build']['system_seconds'] for r in reports.values());cpu_o=statistics.mean(r['runs']['aggressive-build']['user_seconds']+r['runs']['aggressive-build']['system_seconds'] for r in reports.values())
text=f'''# Openmktr performance implementation and full comparison — 30 October 2026

Two fresh LibreOffice 25.2.7.2 pairs at **32 jobs and 30 GiB configured WSL RAM**
reduce the observed clean-build gap from **15.12% to {100*gap:.2f}%**. This closes
**{aggregate['percentage_gap_closed']:.1f}% of the historical percentage gap**.
Openmktr remains slower: the average difference is **{o-g:.3f} seconds**.
All four builds, twelve repeats, application smoke checks, source audits, and
cross-lane artifact controls passed. These are two samples per tool, not a
statistical confidence interval or a claim of universal Makefile compatibility.

## Complete clean-build results

| Fresh pair and order | GNU Make (s) | Openmktr Aggressive (s) | Openmktr overhead |
| --- | ---: | ---: | ---: |
{clean_rows}
| Mean | {g:.3f} | {o:.3f} | +{100*gap:.2f}% |

The historical pair was GNU **834.112 s**, Openmktr **960.223 s**. The new
Openmktr mean is **{old_o-o:.3f} s ({aggregate['candidate_percent_faster_vs_historical']:.2f}%) lower**.
The normalized closure is `(old overhead - new overhead) / old overhead`, where
overhead is `Openmktr / GNU - 1`; it is not the percentage reduction in total build
time. Both new pair ratios improve on the historical ratio. Filesystem caches
were not flushed; alternating order limits, but does not eliminate, order effects.

Each clean timer covers the complete build invocation, including Openmktr graph
preparation and execution. Configuration/bootstrap are recorded separately in the
JSON, as are configure-through-build totals. All lanes use fresh unmodified
release extractions, identical normalized configuration, Clang 18, disabled
ccache, Ninja 1.13.2 where applicable, and 32 jobs. The project binary itself is
built with the same Chimera Clang/LLVM 22.1.8, musl and libc++ toolchain as v17.
No NAS was accessed. Semantic tests retain deliberate limits such as `-j1`;
all performance and release workloads use the maximum 32 logical CPUs.

## Implemented changes

- Pattern-variable indexing has its own `pattern_index` control, independent of
  evaluation memoization. Recursive option transport and cache identities include it.
- Evaluation stops admitting low-yield records after 65,536 expression misses
  when hits are below roughly five percent. This works inside large includes and
  nested evals: enclosing certificates are invalidated while active scopes finish.
- Runtime contexts are read directly into the payload buffer. Variable fields
  are decoded through string views, and recursive expression ASTs are constructed
  lazily after structural validation. Checksums, corrupt-input rejection, variable
  origins/flavors, introspection, exports and effects remain checked.
- Long plain absolute path prefixes are factored through Ninja variables under
  `compact`. Escaping remains unchanged for other paths.
- Fixed a discovered direct-executor race at `-j1`: dependency traversal and root
  dispatch now use the serial path. The regression failed all 48 variations with
  the old sanitized binary and passed with the fix. One snapshot now places each
  recipe's output immediately after its command announcement; no crash was hidden.

## Correctness and repeat builds

| Pair | Tool | Repeat 1 (s) | Repeat 2 (s) | Repeat 3 (s) |
| --- | --- | ---: | ---: | ---: |
{repeat_rows}

All repeats preserve tracked installed files, objects, archives and ZIP outputs.
Only the existing permitted `setuprc`/`versionrc` metadata timestamp refreshes
occurred; contents, sizes and inodes remain unchanged. Guarded Ninja edges can be
visited without rebuilding their outputs. Repeat overhead is still much larger
than GNU's, despite improving on historical Openmktr repeats of 148.256, 110.122
and 109.958 seconds.

For **each pair**, installed entry sets, all 271 directory entries and permissions
match. Of 3,351 installed entries, 3,137 match directly, 195 ZIPs have identical
member payloads, and 9 debugger scripts match after lane-prefix normalization.
The remaining 10 ELF files and 193 of 9,507 compiler objects embed build paths.
An isolated mount-namespace control rebuilt them with GNU at the candidate's
exact paths: **all match byte for byte**, all ten ELF files were relinked, and the
measured candidate trees were unchanged. No differing entry was simply ignored.

Writer, Calc and Impress convert test inputs to PDFs with verified expected text
in all four lanes. Dynamic-library checks pass. Each lane's 147,364 original
source files/symlinks match the release archive; candidate sources also remain
pristine after the isolated GNU controls. The archive SHA-256 is
`21b38b7f429d305b229fb70f3294dd6ccd803f52dad0463d0923cdf143e9c8bd`.

## Focused measurements and remaining cost

The real-context fixture runs 256 recipes with 32 workers, four alternating
batches per binary, and verifies all 2,048 outputs. Median wall time falls from
**{runtime_summary['baseline']['wall_seconds']:.3f} to {runtime_summary['candidate']['wall_seconds']:.3f} s**;
median child CPU time falls from **{runtime_summary['baseline']['cpu_seconds']:.2f} to {runtime_summary['candidate']['cpu_seconds']:.2f} CPU-s**.
This is an isolated context-loading result, not a full-build speedup.

On the same final graph, compact paths use **{graph['compact']['bytes']/1e6:.1f} MB**
versus **{graph['expanded']['bytes']/1e6:.1f} MB** with literal prefixes. Ninja emits
identical complete target listings ({graph['compact']['target_lines']:,} lines).
The compact query took {graph['compact']['seconds']:.3f} s with
{graph['compact']['rss_kib']/1024:.1f} MiB peak RSS; the expanded query took
{graph['expanded']['seconds']:.3f} s with {graph['expanded']['rss_kib']/1024:.1f} MiB.
This single observation shows a storage reduction, little RSS improvement and
slower graph loading; it is not credited as a speed improvement.

The same-toolchain `tests/bench.py` comparison passed using a disposable copy
with every performance job limit set to 32. It does not establish a broad speedup:
small synthetic conversion medians were 0.0982 s baseline and 0.1025 s candidate.
All samples are retained. Peak individual repeat RSS is **{peak:.3f} GiB**, down
from the historical 12.783 GiB, but still above the earlier 8-GiB objective.
The graph remains above 200 MB and clean execution remains slower than GNU.
Mean clean child CPU totals are {cpu_g:.1f} CPU-s for GNU and {cpu_o:.1f} CPU-s
for Openmktr; the remaining gap therefore includes extra CPU work as well as
less effective parallel use. These totals alone do not isolate the next bottleneck.

## Validation and evidence

The local Chimera normal and ASan/UBSan gates pass, including direct/Ninja
correctness, recursive execution, exports, regeneration, jobserver/cancellation,
42 runtime-recipe tests, 55 graph tests, and both 858-scenario snapshot profiles
with zero quarantined crashes. The new nested-admission, malformed-unused-expression,
context corruption, absolute-path and serial-order checks pass. Changed C++
formatting, the incremental-campaign harness and the external 32-job GNU
differential incremental campaign pass; the latter reports no release blockers
or performance defects.

Docker's Linux daemon is unavailable, so the Docker container gate was not run.
The GitHub integration returned no PR-triggered CI runs for current commit
`38ddf6d0e4c8bee9e5449992ed1c412205d6e56c`; no remote CI pass is claimed.

Timed runs temporarily paused guest time synchronization. Every measured phase
uses `CLOCK_MONOTONIC_RAW` and records realtime observations: **zero clock jumps**.
The entire controller measured {controller['raw_elapsed_seconds']:.3f} s locally
versus {windows['seconds']:.3f} s on Windows Stopwatch. Both lanes had the same
30-GiB allocation and 16-GiB swap configuration; peak observed swap usage was
0 KiB in pair 1 and 96 KiB in pair 2. Original WSL configuration and time-service
state were restored afterward.

Candidate binary SHA-256:
`{summary['candidate']['sha256']}`.

- [Machine-readable results](../validation/openmktr-performance-results.json)
- [Evidence archive](../validation/evidence/{name}.zip)
- [Archive SHA-256](../validation/evidence/{name}.zip.sha256)
- [Prior investigation](openmktr-speed-investigation-2026-10-30.md)

Raw release trees, binaries, graphs and runtime contexts remain on this PC under
`{E}`. The archive contains selected logs, results, controller scripts, source
hashes and the v17-to-candidate patch. It excludes full runtime contexts and raw
process environments. The working tree's pre-existing edits are preserved.
'''
(R/'docs'/f'{name}.md').write_text(text)
p=R/'docs/ninja-performance.md';s=p.read_text();marker='## LibreOffice 25.2.7.2 on the local PC\n';addition=f'''\nThe [implemented-performance follow-up]({name}.md) runs two fresh pairs in\nopposite orders at 32 jobs and 30 GiB RAM. Mean clean times are **{g:.3f} s GNU**\nand **{o:.3f} s Openmktr**, a **{100*gap:.2f}% gap**, closing **{aggregate['percentage_gap_closed']:.1f}%** of the\nhistorical percentage gap. Both pairs pass full output controls, repeat checks,\napplication smoke tests and source audits. The following single pair is historical.\n''';assert marker in s
if addition.strip() not in s:s=s.replace(marker,marker+addition,1);p.write_text(s)
p=R/'validation/evidence/README.md';s=p.read_text();entry=f'''\n## Implemented performance comparison — 30 October 2026\n\n[{name}.zip]({name}.zip) and its [SHA-256]({name}.zip.sha256)\nretain two fresh 32-job GNU/Openmktr pairs, normal/sanitizer gates, incremental\nchecks, same-path artifact controls and controller scripts. The\n[report](../../docs/{name}.md) records a {100*gap:.2f}% remaining mean clean-build gap\nand {aggregate['percentage_gap_closed']:.1f}% closure of the historical percentage gap.\n'''
if entry.strip() not in s:p.write_text(s+entry)
# Package only explicit evidence files, not build trees or context payloads.
files=[(C/'bench-j32.py','evidence/bench-j32.py')]
for p in E.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.patch'):files.append((p,'evidence/'+p.name))
for folder in ('pair1','pair2','before-serial-fix','before-nested-fallback'):
 for p in (E/folder).iterdir():
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.txt'):files.append((p,'evidence/'+folder+'/'+p.name))
for p in Path('/mnt/c/Users/Harry/AppData/Local/Temp').glob('omktr-*.py'):
 if p.name.startswith(('omktr-implemented-','omktr-gates-clock','omktr-order-repro','omktr-record-serial-snapshot','omktr-speed-implementation')):files.append((p,'controllers/'+p.name))
for p in (R/'src').iterdir():
 if p.is_file():files.append((p,'candidate/src/'+p.name))
for name2 in ('correctness.py','graph_optimizations.py','generated_recipe_reads.py','golden.json','bench.py'):
 files.append((R/'tests'/name2,'candidate/tests/'+name2))
for name2 in ('build.ninja','.clang-format','LICENSE','NOTICE','tools/gen_version.py','tools/gen_sanitizer_build.py'):
 
 if (R/name2).is_file():files.append((R/name2,'candidate/'+name2))
for path in (R/'docs'/f'{name}.md',R/'validation/openmktr-performance-results.json'):
 files.append((path,str(path.relative_to(R))))
for name2 in ('benchmark_libreoffice.py','compare_libreoffice_outputs.py','verify_release_archive.py','incremental.py'):
 files.append((R/'validation'/name2,'candidate/validation/'+name2))
archive=R/'validation/evidence'/f'{name}.zip';manifest={arc:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p,arc in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,arc in files:z.write(p,arc)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
h=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix('.zip.sha256').write_text(h+'  '+archive.name+'\n')
print(json.dumps(dict(report=str(R/'docs'/f'{name}.md'),aggregate=aggregate,archive_bytes=archive.stat().st_size,archive_sha256=h),indent=2))
