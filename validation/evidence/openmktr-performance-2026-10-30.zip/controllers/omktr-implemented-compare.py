from pathlib import Path
import subprocess,json,os,shutil,time,concurrent.futures,hashlib
E=Path('/root/openmktr-implemented-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');B=E/'omktr-candidate18'
assert B.is_file()
assert os.cpu_count()==32
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
assert int(mem['MemTotal'].split()[0])>29_000_000
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
start_raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
result=dict(jobs=32,meminfo=mem,original_timesync_active=state,runs=[])
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
def run(name,cmd,log=True):
 print('START',name,flush=True);start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
 if log:
  with (E/(name+'.log')).open('w') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 else:q=subprocess.run(cmd,env=env)
 result['runs'].append(dict(name=name,command=cmd,exit_code=q.returncode,seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start));(E/'controller.json').write_text(json.dumps(result,indent=2));print('END',name,q.returncode,flush=True)
 if q.returncode:raise RuntimeError(name+' failed')
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
  if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
 before=(R/'tests/bench.py').read_text()
 after=before.replace('"-j4"','"-j32"').replace('for job_count in (1, 4):','for job_count in (32,):').replace('[str(binary), "--ninja",','[str(binary), "--ninja", "-j32",').replace('time.perf_counter()', 'time.clock_gettime(time.CLOCK_MONOTONIC_RAW)')
 (C/'omktr-speed-implementation/bench-j32.py').write_text(after)
 run('bench-j32',['chroot',str(C),'python','/omktr-speed-implementation/bench-j32.py','/omktr-speed-implementation/omktr','--baseline','/lo-improvements-candidate/omktr','--repeats','3'])
 run('incremental-j32',['python3',str(R/'validation/incremental.py'),'--omktr',str(B),'--cc','/usr/bin/clang-18','--make','/usr/bin/make','--jobs','32','--output',str(E/'incremental-j32')])
 # Same real context, 256 recipes and 32 workers; alternating binary order.
 fixture=Path('/root/openmktr-speed-20261030/runtime-fixture-v2')
 sidecars=sorted(fixture.glob('libreoffice-.kati_runtime-*'));assert len(sidecars)==256
 runtime={k:[] for k in ('baseline','candidate')}
 binaries={'baseline':Path('/root/libreoffice-improvements-20261029/omktr-candidate17'),'candidate':B}
 for iteration in range(4):
  for name in (('baseline','candidate') if iteration%2==0 else ('candidate','baseline')):
   start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW);cpu=os.times()
   def invoke(p):
    q=subprocess.run([str(binaries[name]),'--internal-evaluate-recipe',str(p)],cwd=fixture,env=env,capture_output=True)
    assert q.returncode==0,q.stderr
   with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:list(workers.map(invoke,sidecars))
   end=os.times();runtime[name].append(dict(wall_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,cpu_seconds=end.children_user+end.children_system-cpu.children_user-cpu.children_system))
   assert all((fixture/f'out{i}').read_text()=='ready' for i in range(256))
 (E/'runtime-ab.json').write_text(json.dumps(runtime,indent=2));print('runtime A/B complete',flush=True)
 for pair,lanes in [('pair1',['gnu','aggressive']),('pair2',['aggressive','gnu'])]:
  run(pair,['python3',str(R/'validation/benchmark_libreoffice.py'),'--workspace',str(E/pair),'--report',str(E/(pair+'-report')),'--omktr',str(B),'--jobs','32','--repeats','3','--lanes',*lanes,'--pdf-module-path','/root/libreoffice-pair-20261029-200435/pylib'],False)
 result['pass']=True
finally:
 if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 result['raw_elapsed_seconds']=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start_raw
 result['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 (E/'controller.json').write_text(json.dumps(result,indent=2))

