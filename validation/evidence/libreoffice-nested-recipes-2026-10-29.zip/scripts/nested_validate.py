from pathlib import Path
import subprocess
import shutil

repo = Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
root = Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
work = '/tmp/lo-fix-20261029'
logs = Path('/root/omktr-lo-fix-20261029/nested-validation-complete')
logs.mkdir(exist_ok=True)
files = ['src/command.cc', 'src/command.h', 'src/expr.cc', 'src/expr.h', 'src/main.cc', 'src/ninja.cc', 'src/eval.cc', 'src/eval.h', 'src/dep.cc']
shutil.copytree(repo/'tests', root/work.lstrip('/')/'tests', dirs_exist_ok=True)
for name in files:
    shutil.copy2(repo/name, root/work.lstrip('/')/name)
subprocess.run(['chroot', str(root), 'clang-format', '-i'] + [work+'/'+name for name in files], check=True)
for name in files:
    shutil.copy2(root/work.lstrip('/')/name, repo/name)
for mount, args in [('proc', ['mount','-t','proc','proc']), ('dev',['mount','--bind','/dev'])]:
    if subprocess.run(['mountpoint','-q',str(root/mount)]).returncode:
        subprocess.run(args+[str(root/mount)],check=True)

def run(label, command):
    with (logs/(label+'.log')).open('w') as stream:
        status = subprocess.run(['chroot',str(root),'/bin/sh','-c','cd '+work+' && '+command], stdout=stream,stderr=subprocess.STDOUT).returncode
    print(label,status,flush=True)

run('normal', 'ninja -j16 omktr tests && out/find_test && out/ninja_test && out/strutil_test && python tests/version_generator.py && python tests/correctness.py && python tests/generated_recipe_reads.py && python tests/graph_optimizations.py && python tests/workspace.py && python tests/ninja_jobserver.py && python tests/make_compat_regressions.py && python tests/regression.py && sh testcase/dump/run.sh')
run('format', "CLANG_FORMAT_FILES='"+' '.join(files)+"' sh clang-format-check")
run('sanitizer-build', 'python tools/gen_sanitizer_build.py && ninja -f build.sanitizer.ninja -j16 omktr-sanitized tests')
run('sanitized-units', 'ASAN_OPTIONS=detect_leaks=0 out/sanitized/find_test && ASAN_OPTIONS=detect_leaks=0 out/sanitized/ninja_test && ASAN_OPTIONS=detect_leaks=0 out/sanitized/strutil_test && ASAN_OPTIONS=detect_leaks=0 out/sanitized/load_limit_test')
for suite in ['generated_recipe_reads','correctness','graph_optimizations','workspace','ninja_jobserver','make_compat_regressions','load_limits','portage']:
    run('sanitized-'+suite, 'ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY='+work+'/omktr-sanitized python tests/'+suite+'.py')
run('sanitized-aggressive', 'ASAN_OPTIONS=detect_leaks=0 OMKTR_TEST_GRAPH_PROFILE=aggressive OMKTR_BINARY='+work+'/omktr-sanitized python tests/correctness.py')
