from pathlib import Path
import shutil
import subprocess
import zipfile
import re

repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
root=Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
work=root/'tmp/lo-nested-baseline-20261029'
if not work.exists():
    shutil.copytree(root/'tmp/lo-fullblast-tool-20261029',work,ignore=shutil.ignore_patterns('out','.git','omktr','omktr-sanitized'))
    (work/'out').mkdir(exist_ok=True)
if not (work/'baseline-ready').exists():
    with zipfile.ZipFile(repo/'validation/evidence/libreoffice-fixes-2026-10-29.zip') as archive:
        name=next(n for n in archive.namelist() if n.endswith('implementation.patch'))
        patch=archive.read(name).replace(b'\r\n', b'\n')
    for name in re.findall(rb'^diff --git a/(\S+) b/',patch,re.M):
        target=work/name.decode()
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(subprocess.check_output(['git','-C',str(repo),'show','38ddf6d0e4c8bee9e5449992ed1c412205d6e56c:'+name.decode()]))
    subprocess.run(['git','apply','-'],cwd=work,input=patch,check=True)
    (work/'baseline-ready').touch()
shutil.copy2(repo/'tests/generated_recipe_reads.py',work/'tests/generated_recipe_reads.py')
for mount,args in [('proc',['mount','-t','proc','proc']),('dev',['mount','--bind','/dev'])]:
    if subprocess.run(['mountpoint','-q',str(root/mount)]).returncode:
        subprocess.run(args+[str(root/mount)],check=True)
subprocess.run(['chroot',str(root),'/bin/sh','-c','cd /tmp/lo-nested-baseline-20261029 && ninja -j16 omktr'],check=True)
with Path('/root/omktr-lo-fix-20261029/nested-baseline.log').open('w') as log:
    status=subprocess.run(['chroot',str(root),'/bin/sh','-c','cd /tmp/lo-nested-baseline-20261029 && OMKTR_BINARY=/tmp/lo-nested-baseline-20261029/omktr python tests/generated_recipe_reads.py'],stdout=log,stderr=subprocess.STDOUT).returncode
print('baseline focused suite',status,flush=True)
