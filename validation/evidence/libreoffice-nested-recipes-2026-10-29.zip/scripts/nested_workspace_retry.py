from pathlib import Path
import subprocess
root=Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
logs=Path('/root/omktr-lo-fix-20261029/nested-validation-complete')
for label,tests in [('sanitized-workspace-gc-retry','Workspace.test_gc_records_selected_format_without_implicitly_repacking'),('sanitized-workspace-retry','')]:
    with (logs/(label+'.log')).open('w') as stream:
        result=subprocess.run(['chroot',str(root),'/bin/sh','-c','cd /tmp/lo-fix-20261029 && ASAN_OPTIONS=detect_leaks=0 OMKTR_BINARY=/tmp/lo-fix-20261029/omktr-sanitized python tests/workspace.py '+tests],stdout=stream,stderr=subprocess.STDOUT)
    print(label,result.returncode,flush=True)
