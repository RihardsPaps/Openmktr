from pathlib import Path
import os
import signal
import subprocess
import runpy
import time

settings = runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root = Path('/root/omktr-lo-fix-20261029/libreoffice')
build = root / 'build'
source = root / 'libreoffice-25.2.7.2'
tool = '/root/omktr-lo-fix-20261029/omktr'
env = dict(settings['ENV'], SRCDIR=str(source), BUILDDIR=str(build), WORKDIR=str(build/'workdir'))
langs = next(l.split('=',1)[1] for l in (build/'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
command = [tool, '--ninja', '--regen', '--ninja_dir=.openmktr-nested', '--graph_optimizations=aggressive', '-j32', '-rs', '-f', str(source/'Makefile.gbuild'), 'MAKE='+tool, 'ALL_LANGS='+langs, 'build']
start = time.monotonic()
with (root/'nested-generation.log').open('w') as log:
    process = subprocess.Popen(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()
print(process.returncode, time.monotonic()-start, flush=True)
