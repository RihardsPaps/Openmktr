from pathlib import Path
import os
import signal
import subprocess
import runpy
import time
import json
import hashlib
import re

settings = runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root = Path('/root/omktr-lo-fix-20261029/libreoffice')
source = root/'libreoffice-25.2.7.2'
tool = '/root/omktr-lo-fix-20261029/omktr'
targets = ['workdir/ComponentTarget/comphelper/util/comphelp.component', 'workdir/InstallScriptTarget/setup_osl.ins']
results = {}
for lane, executable in [('gnu','/usr/bin/make'),('direct',tool)]:
    build = root/(lane+'-small')
    env = dict(settings['ENV'], SRCDIR=str(source), BUILDDIR=str(build), WORKDIR=str(build/'workdir'))
    langs=next(l.split('=',1)[1] for l in (build/'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
    for number in range(2):
        label = lane+('-repeat' if number else '-selected')
        command=[executable,'-j32','-rs','-f',str(source/'Makefile.gbuild'),'MAKE='+executable,'ALL_LANGS='+langs]+[str(build/t) for t in targets]
        start=time.monotonic()
        before={t:(build/t).stat().st_mtime_ns for t in targets if (build/t).exists()}
        with (root/('nested-'+label+'.log')).open('w') as stream:
            process=subprocess.Popen(command,cwd=build,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            timeout=False
            try: process.wait(timeout=300)
            except subprocess.TimeoutExpired:
                timeout=True
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
        results[label]=dict(exit_code=process.returncode,timeout=timeout,seconds=time.monotonic()-start,command=command,unchanged=before=={t:(build/t).stat().st_mtime_ns for t in targets if (build/t).exists()})
        print(label,process.returncode,flush=True)
        if process.returncode: break

def normalize(text):
    # par2script.pl emits simple identifier lists in randomized Perl hash order.
    return re.sub(r'(?m)^([ \t]*[A-Za-z0-9_]+[ \t]*=[ \t]*)\(([A-Za-z0-9_,\s]+)\);',lambda m:m[1]+'('+','.join(sorted(x.strip() for x in m[2].split(',')))+');',text)
outputs={}
for lane, directory in [('ninja','build'),('gnu','gnu-small'),('direct','direct-small')]:
    outputs[lane]={}
    for target in targets+['instdir/program/libuno_sal.so.3']:
        p=root/directory/target
        if p.exists():
            data=p.read_bytes()
            outputs[lane][target]={'sha256':hashlib.sha256(data).hexdigest()}
            if target.endswith('.ins'):
                outputs[lane][target]['canonical_sha256']=hashlib.sha256(normalize(data.decode()).encode()).hexdigest()
(root/'nested-comparison-results.json').write_text(json.dumps(dict(runs=results,outputs=outputs),indent=2))
