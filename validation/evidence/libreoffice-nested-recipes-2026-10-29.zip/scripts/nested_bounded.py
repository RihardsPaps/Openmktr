from pathlib import Path
import os
import sys
import signal
import subprocess
import runpy
import time
import json
import hashlib

settings = runpy.run_path(str(Path(__file__).with_name('run_benchmark.py')))
root = Path('/root/omktr-lo-fix-20261029/libreoffice')
build = root / 'build'
source = root / 'libreoffice-25.2.7.2'
tool = '/root/omktr-lo-fix-20261029/omktr'
env = dict(settings['ENV'], SRCDIR=str(source), BUILDDIR=str(build), WORKDIR=str(build/'workdir'))
langs = next(l.split('=',1)[1] for l in (build/'config_host_lang.mk').read_text().splitlines() if l.startswith('ALL_LANGS='))
label = sys.argv[1]
goals = [arg for arg in sys.argv[2:] if arg != '--force']
if '--force' in sys.argv[2:]:
    for goal in goals:
        target = Path(goal).resolve()
        assert target.is_relative_to((build/'workdir').resolve())
        assert target.suffix in ('.component', '.ins')
        target.unlink(missing_ok=True)
base = [tool, '-j32', '-rs', '-f', str(source/'Makefile.gbuild'), 'MAKE='+tool, 'ALL_LANGS='+langs] + goals
graph = '.openmktr-nested-'+label
commands = [('generate',base[:1]+['--ninja','--regen','--ninja_dir='+graph,'--graph_optimizations=aggressive']+base[1:])]
if goals != ['build']:
    commands += [('execute',['sh',graph+'/ninja.sh','-j32']),('repeat',['sh',graph+'/ninja.sh','-j32'])]
results = {}
for phase, command in commands:
    start = time.monotonic()
    with (root/('nested-'+label+'-'+phase+'.log')).open('w') as log:
        process = subprocess.Popen(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            process.wait(timeout=300)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    results[phase] = dict(command=command, exit_code=process.returncode, timeout=timed_out, seconds=time.monotonic()-start)
    results[phase]['artifacts'] = {goal:dict(sha256=hashlib.sha256(Path(goal).read_bytes()).hexdigest(),mtime_ns=Path(goal).stat().st_mtime_ns) for goal in goals if Path(goal).is_absolute() and Path(goal).is_file()}
    print(label,phase,results[phase],flush=True)
    if process.returncode:
        break
(root/('nested-'+label+'-results.json')).write_text(json.dumps(results,indent=2))
