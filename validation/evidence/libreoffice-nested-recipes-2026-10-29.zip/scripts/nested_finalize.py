from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import re

repo=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
root=Path('/root/omktr-lo-fix-20261029')
lo=root/'libreoffice'
logs=root/'nested-validation-complete'
sha=lambda data: hashlib.sha256(data).hexdigest()
for suite in ['correctness','generated_recipe_reads','graph_optimizations','ninja_jobserver','make_compat_regressions','load_limits','portage','aggressive','workspace-retry']:
    text=(logs/('sanitized-'+suite+'.log')).read_text()
    assert re.search(r'\nOK(?: \(skipped=1\))?\s*$',text),suite
assert '858/858 scenarios match' in (logs/'normal.log').read_text()
assert not (logs/'format.log').read_text().strip()
graph=json.loads((lo/'nested-complete-graph-results.json').read_text())
selected=json.loads((lo/'nested-stable-output-results.json').read_text())
assert all(v['exit_code']==0 and not v['timeout'] for v in [*graph.values(),*selected.values()])
generation=(lo/'nested-complete-graph-generate.log').read_text()
assert 'No such file or directory' not in generation
comparison=json.loads((lo/'nested-comparison-results.json').read_text())

def canonical(text):
    return re.sub(r'(?m)^([ \t]*[A-Za-z0-9_]+[ \t]*=[ \t]*)\(([A-Za-z0-9_,\s]+)\);',lambda m:m[1]+'('+','.join(sorted(x.strip() for x in m[2].split(',')))+');',text)
for lane,directory in [('ninja','build'),('gnu','gnu-small'),('direct','direct-small')]:
    for target,record in comparison['outputs'][lane].items():
        data=(lo/directory/target).read_bytes()
        record['sha256']=sha(data)
        if target.endswith('.ins'): record['canonical_sha256']=sha(canonical(data.decode()).encode())
outputs=comparison['outputs']
for target in outputs['ninja']:
    field='canonical_sha256' if target.endswith('.ins') else 'sha256'
    assert len({outputs[lane][target][field] for lane in outputs})==1,(target,field)
verification=subprocess.run(['python3',str(repo/'validation/verify_archive.py'),'/root/universal-tool-campaign-20260927/sources/libreoffice-25.2.7.2.tar.xz',str(lo/'libreoffice-25.2.7.2')],capture_output=True,text=True,check=True)
(root/'nested-source-integrity.log').write_text(verification.stdout+verification.stderr)
paths=subprocess.check_output(['git','-C',str(repo),'-c','core.autocrlf=true','diff','--name-only','--','src','tests']).decode().splitlines()
paths += ['tests/generated_recipe_reads.py']
source_hashes={p:sha((repo/p).read_bytes()) for p in paths}
snapshot=Path('/root/universal-tool-campaign-20260927/chimera-root-complete/tmp/lo-fix-20261029')
assert all((repo/p).read_bytes()==(snapshot/p).read_bytes() for p in paths)
patch=subprocess.check_output(['git','-C',str(repo),'-c','core.autocrlf=true','diff','--','src','tests','Dockerfile','.github/workflows/cpp-ci.yml','CONTRIBUTING.md'])
result=dict(status='nested-generated-reads-fixed-and-bounded-validation-complete',full_benchmark_run=False,execution_cap_seconds=300,binary_sha256=sha((root/'omktr').read_bytes()),source_sha256=source_hashes,patch_sha256=sha(patch),baseline='Recreated previous candidate from retained patch on recorded base; focused suite fails 24 Ninja subcases.',normal_gate='180 correctness, 8 focused tests, 53 graph tests, 30 workspace, 7 jobserver, 6 compatibility, 858 snapshots, C++ units, version and include dump passed',sanitizers='All CI suites and focused tests passed; one optional Portage skip. Workspace GC failed once, then focused and full workspace retries passed.',docker='Docker Desktop Linux engine unavailable; local pinned Chimera chroot used.',graph=graph,missing_generated_file_probes=0,selected=selected,comparison=comparison,source_integrity=verification.stdout.strip(),limits=['No full LibreOffice build or speed ratio.', 'Two early graph attempts reached 300 seconds and were killed; initial large per-recipe snapshots were replaced with shared global contexts.', 'One graph retry recorded a deleted executable path because the validation driver replaced its running binary; stable-binary replay passed.', 'Real selected-target repeats can rebuild intermediates; direct repeat also changed timestamps. Focused stable-output repeats remain unchanged.', 'Multiple double-colon recipe groups and recipe-time assignments to another target are explicitly rejected on the deferred path.', 'A pre-existing direct-mode target-export limitation for shell-function expansion was observed; recipe-process exports are covered.'])
destination=repo/'validation/libreoffice-nested-recipe-results.json'
destination.write_text(json.dumps(result,indent=2)+'\n')
entries={'results.json':destination.read_bytes(),'implementation.patch':patch,'tests/generated_recipe_reads.py':(repo/'tests/generated_recipe_reads.py').read_bytes()}
entries['investigation-report.md']=(repo/'docs/libreoffice-benchmark-2026-10-29.md').read_bytes()
for p in sorted(root.glob('nested-*.log')):
    entries['logs/'+p.name]=p.read_bytes()
for directory in sorted(root.glob('nested-validation*')):
    for p in sorted(directory.glob('*.log')):
        entries['logs/'+directory.name+'/'+p.name]=p.read_bytes()
for p in sorted(lo.glob('nested-*')):
    if p.is_file() and p.suffix in ('.log','.json'):
        entries['libreoffice/'+p.name]=p.read_bytes()
for p in sorted((repo/'validation/logs/libreoffice-fullblast-20261029').glob('nested_*.py')):
    entries['scripts/'+p.name]=p.read_bytes()
for lane,directory in [('ninja','build'),('gnu','gnu-small'),('direct','direct-small')]:
    for target in ['workdir/ComponentTarget/comphelper/util/comphelp.component','workdir/InstallScriptTarget/setup_osl.ins']:
        entries['outputs/'+lane+'/'+Path(target).name]=(lo/directory/target).read_bytes()
entries['manifest.json']=json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in entries.items()},indent=2).encode()
archive=repo/'validation/evidence/libreoffice-nested-recipes-2026-10-29.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
    for name,data in entries.items(): package.writestr(name,data)
result['evidence']=dict(path=str(archive.relative_to(repo)),sha256=sha(archive.read_bytes()),entries=len(entries))
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['evidence']),flush=True)
