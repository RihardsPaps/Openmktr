#!/usr/bin/env python3
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
"""Focused producer/consumer checks for runtime Ninja recipe expansion."""

import os
from pathlib import Path
import subprocess
import tempfile
import unittest


BINARY = Path(os.environ.get(
    "OMKTR_BINARY", Path(__file__).resolve().parents[1] / "omktr"
)).resolve()


class GeneratedRecipeReads(unittest.TestCase):
    def test_runtime_consumers_overlap_within_job_limit(self):
        for profile in ("off", "safe", "aggressive"):
            with self.subTest(profile=profile), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "Makefile").write_text(
                    "all: a b\ngenerated:\n\t@printf ready > $@\n"
                    "a b: generated\n"
                    "\t@python3 worker.py '$(strip $(shell cat generated))' $@\n")
                (root / "worker.py").write_text(
                    "import fcntl, json, pathlib, sys, time\n"
                    "assert sys.argv[1] == 'ready'\n"
                    "def change(delta):\n"
                    " with open('counter', 'a+') as f:\n"
                    "  fcntl.flock(f, fcntl.LOCK_EX); f.seek(0)\n"
                    "  state=json.loads(f.read() or '[0,0,0]')\n"
                    "  state[0]+=delta; state[1]=max(state[0],state[1])\n"
                    "  state[2]+=delta>0\n"
                    "  f.seek(0); f.truncate(); json.dump(state,f); f.flush()\n"
                    "  return state\n"
                    "change(1)\n"
                    "deadline=time.monotonic()+5\n"
                    "while change(0)[2] < 2:\n"
                    " assert time.monotonic()<deadline, 'consumers serialized'\n"
                    " time.sleep(.01)\n"
                    "change(-1); pathlib.Path(sys.argv[2]).touch()\n")
                for command in ([str(BINARY), "--ninja", "--regen",
                                 "--graph_optimizations=" + profile, "all"],
                                ["sh", "./ninja.sh", "-j2"]):
                    result = subprocess.run(command, cwd=root, capture_output=True,
                                            text=True, timeout=15)
                    self.assertEqual(result.returncode, 0,
                                     result.stdout + result.stderr)
                import json
                self.assertEqual(json.loads((root / "counter").read_text()),
                                 [0, 2, 2])

    def run_case(self, expression, expected, mode, profile, prefix=""):
        with tempfile.TemporaryDirectory(prefix="omktr-generated-read-") as tmp:
            root = Path(tmp)
            (root / "seed").write_text("dir/b dir/a other/b\n")
            (root / "Makefile").write_text(
                prefix + "transform = $(sort $(notdir $(1)))\n"
                "reader = $(shell cat $(1))\n"
                "selected = reader\n"
                "all: result\n"
                "generated: seed\n\t@cp $< $@\n"
                "result: generated\n"
                "\t@printf '%s' '" + expression + "' > $@\n")

            def run(*args):
                result = subprocess.run(
                    args, cwd=root, capture_output=True, text=True, timeout=15)
                self.assertEqual(result.returncode, 0,
                                 result.stdout + result.stderr)
                return result.stdout + result.stderr

            flags = ("--graph_optimizations=" + profile,)
            if mode == "ninja":
                output = run(str(BINARY), "--ninja", "--regen", *flags, "all")
                self.assertFalse((root / "generated").exists())
                self.assertFalse((root / "effect").exists())
                run("sh", "./ninja.sh", "-j2")
            else:
                run(str(BINARY), *flags, "all")
            self.assertEqual((root / "result").read_text(), expected)
            if mode == "ninja":
                self.assertNotIn("No such file", output)
                stamp = (root / "result").stat().st_mtime_ns
                run("sh", "./ninja.sh", "-j2")
                self.assertEqual((root / "result").stat().st_mtime_ns, stamp)
                sidecars = list(root.glob(".kati_runtime-*"))
                self.assertTrue(sidecars)
                for sidecar in sidecars:
                    sidecar.write_bytes(b"corrupt")
                (root / "result").unlink()
                failed = subprocess.run(
                    ["sh", "./ninja.sh", "-j2"], cwd=root,
                    capture_output=True, text=True, timeout=15)
                self.assertNotEqual(failed.returncode, 0)
                self.assertIn("regenerate", failed.stdout + failed.stderr)

    def check_expression(self, expression, expected, prefix=""):
        for profile in ("off", "safe", "aggressive"):
            for mode in ("direct", "ninja"):
                with self.subTest(profile=profile, mode=mode):
                    self.run_case(expression, expected, mode, profile, prefix)

    def test_quoted_component_contents(self):
        self.check_expression("$(shell cat generated)", "dir/b dir/a other/b")

    def test_installer_transform(self):
        self.check_expression(
            "$(call transform,$(shell cat generated))", "a b")

    def test_foreach_directory_transform(self):
        self.check_expression(
            "$(sort $(foreach entry,$(shell cat generated),$(dir $(entry))))",
            "dir/ other/")

    def test_computed_macro_read(self):
        self.check_expression(
            "$(call transform,$(call $(selected),generated))", "a b")

    def test_recipe_effects_and_automatic_variables(self):
        self.check_expression(
            "$(eval LOCAL := ready)$(file >effect,$(LOCAL))"
            "$(LOCAL):$@:$<:$(call transform,$(shell cat generated))",
            "ready:result:generated:a b")

    def test_oneshell_target_specific_context(self):
        self.check_expression(
            "$(flavor WORD):$(origin WORD):$(WORD):"
            "$(call transform,$(shell cat generated))",
            "simple:file:target:a b",
            ".ONESHELL:\nresult: WORD := target\n")

    def test_target_export_reaches_recipe_process(self):
        self.check_expression(
            "$(call transform,$(shell cat generated))'\"$$WORD\"'",
            "a bresult", "result: export WORD = $@\n")


if __name__ == "__main__":
    unittest.main()
