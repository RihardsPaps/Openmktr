from pathlib import Path
import json,subprocess,sys,time
E=Path('/root/openmktr-next-20261030');S=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
assert (E/'environment.json').is_file()
assert len(list(E.glob('*generate.json')))==8
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
try:
    subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
    # Replace warm-off-2: a read-only graph inventory overlapped that sample.
    subprocess.run(['unshare','-m',sys.executable,str(S/'omktr-next-front.py'),'--inner','warm-off-3'],check=True)
finally:
    if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
for name in ('runtime','helpers','audit'):
    with (E/(name+'-controller.log')).open('w') as f:
        subprocess.run([sys.executable,str(S/('omktr-next-'+name+'.py'))],stdout=f,stderr=subprocess.STDOUT,check=True)
    print(name,'complete',flush=True)
(E/'controls-complete.json').write_text(json.dumps(dict(complete=True,excluded_sample='warm-off-2',exclusion_reason='Read-only graph inventory ran concurrently; replaced by warm-off-3.'),indent=2))
