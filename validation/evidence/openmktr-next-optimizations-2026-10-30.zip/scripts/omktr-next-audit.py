from pathlib import Path
import collections,hashlib,json,re,struct,subprocess
E=Path('/root/openmktr-next-20261030');P=Path('/root/openmktr-implemented-20261030');N='/root/omktr-graph-optimizations/ninja-1.13.2/ninja'
def digest(b):return hashlib.sha256(b).hexdigest()
def parts(data):
    offset=0;result=[]
    while offset<len(data):
        length=struct.unpack_from('<Q',data,offset)[0];offset+=8
        assert offset+length<=len(data)
        result.append(data[offset:offset+length]);offset+=length
    return result
def read(path):return parts(path.read_bytes())[2]
front={};target_hashes=collections.defaultdict(set);name_hashes=collections.defaultdict(set)
for path in sorted(E.glob('*generate.json')):
    name=path.name.removesuffix('-generate.json');r=json.loads(path.read_text());text=path.with_suffix('.log').read_text()
    cold=name.startswith('cold');build=E/name if cold else P/'pair1/aggressive/build';actual=build if cold else E/name/'upper'
    graph=actual/'.openmktr/build.ninja'
    # Query only; this never executes recipes. Ninja parses with the max jobs setting.
    targets=subprocess.check_output([N,'-j32','-f',str(graph),'-t','targets','all'],cwd=build).decode()
    normalized=targets.replace(str(build),'<BUILD>')
    # Profile names differ intentionally; target order/rules should otherwise agree.
    sh=digest(normalized.encode());target_hashes['cold' if cold else 'warm'].add(sh)
    nh=digest('\n'.join(line.rsplit(': ',1)[0] for line in normalized.splitlines()).encode());name_hashes['cold' if cold else 'warm'].add(nh)
    (E/(name+'-targets.sha256')).write_text(sh+'\n')
    data=dict(**r,graph_bytes=graph.stat().st_size,target_lines=len(targets.splitlines()),normalized_targets_sha256=sh,normalized_target_names_sha256=nh,
        evaluation_seconds=[float(x) for x in re.findall(r'\*kati\*: eval time: ([\d.]+)',text)],
        include_execution_seconds=[float(x) for x in re.findall(r'\*kati\*: execute included makefiles time: ([\d.]+)',text)],
        final_dependency_seconds=[float(x) for x in re.findall(r'\*kati\*: make dep time: ([\d.]+)',text)],
        ninja_evaluation_seconds=[float(x) for x in re.findall(r'\*kati\*: ninja gen \(eval\): ([\d.]+)',text)],
        ninja_emission_seconds=[float(x) for x in re.findall(r'\*kati\*: ninja gen \(emit\): ([\d.]+)',text)],
        cutoffs=[dict(hits=int(a),misses=int(b)) for a,b in re.findall(r'evaluation recording disabled after (\d+) hits and (\d+) misses',text)],
        graph_stats=re.findall(r'kati: Ninja graph stats: (.*)',text),
        indexed_pattern_counts=re.findall(r'indexed pattern scopes: (.*)',text),
        include_actions=dict(collections.Counter(re.findall(r'^\[build ([^\]]+)\]',text,re.M))))
    if cold:
        config=(build/'config_host.mk').read_text().replace(str(build),'<BUILD>')
        data['normalized_config_sha256']=digest(config.encode())
    front[name]=data
    print(name,data['target_lines'],sh,flush=True)
# Inventory a fresh graph, resolving script sidecars without executing them.
build=E/'cold-adaptive-1';directory=build/'.openmktr';graph=(directory/'build.ninja').read_bytes()
script_names=set(re.findall(rb'\.kati_script-\d+',graph))
scripts=[read(directory/name.decode()) for name in script_names]
texts=[graph,*scripts];names=set()
helpers=collections.Counter()
for text in texts:
    names.update(re.findall(rb'\.kati_runtime-\d+',text))
    helpers.update(x.decode() for x in re.findall(rb'--internal-[a-z-]+',text))
contexts=collections.Counter();total_bytes=0
for name in names:
    fields=parts(read(directory/name.decode()));assert fields[0]==b'runtime-recipe-v5'
    context=Path(fields[7].decode());context=context if context.is_absolute() else build/context
    contexts[str(context)]+=1;total_bytes+=context.stat().st_size
inventory=dict(runtime_recipe_references=len(names),script_sidecars=len(script_names),helper_text_occurrences=dict(helpers),logical_context_read_bytes_once_per_recipe=total_bytes,
    contexts=[dict(path=k,bytes=Path(k).stat().st_size,references=v,sha256=digest(Path(k).read_bytes())) for k,v in contexts.items()])
result=dict(front=front,all_target_and_rule_listings_match={k:len(v)==1 for k,v in target_hashes.items()},all_target_names_match={k:len(v)==1 for k,v in name_hashes.items()},inventory=inventory)
(E/'audit-results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(all_target_and_rule_listings_match=result['all_target_and_rule_listings_match'],all_target_names_match=result['all_target_names_match'],inventory=inventory),indent=2),flush=True)
