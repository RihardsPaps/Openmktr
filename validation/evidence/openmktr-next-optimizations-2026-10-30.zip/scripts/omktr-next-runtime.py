from pathlib import Path
import collections,concurrent.futures,hashlib,json,os,statistics,struct,subprocess,time
E=Path('/root/openmktr-next-20261030');P=Path('/root/openmktr-implemented-20261030');B=P/'omktr-candidate18'
root=E/'runtime-fixture';root.mkdir()
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
for k in list(env):
    if k.startswith(('KATI_','OMKTR_')) or k in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):env.pop(k)
def parts(data):
    offset=0;result=[]
    while offset<len(data):
        length=struct.unpack_from('<Q',data,offset)[0];offset+=8
        assert offset+length<=len(data)
        result.append(data[offset:offset+length]);offset+=length
    return result
def pack(fields):return b''.join(struct.pack('<Q',len(x))+x for x in fields)
def read(path):return parts(path.read_bytes())[2]
def write(path,payload):
    h=14695981039346656037
    for c in payload:h=((h^c)*1099511628211)&((1<<64)-1)
    path.write_bytes(pack([b'OMKTR_GRAPH1',str(h).encode(),payload]))
(root/'seed').write_text('ready')
(root/'Makefile').write_text('OMKTR_PROFILE_MACRO = OMKTR_PROFILE_READER\nOMKTR_PROFILE_READER = $(shell cat seed)\nall: '+ ' '.join('out'+str(i) for i in range(256))+'\n'+''.join('out'+str(i)+': seed\n\t@printf %s "$(call $(OMKTR_PROFILE_MACRO))" > $@\n' for i in range(256)))
with (E/'runtime-generate.log').open('w') as log:subprocess.run([str(B),'--ninja','-j32','all'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sidecars=sorted(p for p in root.glob('.kati_runtime-*') if not p.name.startswith(('.kati_runtime-context-','.kati_runtime-reads-')))
assert len(sidecars)==256
real=max((P/'pair1/aggressive/build/.openmktr').glob('.kati_runtime-context-*'),key=lambda x:x.stat().st_size)
context=read(real);definitions=parts(context)
flavors=collections.Counter(parts(d)[2].decode() for d in definitions)
variants={k:[] for k in ('small','libreoffice')}
for p in sidecars:
    fields=parts(read(p));assert fields[0]==b'runtime-recipe-v5'
    fixture_globals=read(root/fields[7].decode())
    for name in variants:
        out=root/(name+'-'+p.name);copy=list(fields)
        if name=='libreoffice':copy[7]=str(real).encode();copy[8]+=fixture_globals
        write(out,pack(copy));variants[name].append(out)
results=dict(jobs=os.cpu_count(),memory=Path('/proc/meminfo').read_text(),binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),context_bytes=len(context),context_sha256=hashlib.sha256(real.read_bytes()).hexdigest(),variables=len(definitions),flavors=dict(flavors),samples={k:[] for k in variants})
assert results['jobs']==32
assert int(results['memory'].split('MemTotal:')[1].split()[0])>29_000_000
def invoke(p):
    out=subprocess.run([str(B),'--internal-evaluate-recipe',str(p)],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    if out.returncode:raise RuntimeError(out.stderr.decode())
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
try:
    subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
    for iteration in range(6):
        for name in (('small','libreoffice') if iteration%2==0 else ('libreoffice','small')):
            for i in range(256):(root/('out'+str(i))).unlink(missing_ok=True)
            before=os.times();t=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
            with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:list(workers.map(invoke,variants[name]))
            wall=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-t;after=os.times()
            assert all((root/('out'+str(i))).read_text()=='ready' for i in range(256))
            result=dict(wall_seconds=wall,cpu_seconds=after.children_user+after.children_system-before.children_user-before.children_system,verified_outputs=256)
            results['samples'][name].append(result);print(iteration,name,result,flush=True)
finally:
    if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
    results['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
    (E/'runtime-results.json').write_text(json.dumps(results,indent=2))
