from pathlib import Path
import hashlib,json,zipfile
E=Path('/root/openmktr-next-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');S=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
report=R/'docs/openmktr-next-optimizations-2026-10-30.md';results=R/'validation/openmktr-next-optimizations-results.json'
data=json.loads(results.read_text());data['restoration']=json.loads((E/'restoration.json').read_text())
results.write_text(json.dumps(data,indent=2)+'\n');(E/'summary.json').write_text(json.dumps(data,indent=2)+'\n')
hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((R/'src').glob('*')) if p.suffix in ('.cc','.h')}
(E/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
files={('raw/'+p.name):p.read_bytes() for p in E.iterdir() if p.is_file() and p.suffix in ('.json','.log','.sha256','.txt')}
files.update({('scripts/'+p.name):p.read_bytes() for p in S.glob('omktr-next-*.py')})
files['scripts/verify_release_archive.py']=(R/'validation/verify_release_archive.py').read_bytes()
files['report.md']=report.read_bytes()
manifest={name:dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest()) for name,content in sorted(files.items())}
archive=R/'validation/evidence/openmktr-next-optimizations-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,content in sorted(files.items()):z.writestr(name,content)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,item in manifest.items():
        content=z.read(name);assert len(content)==item['bytes'] and hashlib.sha256(content).hexdigest()==item['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix('.zip.sha256').write_text(sha+'  '+archive.name+'\n')
data['evidence']=dict(archive=str(archive.relative_to(R)),sha256=sha,manifest_verified_files=len(manifest),bytes=archive.stat().st_size,excluded='Large build trees, runtime contexts and binaries remain locally; no raw variable contexts are included.')
results.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data['evidence'],indent=2))
