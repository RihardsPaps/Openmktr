from pathlib import Path
import hashlib,json,statistics
E=Path('/root/openmktr-next-20261030');P=Path('/root/openmktr-implemented-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool')
audit=json.loads((E/'audit-results.json').read_text());front=audit['front'];runtime=json.loads((E/'runtime-results.json').read_text());helpers=json.loads((E/'helpers-results.json').read_text())
means={}
for state in ('cold','warm'):
    names={variant:[f'{state}-{variant}-{n}' for n in ((1,3) if state=='warm' and variant=='off' else (1,2))] for variant in ('adaptive','off')}
    means[state]=dict(samples=names,**{variant:statistics.mean(front[n]['wall_seconds'] for n in samples) for variant,samples in names.items()})
    means[state]['saving_seconds']=means[state]['adaptive']-means[state]['off']
for result in (runtime,helpers):
    result['medians']={k:{x:statistics.median(s[x] for s in v) for x in ('wall_seconds','cpu_seconds')} for k,v in result['samples'].items()}
pairs=[]
for name in ('pair1','pair2'):
    r=json.loads((P/name/'report.json').read_text())
    pairs.append({lane:dict(seconds=r['runs'][lane+'-build']['wall_seconds'],cpu_seconds=r['runs'][lane+'-build']['user_seconds']+r['runs'][lane+'-build']['system_seconds'],cores=r['runs'][lane+'-build']['average_cpu_cores']) for lane in ('gnu','aggressive')})
aggregate={lane:{metric:statistics.mean(pair[lane][metric] for pair in pairs) for metric in ('seconds','cpu_seconds','cores')} for lane in ('gnu','aggressive')}
aggregate['gap_seconds']=aggregate['aggressive']['seconds']-aggregate['gnu']['seconds']
aggregate['gap_percent']=100*aggregate['gap_seconds']/aggregate['gnu']['seconds']
aggregate['extra_cpu_seconds']=aggregate['aggressive']['cpu_seconds']-aggregate['gnu']['cpu_seconds']
aggregate['extra_cpu_seconds_divided_by_32']=aggregate['extra_cpu_seconds']/32
aggregate['capacity_shortfall_difference_seconds']=aggregate['gap_seconds']-aggregate['extra_cpu_seconds_divided_by_32']
largest=max(audit['inventory']['contexts'],key=lambda d:d['bytes'])
potential_context_cpu=(runtime['medians']['libreoffice']['cpu_seconds']-runtime['medians']['small']['cpu_seconds'])*largest['references']/256
projection=dict(kind='conditional arithmetic, not a measured full build',front_saving_seconds=means['cold']['saving_seconds'],front_saving_fraction_of_gap=means['cold']['saving_seconds']/aggregate['gap_seconds'],remaining_gap_if_front_saving_transfers_percent=100*(aggregate['gap_seconds']-means['cold']['saving_seconds'])/aggregate['gnu']['seconds'],context_cpu_difference_scaled_to_3454_recipes=potential_context_cpu,context_ideal_32_core_seconds=potential_context_cpu/32)
current=hashlib.sha256((P/'pair1/aggressive/build/.openmktr/build.ninja').read_bytes()).hexdigest()
initial=json.loads((E/'environment.json').read_text())['original_graph_sha256']
result=dict(date='2026-10-30',status='investigation complete; optimizations proposed, not implemented',jobs=32,wsl_memory_gib=30,wsl_swap_gib=16,binary_sha256=hashlib.sha256((P/'omktr-candidate18').read_bytes()).hexdigest(),authoritative_full_comparison=aggregate,front_means=means,conditional_projection=projection,front=audit,runtime=runtime,helpers=helpers,excluded_sample=dict(name='warm-off-2',reason='Concurrent read-only graph inventory; replaced with warm-off-3'),correctness=dict(generation_commands_passed=9,runtime_outputs_verified=sum(s['verified_outputs'] for v in runtime['samples'].values() for s in v),helper_outputs_verified=sum(s['verified_outputs'] for v in helpers['samples'].values() for s in v),original_graph_unchanged=current==initial,original_graph_sha256=current,source_integrity=(E/'source-integrity.log').read_text().strip()),limitations=['No production source changes or new complete GNU/Openmktr pair in this investigation.','Generation controls exclude the main Ninja build and are not no-op timings.','Filesystem caches were not flushed; populated-tree timings vary.','Cold target names and normalized configurations match; eight rule assignments differ across different-length build paths, crossing the 4096-byte script-sidecar threshold (including restat selection). These are not claimed byte-identical graphs.','Runtime context is 26.70 MB; do not compare absolute fixture timing with the previous 32.74 MB fixture as a new code speedup.','Helper fixture omits production state certificates, FIFO contention and large environment scripts.','CPU/32 accounting is not causal attribution or a predicted wall-time saving.'])
assert result['correctness']['original_graph_unchanged']
assert '147364 original files/symlinks checked; 0 differ' in result['correctness']['source_integrity']
assert all(audit['all_target_names_match'].values())
assert len({v['normalized_config_sha256'] for k,v in front.items() if k.startswith('cold')})==1
(E/'summary.json').write_text(json.dumps(result,indent=2))
(R/'validation/openmktr-next-optimizations-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(means=means,aggregate=aggregate,projection=projection,correctness=result['correctness']),indent=2))
