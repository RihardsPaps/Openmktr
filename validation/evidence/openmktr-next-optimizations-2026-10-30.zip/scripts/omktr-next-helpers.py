from pathlib import Path
import concurrent.futures,json,os,subprocess,time
E=Path('/root/openmktr-next-20261030');B='/root/openmktr-implemented-20261030/omktr-candidate18'
root=E/'helper-fixture';root.mkdir()
env=dict(os.environ)
for k in list(env):
    if k.startswith(('KATI_','OMKTR_')) or k in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):env.pop(k)
results=dict(jobs=os.cpu_count(),recipes_per_batch=512,samples={k:[] for k in ('shell','supervisor','supervisor-and-guard')})
assert results['jobs']==32
assert int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])>29_000_000
(root/'seed').write_text('ready');old=time.time()-60;os.utime(root/'seed',(old,old))
def invoke(item):
    name,i=item;cmd=f'printf ready > out{i}'
    if name=='shell':args=['/bin/sh','-c',cmd]
    else:
        if name=='supervisor-and-guard':cmd=f'{B} --internal-low-resolution-up-to-date out{i} 1 0 seed || '+cmd
        args=[B,'--internal-run-recipe','/bin/sh','-c',cmd]
    subprocess.run(args,cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
try:
    subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
    for iteration in range(6):
        order=list(results['samples'])
        if iteration%2:order.reverse()
        for name in order:
            for i in range(512):(root/f'out{i}').unlink(missing_ok=True)
            before=os.times();start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
            with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:list(workers.map(invoke,((name,i) for i in range(512))))
            elapsed=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start;after=os.times()
            assert all((root/f'out{i}').read_text()=='ready' for i in range(512))
            sample=dict(wall_seconds=elapsed,cpu_seconds=after.children_user+after.children_system-before.children_user-before.children_system,verified_outputs=512)
            results['samples'][name].append(sample);print(iteration,name,sample,flush=True)
finally:
    if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
    results['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
    (E/'helpers-results.json').write_text(json.dumps(results,indent=2))
