from pathlib import Path
import json,re
E=Path('/root/openmktr-round2-20261030')
for pair in ('pair1','pair2'):
 p=E/pair/'report.json'
 if not p.exists():continue
 r=json.loads(p.read_text());status=r['status'];result=dict(pair=pair,status=status,completed_builds={k:round(v['wall_seconds'],3) for k,v in r['runs'].items() if k.endswith('-build')})
 resource=E/pair/(status+'.resources.jsonl')
 if resource.exists():
  rows=[json.loads(s) for s in resource.read_text().splitlines()];v=rows[-1];offsets=[(x['realtime_ns']-x['monotonic_raw_ns'])/1e9 for x in rows]
  result.update(elapsed_seconds=round(v['elapsed_seconds'],1),processes=v['process_count'],available_memory_gib=round(v['MemAvailable']/1024**2,2),swap_kib=v['swap_used_kib'],largest_clock_step_seconds=round(max([abs(b-a) for a,b in zip(offsets,offsets[1:])] or [0]),5))
 log=E/pair/(status+'.log')
 if log.exists():
  text=log.read_text(errors='replace');result['last_output']=text.splitlines()[-1][:200] if text else ''
  if status.endswith('-build'):result['compile_recipe_starts']=len(re.findall(r'^\[build (?:CXX|C|ASM)\]',text,re.M))
 print(json.dumps(result))

