from pathlib import Path
import json,re
E=Path('/root/openmktr-round2-20261030');phases={}
for p in (E/'front').glob('*-generate.log'):
 lines=p.read_text().splitlines();relevant=[x for x in lines if any(k in x for k in ('make dep time','ninja gen (','eval time','evaluation recording disabled','evaluation recording work','eval makefile','execute included','parse time'))];phases[p.name]=relevant
(E/'front/phase-summary.json').write_text(json.dumps(phases,indent=2))
for p,lines in phases.items():print(p,*lines,sep='\n')
p=E/'pair1/report.json'
if p.exists():
 r=json.loads(p.read_text());print('FULL STATUS:',r['status'])
