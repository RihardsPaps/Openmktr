from pathlib import Path
import subprocess,json,os,shutil,time,concurrent.futures,hashlib
E=Path('/root/openmktr-round2-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');B=E/'omktr-candidate19'
assert B.is_file()
assert os.cpu_count()==32
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
assert int(mem['MemTotal'].split()[0])>29_000_000
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
start_raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
result=dict(jobs=32,meminfo=mem,original_timesync_active=state,binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),runs=[])
(E/'preflight-controller.json').write_text(json.dumps(result,indent=2))
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
def run(name,cmd,log=True):
 print('START',name,flush=True);start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
 if log:
  with (E/(name+'.log')).open('w') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 else:q=subprocess.run(cmd,env=env)
 result['runs'].append(dict(name=name,command=cmd,exit_code=q.returncode,seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start));(E/'preflight-controller.json').write_text(json.dumps(result,indent=2));print('END',name,q.returncode,flush=True)
 if q.returncode:raise RuntimeError(name+' failed')
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
  if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
 before=(R/'tests/bench.py').read_text()
 after=before.replace('"-j4"','"-j32"').replace('for job_count in (1, 4):','for job_count in (32,):').replace('[str(binary), "--ninja",','[str(binary), "--ninja", "-j32",').replace('time.perf_counter()', 'time.clock_gettime(time.CLOCK_MONOTONIC_RAW)')
 (C/'omktr-round2/bench-j32.py').write_text(after)
 run('bench-j32',['chroot',str(C),'python','/omktr-round2/bench-j32.py','/omktr-round2/omktr','--baseline','/omktr-speed-implementation/omktr','--repeats','3'])
 run('incremental-j32',['python3',str(R/'validation/incremental.py'),'--omktr',str(B),'--cc','/usr/bin/clang-18','--make','/usr/bin/make','--jobs','32','--output',str(E/'incremental-j32')])
 run('runtime-controls',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-runtime-bench.py'])
 run('front-controls',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-front.py'])
 result['pass']=True
finally:
 if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 result['raw_elapsed_seconds']=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start_raw
 result['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 (E/'preflight-controller.json').write_text(json.dumps(result,indent=2))

