$ErrorActionPreference = 'Continue'
$round2Start = Get-Date
$round2Watch = [System.Diagnostics.Stopwatch]::StartNew()
$round2Phases = New-Object 'System.Collections.Generic.List[object]'
wsl -d Ubuntu-24.04 -u root -- python3 /mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-host-controls.py 2>&1 | ForEach-Object {
    $round2Line = [string]$_
    if ($round2Line -match '^phase-start (\S+)$') { $round2Phases.Add(@{ phase = $Matches[1]; event = 'start'; seconds = $round2Watch.Elapsed.TotalSeconds }) }
    if ($round2Line -match '^(\S+) (-?\d+) ([\d.]+)$') { $round2Phases.Add(@{ phase = $Matches[1]; event = 'end'; seconds = $round2Watch.Elapsed.TotalSeconds; reported_exit_code = [int]$Matches[2]; guest_raw_seconds = [double]$Matches[3] }) }
    $round2Line
} | Tee-Object -FilePath C:\Users\Harry\AppData\Local\Temp\omktr-round2-host-controls-console.log
$round2Exit = $LASTEXITCODE
$round2Watch.Stop()
@{ start = $round2Start.ToUniversalTime().ToString('o'); end = (Get-Date).ToUniversalTime().ToString('o'); seconds = $round2Watch.Elapsed.TotalSeconds; exit_code = $round2Exit; phase_observations = $round2Phases.ToArray() } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 C:\Users\Harry\AppData\Local\Temp\omktr-round2-host-controls-timing.json
exit $round2Exit
