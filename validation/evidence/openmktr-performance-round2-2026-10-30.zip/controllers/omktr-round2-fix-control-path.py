from pathlib import Path
import shutil
E=Path('/root/openmktr-round2-20261030');a=E/'wrong-ninja-path';a.mkdir()
for name in ('incremental-j32-final','incremental-j32-final.log','verified-performance-controls.json'):shutil.move(str(E/name),a/name)
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-stable-controls.py');s=p.read_text().replace("results=dict(jobs=32,", "env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])\nresults=dict(jobs=32,").replace('q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)','q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)');p.write_text(s)
