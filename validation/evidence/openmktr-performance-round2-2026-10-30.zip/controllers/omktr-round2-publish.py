from pathlib import Path
import json,statistics,hashlib,zipfile,re
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E=Path('/root/openmktr-round2-20261030');D=Path('/root/universal-tool-campaign-20260927/chimera-root-complete/omktr-round2');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
name='openmktr-performance-round2-2026-10-30'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
previous=read(R/'validation/openmktr-performance-results.json');reports={k:read(E/k/'report.json') for k in ('pair1','pair2')}
checks=read(E/'checks.json');assert len(checks)==38 and all(x['exit_code']==0 for x in checks)
extra=read(E/'extra-checks.json');assert all(x['exit_code']==0 for x in extra)
controller=read(E/'controller.json');preflight=read(E/'host-performance-controls.json');assert controller['pass'] and preflight['pass']
windows=read(T/'omktr-round2-windows-timing.json');assert windows['exit_code']==0
windows_builds={}
for pair in ('pair1','pair2'):
 for lane in ('gnu','aggressive'):
  events={x['event']:x['seconds'] for x in windows['phase_observations'] if x['pair']==pair and x['phase']==lane+'-build'}
  assert set(events)=={'start','end'}
  measured=events['end']-events['start'];raw=reports[pair]['runs'][lane+'-build']['wall_seconds']
  windows_builds[pair+'-'+lane]=dict(windows_seconds=measured,linux_raw_seconds=raw,difference_seconds=measured-raw,difference_percent=100*(measured/raw-1))
# Preserve guest diagnostics, and use independently captured Windows phase times.
host_phases={}
for event in windows['phase_observations']:
 host_phases.setdefault((event['pair'],event['phase']),{})[event['event']]=event['seconds']
for pair,r in reports.items():
 for label,run in r['runs'].items():
  stamps=host_phases[(pair,label)];assert set(stamps)=={'start','end'}
  run['guest_raw_wall_seconds']=run['wall_seconds'];run['wall_seconds']=stamps['end']-stamps['start'];run['elapsed_clock']='Windows Stopwatch'
  run['average_cpu_cores']=(run['user_seconds']+run['system_seconds'])/run['wall_seconds']
 for lane,data in r['lanes'].items():
  data['guest_configure_through_build_seconds']=data['configure_through_build_seconds']
  data['configure_through_build_seconds']=host_phases[(pair,lane+'-build')]['end']-host_phases[(pair,lane+'-configure')]['start']
controls_clock=read(T/'omktr-round2-host-controls-timing.json');assert controls_clock['exit_code']==0
control_phases={}
for event in controls_clock['phase_observations']:control_phases.setdefault(event['phase'],{})[event['event']]=event['seconds']
def control_seconds(label):
 values=control_phases[label];assert set(values)=={'start','end'}
 return values['end']-values['start']
restoration=read(E/'restoration.json');assert restoration['config_sha256']==restoration['original_config_sha256'] and restoration['timesync_active']
incremental=read(E/'incremental-j32-final/report.json');assert not incremental['release_blocked']
freeze=read(E/'freeze.json');binary=read(E/'binary.json');assert binary['sha256']==freeze['binary_sha256']==controller['binary_sha256']==hashlib.sha256((E/'omktr-candidate19').read_bytes()).hexdigest()
for path,h in freeze['source_sha256'].items():assert h==hashlib.sha256((R/path).read_bytes().replace(b'\r\n',b'\n')).hexdigest()
rows=[];verification={}
for pair,r in reports.items():
 assert r['binary_sha256']==binary['sha256']
 assert r['lanes']['gnu']['normalized_config_sha256']==r['lanes']['aggressive']['normalized_config_sha256']
 assert all(x['exit_code']==0 for x in r['runs'].values())
 for lane in r['lanes'].values():assert len(lane['repeat_checks'])==3 and not any(x['blocking_changes'] for x in lane['repeat_checks'])
 g=r['runs']['gnu-build']['wall_seconds'];o=r['runs']['aggressive-build']['wall_seconds']
 rows.append(dict(pair=pair,order=r['comparison_lanes'],gnu_seconds=g,openmktr_seconds=o,gap_percent=100*(o/g-1)))
 comp=read(E/pair/'installed-comparison.json');control=read(E/pair/'gnu-same-path-v19.json')
 assert control['pass'] and control['source_pristine_after_control'] and all(control['measured_tree_intact'].values())
 verification[pair]=dict(artifact_comparison=comp,same_path_control=control)
g=statistics.mean(x['gnu_seconds'] for x in rows);o=statistics.mean(x['openmktr_seconds'] for x in rows);gap=100*(o/g-1)
old=previous['aggregate'];oldgap=old['remaining_gap_percent']
aggregate=dict(gnu_mean_seconds=g,openmktr_mean_seconds=o,remaining_gap_seconds=o-g,remaining_gap_percent=gap,previous_gap_percent=oldgap,percentage_points_closed=oldgap-gap,remaining_percentage_gap_closed_percent=100*(oldgap-gap)/oldgap,previous_gap_seconds=old['remaining_gap_seconds'],gap_seconds_reduced=old['remaining_gap_seconds']-(o-g),candidate_seconds_saved=old['openmktr_mean_seconds']-o,candidate_time_reduction_percent=100*(old['openmktr_mean_seconds']-o)/old['openmktr_mean_seconds'])
runtime=read(E/'runtime-ab-host.json');front={p.stem:read(p) for p in (E/'front-host').glob('*-generate.json')};front_env=read(E/'front-host/environment.json');assert front_env['original_graph_unchanged']
for label,row in front.items():row['guest_raw_wall_seconds']=row['wall_seconds'];row['wall_seconds']=control_seconds(label);row['elapsed_clock']='Windows Stopwatch'
runtime['guest_medians']=runtime['medians']
for mode,samples in runtime['samples'].items():
 for i,row in enumerate(samples):row['guest_raw_wall_seconds']=row['wall_seconds'];row['wall_seconds']=control_seconds('runtime-'+mode+'-'+str(i))
runtime['medians']={k:{f:statistics.median(row[f] for row in v) for f in ('wall_seconds','cpu_seconds')} for k,v in runtime['samples'].items()};runtime['elapsed_clock']='Windows Stopwatch'
summary=dict(status='verified',date='2026-10-30',jobs=32,wsl_memory_gib=30,wsl_swap_gib=16,prior_verified_comparison=dict(aggregate=old,candidate=previous['candidate']),candidate=binary,pairs=rows,aggregate=aggregate,normal_and_sanitizer_checks=checks,extra_checks=extra,preflight=preflight,incremental_differential=dict(report=incremental,timing_qualification='Correctness accepted; guest timings are excluded from the speed claim'),synthetic_bench=read(E/'bench-j32-host.log'),runtime_fixture=runtime,generation_controls=front,benchmark={p:dict(runs=r['runs'],configure_options=r['configure_options'],versions=r['versions'],lanes={k:{f:v[f] for f in ('normalized_config_sha256','configure_through_build_seconds','repeat_checks')} for k,v in r['lanes'].items()},verification=verification[p]) for p,r in reports.items()},clock=dict(linux_raw_seconds=controller['raw_elapsed_seconds'],windows_stopwatch_seconds=windows['seconds'],difference_seconds=windows['seconds']-controller['raw_elapsed_seconds'],guest_adjustment_events=sum(len(run['clock_validation']['realtime_discontinuities_seconds']) for r in reports.values() for run in r['runs'].values()),windows_builds=windows_builds,timing_authority='Windows Stopwatch',control_phase_observations=controls_clock),restoration=restoration,freeze=freeze,ci=read(E/'ci-status.json'),local_evidence=str(E))
(R/'validation/openmktr-performance-round2-results.json').write_text(json.dumps(summary,indent=2)+'\n')
clean_rows='\n'.join(f"| {x['pair']} ({'GNU first' if x['order'][0]=='gnu' else 'Openmktr first'}) | {x['gnu_seconds']:.3f} | {x['openmktr_seconds']:.3f} | {x['gap_percent']:+.2f}% |" for x in rows)
repeat_rows='\n'.join('| '+pair+' | '+('GNU' if lane=='gnu' else 'Openmktr')+' | '+' | '.join(f"{r['runs'][lane+'-noop-'+str(i)]['wall_seconds']:.3f}" for i in (1,2,3))+' |' for pair,r in reports.items() for lane in ('gnu','aggressive'))
front_rows='\n'.join(f"| {key} | {v['wall_seconds']:.3f} | {v['cpu_seconds']:.3f} | {v['maxrss_kib']/1024:.1f} |" for key,v in sorted(front.items()))
runtime_rows='\n'.join(f"| {key} | {v['wall_seconds']:.3f} | {v['cpu_seconds']:.3f} |" for key,v in runtime['medians'].items())
artifact_rows='\n'.join(f"| {pair} | {len(v['artifact_comparison']['raw_identical'])} | {len(v['artifact_comparison']['zip_payload_identical'])} | {len(v['artifact_comparison']['prefix_identical'])} | {len(v['same_path_control']['libraries'])} | {len(v['same_path_control']['objects'])} / {v['artifact_comparison']['objects']['candidate_count']} |" for pair,v in verification.items())
cpu={lane:statistics.mean(r['runs'][lane+'-build']['user_seconds']+r['runs'][lane+'-build']['system_seconds'] for r in reports.values()) for lane in ('gnu','aggressive')}
peak=max(v['peak_individual_rss_kib'] for r in reports.values() for k,v in r['runs'].items() if k.startswith('aggressive-noop'))/1024**2
swap=max(v['maximum_swap_used_kib'] for r in reports.values() for v in r['runs'].values())
report=f'''# Openmktr remaining-gap implementation and comparison — 30 October 2026

Two fresh LibreOffice 25.2.7.2 pairs at **32 jobs and 30 GiB configured WSL RAM**
measure a **{gap:.2f}% clean-build gap**, compared with the previously verified
**{oldgap:.2f}%**. This closes **{aggregate['remaining_percentage_gap_closed_percent']:.1f}% of the remaining
percentage gap** ({aggregate['percentage_points_closed']:.2f} percentage points).
The mean elapsed difference is **{o-g:.3f} seconds**.

All four clean builds, twelve repeats, application smoke tests, original-source
audits, and cross-lane artifact controls passed. Two samples per tool show the
observed result on this PC; they do not establish a confidence interval or
universal Makefile compatibility.

## Complete clean-build comparison

| Pair and order | GNU Make (s) | Openmktr Aggressive (s) | Openmktr overhead |
| --- | ---: | ---: | ---: |
{clean_rows}
| Mean | {g:.3f} | {o:.3f} | {gap:+.2f}% |

The prior means were GNU **{old['gnu_mean_seconds']:.3f} s** and Openmktr
**{old['openmktr_mean_seconds']:.3f} s**, a **{old['remaining_gap_seconds']:.3f} s** difference.
The new Openmktr mean is **{aggregate['candidate_seconds_saved']:.3f} s lower**
({aggregate['candidate_time_reduction_percent']:.2f}% of its previous total time).
Gap closure uses `(9.1390663 - new percentage overhead) / 9.1390663`, with
overhead defined as `100 * (Openmktr / GNU - 1)`. It is distinct from total-time
reduction. Historical and new absolute times also include machine/run variation.

The clean timer covers graph preparation and build execution. Configure/bootstrap
and configure-through-build totals are separate in the JSON. Each lane uses a
fresh, unmodified extraction, identical normalized configuration, Clang 18,
disabled ccache, 32 jobs and Ninja 1.13.2 where applicable. Caches were not flushed;
alternating order limits but cannot eliminate order effects. The project binaries
use matched Chimera Clang/LLVM 22.1.8, musl, libc++ and linker flags.

## Implemented optimizations

- Bound evaluation-recording admission inside expressions as well as statements.
  A rolling 65,536-lookup window rejects low-yield recording; a 128-MiB
  identity/fingerprint-work budget bounds large profitable-looking records.
  Active scopes finish with their certificates invalidated, preserving effects.
- Index runtime variable definitions using views into shared-lifetime buffers.
  Construct variable objects and recursive expression trees only when used.
  Preserve lookup, assignment precedence, introspection and target-local behavior.
- Validate large runtime contexts once per Linux launcher invocation and share
  immutable sealed memory with workers. Recheck file and executable identities;
  changed/unavailable contexts fall back to checksummed structural validation.
  Each recipe retains isolated evaluator state. Standalone helpers still work.
- Reuse lexical prerequisite normalization, escaped Ninja target names, and emitted
  normal-prerequisite text after exact dependency-sequence comparison. Preserve
  cycle filtering, duplicates' automatic-variable semantics, target scopes and
  order-only dependencies. Directory-alias sequences keep live filesystem checks.

The new regression tests cover a 70,000-iteration single expansion, nested
side effects, sealed-context reuse, changed/corrupt/unsealed contexts, protected
private descriptor transport, and shared dependency lists with target scopes.
The broader suite caught a generated manifest leaking into wildcard file lists;
its name now uses the existing hidden `.kati_` namespace. No new golden expectation
or known-crash exclusion was used to hide that failure. A further review found
that directory-alias filtering must observe filesystem effects between emitted
edges. The added regression fails on the pre-fix candidate and passes after
excluding directory-alias sequences from fragment sharing.

The measured dependency work is reused within a generation. Arbitrary Makefile
effects still require evaluation; this change does not claim complete graph-free
no-op execution. The investigation's conditional helper fusion and additional
path compression were not supported as speed priorities and are not credited as
implemented speedups.

## Focused controls

Generation-only controls use the same original source/configuration, with fresh
configured build directories or a private overlay of the populated tree. They
are separate observations, not complete build/no-op timings. The original graph
hash is unchanged.

| Generation control | Wall (s) | CPU (s) | Peak individual RSS (MiB) |
| --- | ---: | ---: | ---: |
{front_rows}

The runtime fixture uses the same real 26.7-MB context, 256 output-producing
recipes, 32 workers, and six alternating batches per mode. All **6,144 outputs**
match. Launcher measurements include shared-snapshot preparation; standalone
measurements retain normal context validation. These isolated savings must not
be added mechanically to the clean-build savings.

| Runtime path | Median wall / 256 recipes (s) | Median child CPU (s) |
| --- | ---: | ---: |
{runtime_rows}

The same-toolchain `tests/bench.py` comparison passed using a disposable copy with
all performance job limits set to 32. Its short per-operation guest-clock samples remain diagnostic in the JSON;
they are not used to quantify a speedup. The external 32-job GNU differential incremental
campaign and its harness tests also pass.

## Correctness and repeat builds

| Pair | Tool | Repeat 1 (s) | Repeat 2 (s) | Repeat 3 (s) |
| --- | --- | ---: | ---: | ---: |
{repeat_rows}

All repeats preserve tracked installed payloads, compiler objects, archives and
ZIP outputs. Only the harness's existing permitted metadata timestamp refreshes
are allowed; blocking output changes are zero. Guarded edges can be visited
without rebuilding their outputs.

| Pair | Raw-identical installed entries | Identical ZIP payloads | Prefix-normalized scripts | Same-path ELF checks | Same-path objects / all objects |
| --- | ---: | ---: | ---: | ---: | ---: |
{artifact_rows}

Installed entry sets, directory sets and permissions agree. Differing ELF/object
bytes contain build-path differences: isolated GNU rebuilds at the candidate's
exact paths match all of them byte for byte, and all selected ELF files were
relinked. The measured build trees remain unchanged. No differing entry is ignored.

Writer, Calc and Impress produce PDFs with the expected text in all four lanes;
dynamic-library checks pass. Every lane's **147,364 original source files and
symlinks** match the release archive, and candidate sources remain pristine after
the GNU controls. No third-party source was patched and no NAS was accessed.

Mean clean child CPU totals are **{cpu['gnu']:.1f} CPU-s GNU** and
**{cpu['aggressive']:.1f} CPU-s Openmktr**. Average utilized cores, derived from
those means, are **{cpu['gnu']/g:.2f}** and **{cpu['aggressive']/o:.2f}**.
Peak individual Openmktr repeat RSS is **{peak:.3f} GiB**. These totals do not
independently identify a remaining bottleneck.

## Validation, environment and evidence

All 38 local normal and ASan/UBSan gate commands pass: 181 correctness tests,
43 runtime-recipe tests, 58 graph tests, both 858-scenario snapshot profiles,
recursive execution, exports, regeneration, jobserver/cancellation, packaging
and related suites. No snapshot crash is quarantined. Formatting and the
incremental-campaign harness pass. Deliberate semantic limits such as `-j1`
remain in correctness tests; performance workloads all request 32 jobs.

Docker's Linux daemon is unavailable, so the Docker container gate was not run.
The retained local Chimera environment supplies the reference toolchain and
normal/sanitizer checks. An initial final-candidate incremental controller selected
system Ninja 1.11.1 and was rejected by the required-version check; its failed
evidence is retained, and the final campaign uses Ninja 1.13.2. The GitHub integration returned no workflow runs for
current HEAD; the uncommitted candidate has no remote CI qualification.

A first attempt was excluded after a guest-clock discontinuity during GNU
configuration; a second partial GNU build was excluded for the directory-alias
correctness fix. Neither contributes timing samples. Further clock probes found
that kernel tick/frequency parameters still changed after pausing the guest time
service, including when trying alternative clock sources and clearing pending
NTP corrections. The probes use the documented [adjtimex interface](https://www.man7.org/linux/man-pages/man2/clock_adjtime.2.html).

**All final clean/repeat and focused generation/runtime wall times above use
Windows Stopwatch**, captured independently at each flushed phase-start/end
marker. The final disposable harness retains guest raw-clock observations and
adjustment diagnostics without using them for speed ratios. Artifact and repeat
correctness checks are unchanged. The repository benchmark harness is unchanged.

The full controller measured **{controller['raw_elapsed_seconds']:.3f} guest raw
seconds** and **{windows['seconds']:.3f} Windows Stopwatch seconds**. These are
recorded as different clocks, not treated as interchangeable. Per-build host and
guest readings are retained in the JSON. Both tools had 30 GiB configured RAM
and 16 GiB swap; maximum sampled swap usage was {swap:,} KiB. The original
24-GiB WSL configuration was restored byte for byte, the original clock source
was restored, and the time service is active again.

Candidate SHA-256: `{binary['sha256']}`.

- [Machine-readable results](../validation/openmktr-performance-round2-results.json)
- [Evidence archive](../validation/evidence/{name}.zip)
- [Archive SHA-256](../validation/evidence/{name}.zip.sha256)
- [Prior 9.14% comparison](openmktr-performance-2026-10-30.md)
- [Optimization investigation](openmktr-next-optimizations-2026-10-30.md)

Raw trees, binaries and contexts remain on this PC under `{E}`. The archive
contains selected logs, reproducible controllers, source hashes and the exact
patch relative to the prior candidate. Full runtime contexts and process
environments are excluded. Pre-existing workspace changes remain preserved.
'''
(R/'docs'/f'{name}.md').write_text(report)
p=R/'docs/openmktr-next-optimizations-2026-10-30.md';prior_text=p.read_text()
followup=f'> Follow-up: the [completed implementation and comparison]({name}.md) measures a {gap:.2f}% remaining gap and {aggregate["remaining_percentage_gap_closed_percent"]:.1f}% closure of the prior 9.14% gap. The investigation below is historical.\n\n'
if f'({name}.md)' not in prior_text:
 heading,body=prior_text.split('\n',1);p.write_text(heading+'\n\n'+followup+body.lstrip('\n'))
p=R/'docs/ninja-performance.md';s=p.read_text();marker='## LibreOffice 25.2.7.2 on the local PC\n';assert marker in s
addition=f'\nThe [second implementation round]({name}.md) measures mean clean times of\n**{g:.3f} s GNU** and **{o:.3f} s Openmktr** in two fresh alternating pairs at\n32 jobs and 30 GiB RAM. The **{gap:.2f}% gap** closes **{aggregate["remaining_percentage_gap_closed_percent"]:.1f}% of the\npreviously remaining 9.14% gap**, with full correctness and artifact controls.\n'
if addition.strip() not in s:p.write_text(s.replace(marker,marker+addition,1))
p=R/'validation/evidence/README.md';s=p.read_text();entry=f'\n## Remaining-gap implementation — 30 October 2026\n\n[{name}.zip]({name}.zip) and its [SHA-256]({name}.zip.sha256) retain\ntwo fresh alternating 32-job GNU/Openmktr pairs, normal/sanitizer checks, focused\ncontrols, output verification and controller scripts. The\n[report](../../docs/{name}.md) measures a {gap:.2f}% clean-build gap and\n{aggregate["remaining_percentage_gap_closed_percent"]:.1f}% closure of the previously remaining 9.14% gap.\n'
if entry.strip() not in s:
 s=s.replace('the verified 9.14% result above remains authoritative.', 'the verified 9.14% result above was authoritative at that stage. The remaining-gap implementation below supersedes it.')
 p.write_text(s+entry)
files=[(D/'bench-j32.py','evidence/bench-j32.py'),(E/'benchmark-windows-clock.py','evidence/benchmark-windows-clock.py'),(T/'omktr_round2_clock.py','controllers/omktr_round2_clock.py')]
for directory in ('discarded-clock-attempt','discarded-safety-review'):
 for p in (E/directory/'pair1').iterdir():
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.txt','.patch'):files.append((p,'evidence/'+directory+'/pair1/'+p.name))
for p in E.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.patch'):files.append((p,'evidence/'+p.name))
for folder in ('pair1','pair2','front','front-verified','front-host','gates-attempt1','before-alias-fix','incremental-j32','incremental-j32-final','discarded-clock-attempt','discarded-safety-review','wrong-ninja-path'):
 for p in (E/folder).iterdir() if (E/folder).exists() else []:
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.txt','.patch'):files.append((p,'evidence/'+folder+'/'+p.name))
for p in T.glob('omktr-round2-*'):
 if p.suffix in ('.py','.ps1','.json'):files.append((p,'controllers/'+p.name))
for p in (R/'src').iterdir():
 if p.is_file():files.append((p,'candidate/src/'+p.name))
for path in ('tests/correctness.py','tests/graph_optimizations.py','tests/generated_recipe_reads.py','tests/golden.json','tests/bench.py','build.ninja','.clang-format','LICENSE','NOTICE','tools/gen_version.py','tools/gen_sanitizer_build.py','validation/benchmark_libreoffice.py','validation/compare_libreoffice_outputs.py','validation/verify_release_archive.py','validation/incremental.py'):
 files.append((R/path,'candidate/'+path))
for path in (R/'docs'/f'{name}.md',R/'validation/openmktr-performance-round2-results.json'):files.append((path,str(path.relative_to(R))))
archive=R/'validation/evidence'/f'{name}.zip';manifest={arc:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p,arc in files};assert len(manifest)==len(files)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,arc in files:z.write(p,arc)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for arc,meta in manifest.items():assert hashlib.sha256(z.read(arc)).hexdigest()==meta['sha256']
h=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix('.zip.sha256').write_text(h+'  '+archive.name+'\n')
print(json.dumps(dict(report=str(R/'docs'/f'{name}.md'),aggregate=aggregate,archive_bytes=archive.stat().st_size,archive_sha256=h),indent=2))
