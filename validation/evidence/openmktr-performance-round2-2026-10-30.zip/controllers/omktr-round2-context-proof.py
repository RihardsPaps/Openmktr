from pathlib import Path
import os,json
E=Path('/root/openmktr-round2-20261030');rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  if not any(x.endswith(b'/ninja.bin') for x in args):continue
  cwd=os.readlink(p/'cwd')
  if '/openmktr-round2-20261030/' not in cwd:continue
  descriptors={}
  for f in (p/'fd').iterdir():
   target=os.readlink(f)
   if 'omktr-runtime-context' in target:descriptors[f.name]=target
  rows.append(dict(pid=int(p.name),cwd=cwd,shared_context_descriptors=descriptors))
 except OSError:pass
print(rows)
if rows:(E/'shared-context-production.json').write_text(json.dumps(rows,indent=2))
