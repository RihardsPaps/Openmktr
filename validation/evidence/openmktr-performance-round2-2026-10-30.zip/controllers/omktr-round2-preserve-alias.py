from pathlib import Path
import shutil
E=Path('/root/openmktr-round2-20261030');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp');a=E/'discarded-safety-review';a.mkdir()
for name in ('pair1','pair1-report','controller.json'):
 p=E/name;assert p.resolve().is_relative_to(E.resolve());shutil.move(str(p),a/name)
for name in ('omktr-round2-windows-timing.json','omktr-round2-console.log'):shutil.copy2(T/name,a/name)
a=E/'before-alias-fix';a.mkdir()
for p in [*E.glob('check-*.log'),E/'checks.json',E/'binary.json',E/'omktr-candidate19',E/'freeze.json',E/'implementation.patch',E/'source-sha256.json',E/'extra-checks.json']:
 if p.exists():shutil.copy2(p,a/p.name)
print('Preserved pre-fix binary, validation and partial benchmark evidence')
