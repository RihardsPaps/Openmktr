from pathlib import Path
import subprocess,shutil
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-round2';E=Path('/root/openmktr-round2-20261030')
files=['src/'+n for n in ('command.cc','command.h','dep.cc','expr.cc','expr.h','incremental_eval.cc','incremental_eval.h','main.cc','ninja.cc','symtab.cc','symtab.h')]
for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
for name in files:(D/name).write_bytes((R/name).read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && clang-format -i '+' '.join(files)],check=True)
for name in files:shutil.copy2(D/name,R/name)
subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && ninja -j32 omktr tests'],check=True)
old=E/'gates-attempt1';old.mkdir(exist_ok=True)
for p in [*E.glob('check-*.log'),E/'checks.json']:
 if p.exists():shutil.move(str(p),old/p.name)
subprocess.run(['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-gates.py'],check=True)
