from pathlib import Path
import hashlib,json,os,time,subprocess
E=Path('/root/openmktr-round2-20261030');config=Path('/mnt/c/Users/Harry/.wslconfig');original=Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-original.wslconfig')
for i in range(20):
 active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 if active:break
 time.sleep(.2)
mem=Path('/proc/meminfo').read_text();total=int(mem.split('MemTotal:')[1].split()[0])
result=dict(config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),original_config_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),jobs=os.cpu_count(),memtotal_kib=total,timesync_active=active,clock_source=Path('/sys/devices/system/clocksource/clocksource0/current_clocksource').read_text().strip())
assert result['config_sha256']==result['original_config_sha256']=='359538deb7d243a51603cc594e2df502b5e4a96770dec01a0b5da66b9550e9cb'
assert active and 23_000_000<total<26_000_000 and result['jobs']==32
(E/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
