from pathlib import Path
import subprocess,json,os,shutil,time,concurrent.futures,hashlib
E=Path('/root/openmktr-round2-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');B=E/'omktr-candidate19'
assert B.is_file()
assert os.cpu_count()==32
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
assert int(mem['MemTotal'].split()[0])>29_000_000
state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
clock_path=Path('/sys/devices/system/clocksource/clocksource0/current_clocksource');original_clock=clock_path.read_text().strip()
start_raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
result=dict(jobs=32,meminfo=mem,original_timesync_active=state,binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),runs=[])
(E/'controller.json').write_text(json.dumps(result,indent=2))
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
def run(name,cmd,log=True):
 print('START',name,flush=True);start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
 if log:
  with (E/(name+'.log')).open('w') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 else:q=subprocess.run(cmd,env=env)
 result['runs'].append(dict(name=name,command=cmd,exit_code=q.returncode,seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start));(E/'controller.json').write_text(json.dumps(result,indent=2));print('END',name,q.returncode,flush=True)
 if q.returncode:raise RuntimeError(name+' failed')
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 result['clock_source']=dict(original=original_clock,selected=original_clock)
 result['timing_authority']='Windows Stopwatch per phase; guest clocks are diagnostic'
 print('Windows Stopwatch phase timing enabled',flush=True)
 for source,target in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
  if not (C/target).is_mount():subprocess.run(['mount','--bind',source,str(C/target)],check=True)
 for pair,lanes in [('pair1',['gnu','aggressive']),('pair2',['aggressive','gnu'])]:
  run(pair,['python3',str(E/'benchmark-windows-clock.py'),'--workspace',str(E/pair),'--report',str(E/(pair+'-report')),'--omktr',str(B),'--jobs','32','--repeats','3','--lanes',*lanes,'--pdf-module-path','/root/libreoffice-pair-20261029-200435/pylib'],False)
 assert hashlib.sha256(B.read_bytes()).hexdigest()==result['binary_sha256']
 run('output-verification',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-verify.py'],False)
 result['pass']=True
finally:
 result['clock_source_at_end']=clock_path.read_text().strip()
 clock_path.write_text(original_clock+'\n')
 result['restored_clock_source']=clock_path.read_text().strip()
 if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 result['raw_elapsed_seconds']=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start_raw
 result['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 (E/'controller.json').write_text(json.dumps(result,indent=2))

