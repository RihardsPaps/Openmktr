from pathlib import Path
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-publish.py');s=p.read_text();needle="p=R/'docs/ninja-performance.md';s=p.read_text()"
addition="""p=R/'docs/openmktr-next-optimizations-2026-10-30.md';prior_text=p.read_text()
followup=f'> Follow-up: the [completed implementation and comparison]({name}.md) measures a {gap:.2f}% remaining gap and {aggregate["remaining_percentage_gap_closed_percent"]:.1f}% closure of the prior 9.14% gap. The investigation below is historical.\\n\\n'
if f'({name}.md)' not in prior_text:
 heading,body=prior_text.split('\\n',1);p.write_text(heading+'\\n\\n'+followup+body.lstrip('\\n'))
"""
s=s.replace(needle,addition+needle)
s=s.replace("if entry.strip() not in s:p.write_text(s+entry)", "if entry.strip() not in s:\n s=s.replace('the verified 9.14% result above remains authoritative.', 'the verified 9.14% result above was authoritative at that stage. The remaining-gap implementation below supersedes it.')\n p.write_text(s+entry)")
p.write_text(s)
