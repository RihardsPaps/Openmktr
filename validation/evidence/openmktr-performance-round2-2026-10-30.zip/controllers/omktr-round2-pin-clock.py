from pathlib import Path
import shutil,json
E=Path('/root/openmktr-round2-20261030');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp');archive=E/'discarded-clock-attempt';archive.mkdir()
for name in ('pair1','pair1-report','controller.json'):
 p=E/name;assert p.resolve().is_relative_to(E.resolve());shutil.move(str(p),archive/name)
for name in ('omktr-round2-windows-timing.json','omktr-round2-console.log'):shutil.copy2(T/name,archive/name)
s=(T/'omktr-round2-compare.py').read_text()
s=s.replace("start_raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)","clock_path=Path('/sys/devices/system/clocksource/clocksource0/current_clocksource');original_clock=clock_path.read_text().strip()\nstart_raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)",1)
s=s.replace(" subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)"," subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)\n clock_path.write_text('hyperv_clocksource_tsc_page\\n')\n result['clock_source']=dict(original=original_clock,selected=clock_path.read_text().strip())\n probe=[]\n for i in range(11):\n  probe.append(dict(raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW),realtime=time.time(),source=clock_path.read_text().strip()))\n  if i<10:time.sleep(2)\n offsets=[x['realtime']-x['raw'] for x in probe];result['clock_probe']=probe\n assert max(abs(b-a) for a,b in zip(offsets,offsets[1:]))<0.05\n assert all(x['source']=='hyperv_clocksource_tsc_page' for x in probe)\n print('Clock probe passed; Hyper-V clock selected',flush=True)",1)
s=s.replace("finally:\n if state:","finally:\n result['clock_source_at_end']=clock_path.read_text().strip()\n clock_path.write_text(original_clock+'\\n')\n result['restored_clock_source']=clock_path.read_text().strip()\n if state:")
(T/'omktr-round2-compare.py').write_text(s)
print('Retained excluded attempt; comparison controller now pins and verifies the guest clock')
