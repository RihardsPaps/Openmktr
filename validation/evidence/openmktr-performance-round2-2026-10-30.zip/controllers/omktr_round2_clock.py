# Local benchmark instrumentation; does not change the real-time clock value.
import ctypes,struct
libc=ctypes.CDLL(None,use_errno=True)
def adjustment(modes=0,offset=0,freq=0,status=0,constant=0):
 data=ctypes.create_string_buffer(256)
 for fmt,pos,value in [('@I',0,modes),('@q',8,offset),('@q',16,freq),('@i',40,status),('@q',48,constant)]:struct.pack_into(fmt,data,pos,value)
 result=libc.adjtimex(data)
 if result<0:raise OSError(ctypes.get_errno(),'adjtimex')
 return {k:struct.unpack_from(fmt,data,pos)[0] for k,fmt,pos in [('offset','@q',8),('freq','@q',16),('status','@i',40),('constant','@q',48),('tick','@q',88)]}
def freeze():
 original=adjustment()
 adjustment(0x2013,status=0x2001)
 adjustment(0x8001)
 adjustment(0x0010,status=0x40)
 current=adjustment();assert current['offset']==0 and current['freq']==0 and not current['status']&1
 return original,current
def restore(original):
 return adjustment(0x0032,freq=original['freq'],status=original['status'],constant=original['constant'])
