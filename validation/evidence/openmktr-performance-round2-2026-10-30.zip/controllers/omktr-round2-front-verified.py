from pathlib import Path
import subprocess,json,os,sys,time,hashlib
E=Path('/root/openmktr-round2-20261030/front-verified');P=Path('/root/openmktr-implemented-20261030');R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E.mkdir(exist_ok=True,parents=True)
report=json.loads((P/'pair1/report.json').read_text());B=P/'omktr-candidate18';run=report['runs']['aggressive-build'];original=Path(run['cwd']);source=Path(run['environment_overrides']['SRCDIR'])
def execute(label,cmd,cwd,env):
 start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
 with (E/(label+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 result=dict(command=cmd,cwd=str(cwd),exit_code=p.returncode,wall_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,cpu_seconds=usage.ru_utime+usage.ru_stime,maxrss_kib=usage.ru_maxrss)
 (E/(label+'.json')).write_text(json.dumps(result,indent=2));print(label,result['exit_code'],round(result['wall_seconds'],3),flush=True);assert p.returncode==0
if '--inner' in sys.argv:
 mode=sys.argv[-1];B=P/'omktr-candidate18' if 'base' in mode else Path('/root/openmktr-round2-20261030/omktr-candidate19');subprocess.run(['mount','--make-rprivate','/'],check=True)
 subprocess.run(['mount','--bind',str(source),str(source)],check=True);subprocess.run(['mount','-o','remount,bind,ro',str(source)],check=True)
 env=dict(os.environ,**report['environment'])
 for k in list(env):
  if k.startswith(('KATI_','OMKTR_')) or k in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):env.pop(k)
 variant='off' if 'off' in mode else 'adaptive';extra=['--disable_graph_optimization=evaluation'] if variant=='off' else []
 if mode.startswith('cold'):
  build=E/mode;build.mkdir()
  execute(mode+'-configure',[str(source/'configure'),*report['configure_options']],build,env)
  execute(mode+'-bootstrap',report['runs']['aggressive-bootstrap']['command'],build,env)
 else:
  overlay=E/mode;overlay.mkdir()
  for name in ('upper','work','merged'):(overlay/name).mkdir()
  subprocess.run(['mount','-t','overlay','overlay','-o',f'lowerdir={original},upperdir={overlay}/upper,workdir={overlay}/work',str(overlay/'merged')],check=True)
  subprocess.run(['mount','--bind',str(overlay/'merged'),str(original)],check=True);build=original
 env.update(SRCDIR=str(source),BUILDDIR=str(build),WORKDIR=str(build/'workdir'))
 cmd=[str(B),'--ninja','--kati_stats','--ninja_stats','--ninja_dir=.openmktr','--graph_optimizations=aggressive',*extra,*[('MAKE='+str(B)) if x.startswith('MAKE=') else x for x in run['command'][3:]]]
 execute(mode+'-generate',cmd,build,env)
else:
 assert os.cpu_count()==32
 assert int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])>29_000_000
 initial=hashlib.sha256((original/'.openmktr/build.ninja').read_bytes()).hexdigest()
 state=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 metadata=dict(jobs=32,meminfo=Path('/proc/meminfo').read_text(),binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),original_graph_sha256=initial)
 try:
  subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
  for mode in ('cold-base-1','cold-next-1','warm-next-1','warm-base-1'):
   subprocess.run(['unshare','-m',sys.executable,__file__,'--inner',mode],check=True)
 finally:
  if state:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
  metadata['original_graph_unchanged']=initial==hashlib.sha256((original/'.openmktr/build.ninja').read_bytes()).hexdigest();metadata['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
  (E/'environment.json').write_text(json.dumps(metadata,indent=2))
