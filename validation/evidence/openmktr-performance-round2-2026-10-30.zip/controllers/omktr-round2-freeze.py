from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E=Path('/root/openmktr-round2-20261030');D=Path('/root/universal-tool-campaign-20260927/chimera-root-complete/omktr-round2')
manifest={};patch=[];changed=[]
for folder in ('src','tests'):
 for p in (R/folder).iterdir():
  if not p.is_file():continue
  q=E/'baseline-source'/folder/p.name
  if not q.is_file():continue
  try:a=q.read_text();b=p.read_text()
  except UnicodeError:continue
  if a!=b:
   name=folder+'/'+p.name;changed.append(name)
   patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='baseline/'+name,tofile='candidate/'+name))
for p in (R/'src').iterdir():
 if p.is_file():
  normalized=p.read_bytes().replace(b'\r\n',b'\n');assert normalized==(D/'src'/p.name).read_bytes(),p
  manifest['src/'+p.name]=hashlib.sha256(normalized).hexdigest()
(E/'implementation.patch').write_text(''.join(patch));(E/'source-sha256.json').write_text(json.dumps(manifest,indent=2))
(E/'freeze.json').write_text(json.dumps(dict(changed_paths=changed,binary_sha256=hashlib.sha256((E/'omktr-candidate19').read_bytes()).hexdigest(),source_sha256=manifest,build_ninja_sha256=hashlib.sha256((D/'build.ninja').read_bytes()).hexdigest()),indent=2))
print('Frozen',len(changed),'changed source/test files',sum(len(s) for s in patch),'patch bytes')
