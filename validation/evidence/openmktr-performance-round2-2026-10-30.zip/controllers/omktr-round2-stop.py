from pathlib import Path
import os,signal,time
found=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:a=(p/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 if len(a)>1 and a[1].endswith(b'/validation/benchmark_libreoffice.py') and b'/root/openmktr-round2-20261030/pair1' in a:found.append(int(p.name))
assert len(found)==1,found
parent=found[0];os.kill(parent,signal.SIGSTOP);children=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  fields=(p/'stat').read_text().rsplit(')',1)[1].split()
  if int(fields[1])==parent:children.append(int(p.name))
 except (OSError,ValueError):pass
for child in children:
 if os.getpgid(child)==child:os.killpg(child,signal.SIGTERM)
 else:os.kill(child,signal.SIGTERM)
os.kill(parent,signal.SIGTERM);os.kill(parent,signal.SIGCONT)
print('Stopped benchmark harness',parent,'and its build process groups',children)
