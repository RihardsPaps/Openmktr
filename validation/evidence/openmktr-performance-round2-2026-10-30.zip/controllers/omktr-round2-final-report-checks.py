from pathlib import Path
import json
E=Path('/root/openmktr-round2-20261030');r=json.loads((E/'incremental-j32-final/report.json').read_text());print('Incremental report keys:',list(r));print('release_blocked:',r['release_blocked'],'performance_defects:',r['performance_defects']);print('Current source files:',json.loads((E/'freeze.json').read_text())['changed_paths'])
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-publish.py');s=p.read_text();needle="freeze=read(E/'freeze.json')"
s=s.replace(needle,"incremental=read(E/'incremental-j32-final/report.json');assert not incremental['release_blocked']\n"+needle)
s=s.replace("preflight=preflight,synthetic_bench=", "preflight=preflight,incremental_differential=dict(report=incremental,timing_qualification='Correctness accepted; guest timings are excluded from the speed claim'),synthetic_bench=")
p.write_text(s)
