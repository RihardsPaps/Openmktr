from pathlib import Path
T=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
s=(T/'omktr-round2-front.py').read_text().replace("/root/openmktr-round2-20261030/front'", "/root/openmktr-round2-20261030/front-verified'")
(T/'omktr-round2-front-verified.py').write_text(s)
s=(T/'omktr-round2-runtime-bench.py').read_text().replace("E/'runtime-fixture'", "E/'runtime-fixture-verified'").replace("E/'runtime-ab.json'", "E/'runtime-ab-verified.json'")
(T/'omktr-round2-runtime-verified.py').write_text(s)
