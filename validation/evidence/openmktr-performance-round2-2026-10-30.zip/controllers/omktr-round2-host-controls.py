from pathlib import Path
import subprocess,json,os,time
E=Path('/root/openmktr-round2-20261030');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete')
assert os.cpu_count()==32 and int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])>29_000_000
active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0;results=dict(jobs=32,runs=[],timing_authority='Windows Stopwatch phase observations')
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True)
 for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
  if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
 commands=[('bench-j32-host',['chroot',str(C),'python','/omktr-round2/bench-j32.py','/omktr-round2/omktr','--baseline','/omktr-speed-implementation/omktr','--repeats','3']),('runtime-controls-host',['python3',str(T/'omktr-round2-runtime-host.py')]),('front-controls-host',['python3',str(T/'omktr-round2-front-host.py')])]
 for name,cmd in commands:
  print('phase-start',name,flush=True);start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
  with (E/(name+'.log')).open('w') as log:
   p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env)
   for line in p.stdout:
    log.write(line);log.flush()
    if name!='bench-j32-host':print(line.rstrip(),flush=True)
   code=p.wait()
  elapsed=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start;results['runs'].append(dict(name=name,command=cmd,exit_code=code,guest_raw_seconds=elapsed));(E/'host-performance-controls.json').write_text(json.dumps(results,indent=2));print(name,code,round(elapsed,6),flush=True)
  assert code==0
 results['pass']=True
finally:
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 results['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 (E/'host-performance-controls.json').write_text(json.dumps(results,indent=2))
