from pathlib import Path
import json
r=json.loads(Path('/root/openmktr-round2-20261030/clock-discipline-probe.json').read_text());print('original',r['original_timex'])
for a,b in zip(r['samples'],r['samples'][1:]):print(round(b['raw']-a['raw'],6),round(b['monotonic']-a['monotonic'],6),round((b['realtime']-b['raw'])-(a['realtime']-a['raw']),6),b['timex'])
