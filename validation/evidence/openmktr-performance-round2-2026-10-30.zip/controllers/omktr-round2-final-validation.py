from pathlib import Path
import subprocess,os,json,shutil
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E=Path('/root/openmktr-round2-20261030');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-round2'
env=dict(os.environ,OMKTR_BINARY=str(E/'before-alias-fix/omktr-candidate19'),PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
with (E/'alias-regression-before.log').open('w') as f:p=subprocess.run(['python3',str(R/'tests/graph_optimizations.py'),'GraphOptimizations.test_dependency_fragments_recheck_directory_aliases_after_effects'],env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode!=0,'Old binary unexpectedly passes regression';print('Regression fails on pre-fix binary, as expected',flush=True)
for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && clang-format -i src/ninja.cc && ninja -j32 omktr tests'],check=True)
shutil.copy2(D/'src/ninja.cc',R/'src/ninja.cc')
for script in ('omktr-round2-gates.py','omktr-round2-extra.py','omktr-round2-freeze.py','omktr-round2-stable-controls.py'):
 subprocess.run(['python3','/mnt/c/Users/Harry/AppData/Local/Temp/'+script],check=True)
