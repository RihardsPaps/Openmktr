from pathlib import Path
import subprocess,json
C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');E=Path('/root/openmktr-round2-20261030')
for a,b in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/b).is_mount():subprocess.run(['mount','--bind',a,str(C/b)],check=True)
commands=["CLANG_FORMAT_FILES='src/command.cc src/dep.cc src/exec.cc src/expr.cc src/expr.h src/flags.cc src/graph_optimization.cc src/graph_optimization.h src/incremental_eval.cc src/incremental_eval.h src/ninja.cc src/symtab.cc src/symtab.h src/command.h src/main.cc' sh clang-format-check",'python tests/incremental_campaign.py']
results=[]
for i,cmd in enumerate(commands):
 with (E/f'extra-check-{i}.log').open('w') as f:q=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && '+cmd],stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(command=cmd,exit_code=q.returncode));print(results[-1],flush=True)
 assert q.returncode==0
(E/'extra-checks.json').write_text(json.dumps(results,indent=2))
