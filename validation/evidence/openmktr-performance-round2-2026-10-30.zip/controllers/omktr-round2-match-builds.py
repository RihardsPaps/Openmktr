from pathlib import Path
import hashlib,json
E=Path('/root/openmktr-round2-20261030');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');baseline=C/'omktr-speed-implementation';candidate=C/'omktr-round2';result={}
for name in ('build.ninja','.clang-format'):
 a=(baseline/name).read_bytes().replace(b'\r\n',b'\n');b=(candidate/name).read_bytes().replace(b'\r\n',b'\n');assert a==b,name;result[name]=hashlib.sha256(a).hexdigest()
result['baseline_source_matches']={p.name:p.read_bytes().replace(b'\r\n',b'\n')==(baseline/'src'/p.name).read_bytes().replace(b'\r\n',b'\n') for p in (E/'baseline-source/src').iterdir() if p.is_file()};assert all(result['baseline_source_matches'].values())
(E/'matched-toolchain-source-check.json').write_text(json.dumps(result,indent=2));print('Baseline source and matched build configuration verified')
