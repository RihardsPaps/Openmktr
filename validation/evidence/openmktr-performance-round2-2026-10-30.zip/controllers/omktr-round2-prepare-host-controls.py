from pathlib import Path
T=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
s=(T/'omktr-round2-front.py').read_text().replace("/root/openmktr-round2-20261030/front'", "/root/openmktr-round2-20261030/front-host'")
s=s.replace(' start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)', " print('phase-start',label,flush=True)\n start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)",1)
(T/'omktr-round2-front-host.py').write_text(s)
s=(T/'omktr-round2-runtime-bench.py').read_text().replace("E/'runtime-fixture'", "E/'runtime-fixture-host'").replace("E/'runtime-ab.json'", "E/'runtime-ab-host.json'")
s=s.replace('  cpu=os.times();start=', "  phase='runtime-'+mode+'-'+str(iteration);print('phase-start',phase,flush=True)\n  cpu=os.times();start=")
s=s.replace('  assert all((root/f\'out{i}\')', "  print(phase,0,round(elapsed,6),flush=True)\n  assert all((root/f'out{i}')")
(T/'omktr-round2-runtime-host.py').write_text(s)
