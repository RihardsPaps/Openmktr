from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,statistics,struct,subprocess,time
E=Path('/root/openmktr-round2-20261030');P=Path('/root/openmktr-implemented-20261030');root=E/'runtime-fixture-verified';root.mkdir()
binaries={'baseline':P/'omktr-candidate18','candidate':E/'omktr-candidate19'}
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
for k in list(env):
 if k.startswith(('KATI_','OMKTR_')) or k in ('MAKEFLAGS','MFLAGS','MAKELEVEL','MAKE'):env.pop(k)
def parts(data):
 out=[]
 while data:
  n=struct.unpack_from('<Q',data)[0];assert n<=len(data)-8;out.append(data[8:8+n]);data=data[8+n:]
 return out
def pack(fields):return b''.join(struct.pack('<Q',len(x))+x for x in fields)
def read(path):return parts(path.read_bytes())[2]
def write(path,payload):
 h=14695981039346656037
 for c in payload:h=((h^c)*1099511628211)&((1<<64)-1)
 path.write_bytes(pack([b'OMKTR_GRAPH1',str(h).encode(),payload]))
(root/'seed').write_text('ready')
(root/'Makefile').write_text('OMKTR_PROFILE_MACRO = OMKTR_PROFILE_READER\nOMKTR_PROFILE_READER = $(shell cat seed)\nall: '+ ' '.join(f'out{i}' for i in range(256))+'\n'+''.join(f'out{i}: seed\n\t@printf %s "$(call $(OMKTR_PROFILE_MACRO))" > $@\n' for i in range(256)))
subprocess.run([str(binaries['candidate']),'--ninja','-j32','all'],cwd=root,env=env,capture_output=True,check=True)
sidecars=sorted(p for p in root.glob('.kati_runtime-*') if not p.name.startswith(('.kati_runtime-context-','.kati_runtime-reads-')));assert len(sidecars)==256
real=max((P/'pair1/aggressive/build/.openmktr').glob('.kati_runtime-context-*'),key=lambda p:p.stat().st_size)
for p in sidecars:
 fields=parts(read(p));assert fields[0]==b'runtime-recipe-v5'
 small=read(root/fields[7].decode());fields[7]=str(real).encode();fields[8]+=small;write(p,pack(fields))
write(root/'.kati_contexts-build.ninja',pack([b'runtime-context-manifest-v1',str(real).encode()]))
original_graph=(root/'build.ninja').read_text();original_launcher=(root/'ninja.sh').read_text()
results=dict(jobs=os.cpu_count(),context_bytes=real.stat().st_size,context_sha256=hashlib.sha256(real.read_bytes()).hexdigest(),samples={k:[] for k in ('baseline-standalone','candidate-standalone','baseline-launcher','candidate-launcher')})
assert results['jobs']==32
assert int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])>29_000_000
for iteration in range(6):
 modes=list(results['samples'])
 if iteration%2:modes.reverse()
 for mode in modes:
  name,kind=mode.split('-');binary=binaries[name]
  for i in range(256):(root/f'out{i}').unlink(missing_ok=True)
  (root/'build.ninja').write_text(original_graph.replace(str(binaries['candidate']),str(binary)))
  (root/'ninja.sh').write_text(original_launcher.replace(str(binaries['candidate']),str(binary)))
  cpu=os.times();start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
  if kind=='standalone':
   def invoke(path):subprocess.run([str(binary),'--internal-evaluate-recipe',str(path)],cwd=root,env=env,capture_output=True,check=True)
   with concurrent.futures.ThreadPoolExecutor(max_workers=32) as workers:list(workers.map(invoke,sidecars))
  else:subprocess.run(['sh','ninja.sh','-j32'],cwd=root,env=env,capture_output=True,check=True)
  elapsed=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start;after=os.times()
  assert all((root/f'out{i}').read_text()=='ready' for i in range(256))
  sample=dict(wall_seconds=elapsed,cpu_seconds=after.children_user+after.children_system-cpu.children_user-cpu.children_system,verified_outputs=256)
  results['samples'][mode].append(sample);print(iteration,mode,sample,flush=True)
results['medians']={k:{field:statistics.median(s[field] for s in v) for field in ('wall_seconds','cpu_seconds')} for k,v in results['samples'].items()}
(E/'runtime-ab-verified.json').write_text(json.dumps(results,indent=2))
