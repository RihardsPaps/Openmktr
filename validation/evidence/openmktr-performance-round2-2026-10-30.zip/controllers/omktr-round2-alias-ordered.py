from pathlib import Path
import subprocess
E=Path('/root/openmktr-round2-20261030');folder=E/'alias-before-ordered';folder.mkdir()
text='.PHONY: all dir\nall: a b dir\na b: dir/\na: .KATI_TAGS = $(if $(shell rmdir dir),removed,removed)\na b:\n\t@printf done > $@\ndir:\n\t@mkdir -p dir\ndir/:\n\t@mkdir -p dir\n'
for name,binary in [('baseline','/root/openmktr-implemented-20261030/omktr-candidate18'),('candidate',str(E/'omktr-candidate19'))]:
 root=folder/name;root.mkdir();(root/'dir').mkdir();(root/'Makefile').write_text(text)
 p=subprocess.run([binary,'--ninja','-j32','--graph_optimizations=aggressive','dir/','all'],cwd=root,text=True,capture_output=True)
 (root/'command.log').write_text(p.stdout+p.stderr);print(name,p.returncode,'dir exists',(root/'dir').exists())
 graph=(root/'build.ninja').read_text();print('\n'.join(x for x in graph.splitlines() if x.startswith('build ')))
 p=subprocess.run(['/root/omktr-graph-optimizations/ninja-1.13.2/ninja','-j32'],cwd=root,text=True,capture_output=True);print('Ninja',p.returncode,p.stdout,p.stderr)
