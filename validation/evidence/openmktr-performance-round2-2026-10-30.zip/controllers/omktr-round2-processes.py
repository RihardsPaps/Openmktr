from pathlib import Path
import os
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  comm=(p/'comm').read_text().strip();args=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if comm in ('ninja','omktr-candidate19') and '--internal-' not in args:print(p.name,comm,os.readlink(p/'cwd'),args[:400])
 except OSError:pass
