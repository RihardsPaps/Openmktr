from pathlib import Path
import ctypes,struct,json
libc=ctypes.CDLL(None);data=ctypes.create_string_buffer(256);rc=libc.adjtimex(data)
print('timex',rc,{k:struct.unpack_from(fmt,data,offset)[0] for k,fmt,offset in [('offset','@q',8),('freq','@q',16),('status','@i',40),('constant','@q',48),('tolerance','@q',64),('tick','@q',88)]})
r=json.loads(Path('/root/openmktr-round2-20261030/verified-performance-controls.json').read_text());samples=r['runs'][0]['samples']
for a,b in zip(samples,samples[1:]):
 delta=(b['realtime']-a['realtime'])-(b['raw']-a['raw'])
 if abs(delta)>.04:print('discontinuity',a,b,'delta',delta)
