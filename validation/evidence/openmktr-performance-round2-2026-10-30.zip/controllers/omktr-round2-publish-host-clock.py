from pathlib import Path
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-publish.py');s=p.read_text()
s=s.replace("preflight=read(E/'verified-performance-controls.json')", "preflight=read(E/'host-performance-controls.json')")
needle="restoration=read(E/'restoration.json')"
insert="""# Preserve guest diagnostics, and use independently captured Windows phase times.
host_phases={}
for event in windows['phase_observations']:
 host_phases.setdefault((event['pair'],event['phase']),{})[event['event']]=event['seconds']
for pair,r in reports.items():
 for label,run in r['runs'].items():
  stamps=host_phases[(pair,label)];assert set(stamps)=={'start','end'}
  run['guest_raw_wall_seconds']=run['wall_seconds'];run['wall_seconds']=stamps['end']-stamps['start'];run['elapsed_clock']='Windows Stopwatch'
  run['average_cpu_cores']=(run['user_seconds']+run['system_seconds'])/run['wall_seconds']
 for lane,data in r['lanes'].items():
  data['guest_configure_through_build_seconds']=data['configure_through_build_seconds']
  data['configure_through_build_seconds']=host_phases[(pair,lane+'-build')]['end']-host_phases[(pair,lane+'-configure')]['start']
controls_clock=read(T/'omktr-round2-host-controls-timing.json');assert controls_clock['exit_code']==0
control_phases={}
for event in controls_clock['phase_observations']:control_phases.setdefault(event['phase'],{})[event['event']]=event['seconds']
def control_seconds(label):
 values=control_phases[label];assert set(values)=={'start','end'}
 return values['end']-values['start']
"""
s=s.replace(needle,insert+needle)
s=s.replace(" and not x['clock_validation']['realtime_discontinuities_seconds']",'')
s=s.replace("runtime=read(E/'runtime-ab-verified.json');front={p.stem:read(p) for p in (E/'front-verified').glob('*-generate.json')};front_env=read(E/'front-verified/environment.json');assert front_env['original_graph_unchanged']", "runtime=read(E/'runtime-ab-host.json');front={p.stem:read(p) for p in (E/'front-host').glob('*-generate.json')};front_env=read(E/'front-host/environment.json');assert front_env['original_graph_unchanged']\nfor label,row in front.items():row['guest_raw_wall_seconds']=row['wall_seconds'];row['wall_seconds']=control_seconds(label);row['elapsed_clock']='Windows Stopwatch'\nruntime['guest_medians']=runtime['medians']\nfor mode,samples in runtime['samples'].items():\n for i,row in enumerate(samples):row['guest_raw_wall_seconds']=row['wall_seconds'];row['wall_seconds']=control_seconds('runtime-'+mode+'-'+str(i))\nruntime['medians']={k:{f:statistics.median(row[f] for row in v) for f in ('wall_seconds','cpu_seconds')} for k,v in runtime['samples'].items()};runtime['elapsed_clock']='Windows Stopwatch'")
s=s.replace("read(E/'bench-j32-verified.log')", "read(E/'bench-j32-host.log')")
s=s.replace('realtime_discontinuities=0,windows_builds=windows_builds', "guest_adjustment_events=sum(len(run['clock_validation']['realtime_discontinuities_seconds']) for r in reports.values() for run in r['runs'].values()),windows_builds=windows_builds,timing_authority='Windows Stopwatch',control_phase_observations=controls_clock")
s=s.replace('All samples, including small regressions\nand noise, remain in the JSON.', 'Guest-clock samples remain diagnostic in the JSON.')
s=s.replace('Full samples, including small regressions\nand noise, remain in the JSON.', 'Its short per-operation guest-clock samples remain diagnostic in the JSON;\nthey are not used to quantify a speedup.')
start=s.index('A first attempt was excluded after a guest-clock discontinuity')
end=s.index('Candidate SHA-256:',start)
s=s[:start]+'''A first attempt was excluded after a guest-clock discontinuity during GNU
configuration; a second partial GNU build was excluded for the directory-alias
correctness fix. Neither contributes timing samples. Further clock probes found
that kernel tick/frequency parameters still changed after pausing the guest time
service, including when trying alternative clock sources and clearing pending
NTP corrections. The probes use the documented [adjtimex interface](https://www.man7.org/linux/man-pages/man2/clock_adjtime.2.html).

**All final clean/repeat and focused generation/runtime wall times above use
Windows Stopwatch**, captured independently at each flushed phase-start/end
marker. The final disposable harness retains guest raw-clock observations and
adjustment diagnostics without using them for speed ratios. Artifact and repeat
correctness checks are unchanged. The repository benchmark harness is unchanged.

The full controller measured **{controller['raw_elapsed_seconds']:.3f} guest raw
seconds** and **{windows['seconds']:.3f} Windows Stopwatch seconds**. These are
recorded as different clocks, not treated as interchangeable. Per-build host and
guest readings are retained in the JSON. Both tools had 30 GiB configured RAM
and 16 GiB swap; maximum sampled swap usage was {swap:,} KiB. The original
24-GiB WSL configuration was restored byte for byte, the original clock source
was restored, and the time service is active again.

'''+s[end:]
s=s.replace("'front-verified','gates-attempt1'", "'front-verified','front-host','gates-attempt1'")
s=s.replace(" for p in (E/folder).iterdir():", " for p in (E/folder).iterdir() if (E/folder).exists() else []:")
s=s.replace("files=[(D/'bench-j32.py','evidence/bench-j32.py')]", "files=[(D/'bench-j32.py','evidence/bench-j32.py'),(E/'benchmark-windows-clock.py','evidence/benchmark-windows-clock.py'),(T/'omktr_round2_clock.py','controllers/omktr_round2_clock.py')]")
p.write_text(s)
