from pathlib import Path
import subprocess,shutil,json,sys,time,shlex,hashlib
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');D=C/'omktr-round2';E=Path('/root/openmktr-round2-20261030')
for p in (R/'src').iterdir():
 if p.is_file():
  q=D/'src'/p.name;data=p.read_bytes().replace(b'\r\n',b'\n')
  if not q.exists() or q.read_bytes()!=data:q.write_bytes(data)
for p in (R/'tests').glob('*.py'):shutil.copy2(p,D/'tests'/p.name)
for name in ('build.ninja','Dockerfile','clang-format-check','CONTRIBUTING.md'):
 shutil.copy2(R/name,D/name)
for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
 if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
label=sys.argv[1];results=[]
commands=['ninja -j32 omktr tests']+sys.argv[2:]
for i,cmd in enumerate(commands):
 start=time.monotonic()
 with (E/f'{label}-{i}.log').open('w') as f:p=subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && '+cmd],stdout=f,stderr=subprocess.STDOUT)
 result=dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start);results.append(result);(E/f'{label}.json').write_text(json.dumps(results,indent=2));print(result,flush=True)
 if p.returncode:sys.exit(p.returncode)
lines=subprocess.check_output(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && ninja -t commands omktr'],text=True).splitlines()
link=shlex.split(lines[-1]);runtime='/root/libreoffice-improvements-20261029/runtime';link=link[:link.index('-o')]+['-Wl,--dynamic-linker='+runtime+'/libc.so','-Wl,-rpath,'+runtime,'-o','omktr-host']
subprocess.run(['chroot',str(C),'/bin/sh','-c','cd /omktr-round2 && '+shlex.join(link)],check=True)
shutil.copy2(D/'omktr-host',E/'omktr-candidate19')
(E/'binary.json').write_text(json.dumps(dict(link=link,sha256=hashlib.sha256((E/'omktr-candidate19').read_bytes()).hexdigest()),indent=2))
