from pathlib import Path
import os,json,collections
counts=collections.Counter();rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0');cwd=os.readlink(p/'cwd')
  if '/openmktr-round2-20261030/pair1/aggressive/build' not in cwd:continue
  counts[args[0].decode(errors='replace')]+=1
  if any('ninja' in x.decode(errors='replace') for x in args[:2]):rows.append((p.name,cwd,[x.decode(errors='replace')[:200] for x in args[:4]]))
 except OSError:pass
print(counts);print(rows[:10])
