from pathlib import Path
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
s=(p/'omktr-implemented-compare.py').read_text().replace('/root/openmktr-implemented-20261030','/root/openmktr-round2-20261030').replace('omktr-candidate18','omktr-candidate19')
s=s.replace("(C/'omktr-speed-implementation/bench-j32.py')", "(C/'omktr-round2/bench-j32.py')")
s=s.replace("'/omktr-speed-implementation/bench-j32.py','/omktr-speed-implementation/omktr','--baseline','/lo-improvements-candidate/omktr'", "'/omktr-round2/bench-j32.py','/omktr-round2/omktr','--baseline','/omktr-speed-implementation/omktr'")
start=s.index(' # Same real context,')
end=s.index(' for pair,lanes',start)
s=s[:start]+" run('runtime-controls',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-runtime-bench.py'])\n run('front-controls',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-front.py'])\n"+s[end:]
s=s.replace("result=dict(jobs=32,meminfo=mem,original_timesync_active=state,runs=[])","result=dict(jobs=32,meminfo=mem,original_timesync_active=state,binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),runs=[])\n(E/'controller.json').write_text(json.dumps(result,indent=2))")
s=s.replace(" result['pass']=True", " assert hashlib.sha256(B.read_bytes()).hexdigest()==result['binary_sha256']\n run('output-verification',['python3','/mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-verify.py'],False)\n result['pass']=True")
(p/'omktr-round2-compare.py').write_text(s)
for name in ('output-control','verify'):
 s=(p/('omktr-implemented-'+name+'.py')).read_text().replace('/root/openmktr-implemented-20261030','/root/openmktr-round2-20261030').replace('omktr-implemented-output-control.py','omktr-round2-output-control.py').replace('v18','v19')
 (p/('omktr-round2-'+name+'.py')).write_text(s)
s=(p/'omktr-implemented-extra.py').read_text().replace('/root/openmktr-implemented-20261030','/root/openmktr-round2-20261030').replace('/omktr-speed-implementation','/omktr-round2')
s=s.replace('src/symtab.cc\'','src/symtab.cc src/symtab.h src/command.h src/main.cc\'')
(p/'omktr-round2-extra.py').write_text(s)
print('Prepared comparison, correctness controls, and extra checks')
