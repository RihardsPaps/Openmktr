from pathlib import Path
import subprocess,time,json,threading,os
E=Path('/root/openmktr-round2-20261030');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp');C=Path('/root/universal-tool-campaign-20260927/chimera-root-complete');clock=Path('/sys/devices/system/clocksource/clocksource0/current_clocksource');original=clock.read_text().strip();active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
assert os.cpu_count()==32 and int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])>29_000_000
env=dict(os.environ,PATH='/root/omktr-graph-optimizations/ninja-1.13.2:'+os.environ['PATH'])
results=dict(jobs=32,original_clock=original,original_timesync_active=active,runs=[])
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True);clock.write_text('hyperv_clocksource_tsc_page\n')
 for s,t in [('/proc','proc'),('/dev','dev'),('/dev/pts','dev/pts')]:
  if not (C/t).is_mount():subprocess.run(['mount','--bind',s,str(C/t)],check=True)
 commands=[('incremental-j32-final',['python3','/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool/validation/incremental.py','--omktr',str(E/'omktr-candidate19'),'--cc','/usr/bin/clang-18','--make','/usr/bin/make','--jobs','32','--output',str(E/'incremental-j32-final')]),('bench-j32-verified',['chroot',str(C),'python','/omktr-round2/bench-j32.py','/omktr-round2/omktr','--baseline','/omktr-speed-implementation/omktr','--repeats','3']),('runtime-controls-verified',['python3',str(T/'omktr-round2-runtime-verified.py')]),('front-controls-verified',['python3',str(T/'omktr-round2-front-verified.py')])]
 for name,cmd in commands:
  stop=threading.Event();samples=[]
  def monitor():
   while not stop.is_set():
    samples.append(dict(raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW),realtime=time.time(),source=clock.read_text().strip()))
    stop.wait(2)
  thread=threading.Thread(target=monitor);thread.start();start=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)
  try:
   with (E/(name+'.log')).open('w') as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
  finally:stop.set();thread.join()
  offsets=[x['realtime']-x['raw'] for x in samples];jumps=[b-a for a,b in zip(offsets,offsets[1:]) if abs(b-a)>0.05]
  result=dict(name=name,command=cmd,exit_code=q.returncode,raw_seconds=time.clock_gettime(time.CLOCK_MONOTONIC_RAW)-start,samples=samples,clock_jumps=jumps);results['runs'].append(result);(E/'verified-performance-controls.json').write_text(json.dumps(results,indent=2));print(name,q.returncode,round(result['raw_seconds'],3),'clock jumps',jumps,flush=True)
  assert q.returncode==0 and not jumps and all(x['source']=='hyperv_clocksource_tsc_page' for x in samples)
 results['pass']=True
finally:
 clock.write_text(original+'\n')
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 results['restored_clock']=clock.read_text().strip();results['restored_timesync_active']=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
 (E/'verified-performance-controls.json').write_text(json.dumps(results,indent=2))
