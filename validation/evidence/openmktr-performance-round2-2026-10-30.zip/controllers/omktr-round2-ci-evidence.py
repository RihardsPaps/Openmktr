from pathlib import Path
import json,hashlib,subprocess
E=Path('/root/openmktr-round2-20261030')
(E/'ci-status.json').write_text(json.dumps(dict(repository='RihardsPaps/Openmktr',commit='38ddf6d0e4c8bee9e5449992ed1c412205d6e56c',provider='installed GitHub integration',workflow_runs=[],qualification='No workflow runs returned for current HEAD; local uncommitted candidate is not covered by remote CI.'),indent=2))
for folder in ('src','tests'):
 base=E/'baseline-source'/folder
 print(folder,'baseline files',sum(p.is_file() for p in base.iterdir()))
print('Current candidate:',hashlib.sha256((E/'omktr-candidate19').read_bytes()).hexdigest())
