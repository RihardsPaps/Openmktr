from pathlib import Path
import json,time,subprocess
from omktr_round2_clock import freeze,restore,adjustment
E=Path('/root/openmktr-round2-20261030');p=Path('/sys/devices/system/clocksource/clocksource0/current_clocksource');original=p.read_text().strip();active=subprocess.run(['systemctl','is-active','--quiet','systemd-timesyncd']).returncode==0
samples=[];state=None
try:
 subprocess.run(['systemctl','stop','systemd-timesyncd'],check=True);p.write_text('hyperv_clocksource_msr\n');state,initial=freeze()
 for i in range(21):
  samples.append(dict(raw=time.clock_gettime(time.CLOCK_MONOTONIC_RAW),monotonic=time.monotonic(),realtime=time.time(),source=p.read_text().strip(),timex=adjustment()))
  if i<20:time.sleep(2)
 offsets=[s['realtime']-s['raw'] for s in samples]
 print('raw elapsed',samples[-1]['raw']-samples[0]['raw'],'realtime elapsed',samples[-1]['realtime']-samples[0]['realtime'],'offset span',max(offsets)-min(offsets),flush=True)
finally:
 if state:restore(state)
 p.write_text(original+'\n')
 if active:subprocess.run(['systemctl','start','systemd-timesyncd'],check=True)
 (E/'clock-discipline-probe.json').write_text(json.dumps(dict(original_source=original,original_timex=state,samples=samples,restored_source=p.read_text().strip(),restored_timex=adjustment()),indent=2))
