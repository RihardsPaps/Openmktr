from pathlib import Path
import json
E=Path('/root/openmktr-round2-20261030')
assert json.loads((E/'controller.json').read_text())['pass']
assert json.loads((E/'host-performance-controls.json').read_text())['pass']
assert all(x['exit_code']==0 for x in json.loads((E/'checks.json').read_text()))
print('Comparison and validation complete; safe to restore temporary resource settings')
