$ErrorActionPreference = 'Stop'
$round2Original = 'C:\Users\Harry\AppData\Local\Temp\omktr-round2-original.wslconfig'
$round2Config = 'C:\Users\Harry\.wslconfig'
$round2Expected = '359538deb7d243a51603cc594e2df502b5e4a96770dec01a0b5da66b9550e9cb'
if ((Get-FileHash -LiteralPath $round2Original -Algorithm SHA256).Hash.ToLowerInvariant() -ne $round2Expected) { throw 'Original resource configuration checksum differs' }
wsl -d Ubuntu-24.04 -u root -- python3 /mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-ready-to-restore.py
if ($LASTEXITCODE -ne 0) { throw 'Comparison or focused verification is incomplete' }
Copy-Item -LiteralPath $round2Original -Destination $round2Config -Force
if ((Get-FileHash -LiteralPath $round2Config -Algorithm SHA256).Hash.ToLowerInvariant() -ne $round2Expected) { throw 'Restored configuration checksum differs' }
wsl --shutdown
wsl -d Ubuntu-24.04 -u root -- python3 /mnt/c/Users/Harry/AppData/Local/Temp/omktr-round2-record-restoration.py
if ($LASTEXITCODE -ne 0) { throw 'Restoration verification failed' }
