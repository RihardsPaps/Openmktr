from pathlib import Path
import shutil
R=Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool');E=Path('/root/openmktr-round2-20261030');T=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
s=(R/'validation/benchmark_libreoffice.py').read_text()
s=s.replace("        if jumps:\n            raise RuntimeError('Clock discontinuities invalidate phase: ' + label)", "        if jumps:\n            print('guest-clock-diagnostic', label, len(jumps), 'adjustments; Windows Stopwatch is authoritative', flush=True)")
s=s.replace("Path(__file__).with_name('verify_release_archive.py')", "Path('/mnt/c/Users/Harry/Documents/ChatGPT/Universal Tool/validation/verify_release_archive.py')")
(E/'benchmark-windows-clock.py').write_text(s)
s=(T/'omktr-round2-compare.py').read_text();a=s.index(" clock_path.write_text('hyperv_clocksource_tsc_page");b=s.index(' for source,target',a)
s=s[:a]+" result['clock_source']=dict(original=original_clock,selected=original_clock)\n result['timing_authority']='Windows Stopwatch per phase; guest clocks are diagnostic'\n print('Windows Stopwatch phase timing enabled',flush=True)\n"+s[b:]
s=s.replace("str(R/'validation/benchmark_libreoffice.py')", "str(E/'benchmark-windows-clock.py')")
(T/'omktr-round2-compare.py').write_text(s)
shutil.copy2(R/'validation/verify_release_archive.py',E/'verify_release_archive.py')
print('Prepared host-clock comparison; production benchmark harness unchanged')
