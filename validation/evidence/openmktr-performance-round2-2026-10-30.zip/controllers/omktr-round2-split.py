from pathlib import Path
p=Path('/mnt/c/Users/Harry/AppData/Local/Temp')
s=(p/'omktr-round2-compare.py').read_text()
a=s.index(' for pair,lanes');b=s.index(" result['pass']=True",a)
pre=s[:a]+s[b:]
pre=pre.replace("E/'controller.json'", "E/'preflight-controller.json'")
(p/'omktr-round2-preflight.py').write_text(pre)
a=s.index(" before=(R/'tests/bench.py')");b=s.index(' for pair,lanes',a)
s=s[:a]+s[b:]
(p/'omktr-round2-compare.py').write_text(s)
