from pathlib import Path
import os,json,fcntl
p=Path('/root/openmktr-round2-20261030/shared-context-production.json');rows=json.loads(p.read_text())
for row in rows:
 for name,target in list(row['shared_context_descriptors'].items()):
  fd=os.open('/proc/'+str(row['pid'])+'/fd/'+name,os.O_RDONLY)
  try:
   seals=fcntl.fcntl(fd,fcntl.F_GET_SEALS);required=fcntl.F_SEAL_WRITE|fcntl.F_SEAL_GROW|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_SEAL;assert seals&required==required
   row['shared_context_descriptors'][name]=dict(target=target,seals=seals,bytes=os.fstat(fd).st_size,all_required_seals=True)
  finally:os.close(fd)
p.write_text(json.dumps(rows,indent=2));print(rows)
