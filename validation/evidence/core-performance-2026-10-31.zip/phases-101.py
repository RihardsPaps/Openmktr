import json,os,statistics,subprocess,time,sys
from pathlib import Path
root=Path('/evidence/'+sys.argv[1]); root.mkdir(exist_ok=True)
binaries={'b':'/baseline/omktr','c':'/workspace/omktr'}
for name in binaries:
 d=root/name;d.mkdir(exist_ok=True)
 (d/'Makefile').write_text(''.join(f'VAR{i} := value{i}\n' for i in range(10000))+''.join(f'target{i}:\n\t@:\n' for i in range(10000))+'all: '+' '.join(f'target{i}' for i in range(10000))+'\n')
results=[]
for phase,extra in [('convert',['--ninja']),('syntax',['-c']),('direct_dry',['-n']),('noop_regen',['--ninja','--regen'])]:
 for repeat in range(103):
  for name in ('bc' if repeat%2==0 else 'cb'):
   t=time.perf_counter();p=subprocess.Popen([binaries[name],*extra,'all'],cwd=root/name,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=dict(PATH='/usr/bin:/bin',HOME='/root',LC_ALL='C',TZ='UTC'));_,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
   assert p.returncode==0
   results.append(dict(repeat=repeat,variant=name,phase=phase,wall=time.perf_counter()-t,user=u.ru_utime,system=u.ru_stime,rss=u.ru_maxrss))
(root/'times.json').write_text(json.dumps(results,indent=2)+'\n')
for phase in dict.fromkeys(r['phase'] for r in results):
 for name in binaries:
  rows=[r for r in results if r['phase']==phase and r['variant']==name and r['repeat']>=2]
  print(phase,name,{k:statistics.median(r[k] for r in rows) for k in ['wall','user','system','rss']})
