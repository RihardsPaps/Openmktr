#include <stdio.h>
#include "command.h"
#include "dep.h"
#include "rule.h"
#include "stmt.h"
#include "var.h"
int main() {
  printf("Command %zu DepNode %zu Rule %zu RuleStmt %zu SimpleVar %zu\n",sizeof(Command),sizeof(DepNode),sizeof(Rule),sizeof(RuleStmt),sizeof(SimpleVar));
}
