from pathlib import Path
import hashlib,json,re,zipfile
root=Path('/workspace/performance-fix-evidence')
out=Path('/workspace/Openmktr/validation/evidence')
name='core-performance-2026-10-31'
def read(path):return json.loads((root/path).read_text())
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
normal=read('acceptance-normal/gates.json');sanitizers=read('acceptance-sanitizers/sanitizers.json')
assert len(normal)==28 and all(x['exit_code']==0 for x in normal)
assert len(sanitizers)==17 and all(x['exit_code']==0 for x in sanitizers)
paired=read('acceptance-paired/report.json');phases=read('acceptance-phases/summary.json')
assert paired['no_regression_passed'] and all(x['passed'] for x in phases)
standard_controls=read('acceptance-standard-paired/summary.json')
assert len(standard_controls)==22 and all(x['passed'] for x in standard_controls)
incremental=read('acceptance-incremental/report.json')
assert not incremental['release_blocked'] and not incremental['performance_defects'] and not incremental['errors']
files=set()
allowed={'.log','.json','.jsonl','.py','.patch','.cc','.txt'}
for p in root.iterdir():
 if p.is_file() and not p.is_symlink() and p.suffix in allowed:files.add(p)
 if p.is_dir():
  for q in p.iterdir():
   if q.is_file() and not q.is_symlink() and q.suffix in allowed:files.add(q)
  if 'paired' in p.name or 'incremental' in p.name:
   for q in p.rglob('*'):
    if q.is_file() and not q.is_symlink() and q.suffix in {'.log','.json','.jsonl'} and not any(x.startswith(('.kati','.omktr')) for x in q.relative_to(p).parts):files.add(q)
# Never publish credentials accidentally retained in a diagnostic log. Report
# filenames only, so reviewing this safeguard cannot print a matching value.
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'sk-[A-Za-z0-9_-]{30,}',rb'Authorization: (?:Bearer|Basic) [A-Za-z0-9+/=_-]{16,}',rb'https?://[^\s/:]+:[^\s/@]+@']
suspect=[str(p.relative_to(root)) for p in files if any(re.search(pattern,p.read_bytes()) for pattern in patterns)]
assert not suspect,('Review suspected credential-bearing artifacts',suspect)
manifest={'schema':1,'runtime_revision':'fd7573bdd7e0166d3f97fa5d41e29b0e2613ae3f','entries':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(files)],'selection':'Logs, drivers, source patches, JSON reports and samples; build/output trees, generated caches and binaries are excluded. Retained binary hashes and paths are in acceptance-identities.json. Exploratory uncommitted states are diagnostic, not independently qualified revisions.'}
archive=out/(name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(root)))
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest['entries']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
archive_sha=digest(archive)
(out/(name+'.zip.sha256')).write_text(archive_sha+'  '+archive.name+'\n')
def cells(values):
 return [{k:v for k,v in x.items() if k not in ('paired_improvement_percent','ratios')} for x in values]
report={'schema':1,'date':'2026-10-31','baseline_revision':'77a397ffd7a1cc5f48e406f8cf9052a50cc0d150','runtime_revision':'fd7573bdd7e0166d3f97fa5d41e29b0e2613ae3f','environment':read('acceptance-identities.json'),'archive':{'file':archive.name,'sha256':archive_sha,'bytes':archive.stat().st_size,'entries':len(files)},'portable':{'passed':True,'commands':normal,'snapshots':{'safe':'858/858; zero quarantined crashes','aggressive':'858/858; zero quarantined crashes'}},'sanitizers':{'passed':True,'commands':sanitizers,'leak_detection':'Session ownership/arena unit uses detect_leaks=1. Other suites use their established detect_leaks=0 setting; this is not a whole-program leak result.'},'external_incremental':{'scenarios':len(incremental['runs']),'release_blocked':incremental['release_blocked'],'performance_defects':incremental['performance_defects'],'errors':incremental['errors']},'paired_acceptance':{'passed':paired['no_regression_passed'],'samples':31,'warmups':2,'jobs':4,'timing':cells(paired['no_regression']),'memory':cells(paired['memory'])},'phase_acceptance':{'passed':all(x['passed'] for x in phases),'samples':101,'warmups':2,'cells':cells(phases)},'standard_benchmark':read('acceptance-standard-bench.json'),'paired_standard_controls':{'passed':True,'cells':standard_controls,'precision_extension':read('acceptance-standard-paired/precision-extension.json')},'retained_failures_and_experiments':['The d542efb public launch-plan alias changed wildcard/snapshot behavior; aceef67 made it bundle-private. Original failed logs remain.','The aceef67 sanitizer session test found a poisoned tiny-slot free-list write. e7dfde5 unpoisons allocator metadata before recycling; the final full sanitizer run includes this fix.','Initial aceef67 snapshots encountered three root-owned temporary fixtures. Their ownership was repaired and both full profiles reran successfully; initial logs remain.','The e7dfde5 paired matrix missed the direct clean median gate by 0.24%; its 10,000-target conversion memory also regressed. Final queue and layout changes address these measurements.','The initial queue-lock consolidation did not improve its focused comparison and was reverted. Workers/batch-size experiments and raw samples remain.','An unprivileged sparse-groups build could not write existing root-owned object files. The build reran as root; final tests run as uid 1000.'],'limits':['Real PC qualification for Linux 7.3, FFmpeg 9.0.2 and LibreOffice 26.8.2.2 has not run. No universal or real-project performance guarantee is claimed.','The strict acceptance cells require paired median candidate/baseline <=1.00 and bootstrap 95% upper <=1.05; thresholds were not relaxed.','wait4 RSS is peak individual-process RSS, not simultaneous aggregate process-tree memory. Small workloads can be masked by the Python parent/exec high-water floor.','tests/bench.py measures candidates in separate blocks. Its raw medians are retained alongside alternating paired controls; neither unpaired drift nor improvements in another cell cancel a regression.','Exploratory uncommitted binaries are not relabeled as final code. Every final acceptance run uses the recorded fd7573b binary and pinned toolchain.']}
(out/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':len(files),'sha256':archive_sha},indent=2))
