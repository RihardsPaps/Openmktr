import json,os,statistics,random,subprocess,time
from pathlib import Path
root=Path('/evidence/acceptance-standard-paired')
(root/'summary-before-precision-extension.json').write_bytes((root/'summary.json').read_bytes())
rows=[json.loads(l) for l in (root/'samples.jsonl').read_text().splitlines()]
env=dict(PATH='/usr/bin:/bin',HOME='/root',LC_ALL='C',TZ='UTC')
for case in ('incremental_noop','direct_recipe_launch_j1'):
 start_repeat=max(r['repeat'] for r in rows if r['case']==case)+1
 for repeat in range(start_repeat,303):
  for variant in ('bc' if repeat%2==0 else 'cb'):
   tool='/baseline/omktr' if variant=='b' else '/workspace/omktr';d=root/case/variant
   command=[tool,'-j4','all'] if case=='incremental_noop' else [tool,'-j1']
   before={p.name:p.stat().st_mtime_ns for p in d.glob('link*')}
   start=time.perf_counter();p=subprocess.Popen(command,cwd=d,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   _,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
   result=dict(wall=time.perf_counter()-start,rss=u.ru_maxrss,user=u.ru_utime,system=u.ru_stime)
   assert p.returncode==0 and before=={p.name:p.stat().st_mtime_ns for p in d.glob('link*')}
   row=dict(case=case,repeat=repeat,warmup=False,variant=variant,**result);rows.append(row)
   with (root/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
summary=[]
for case in dict.fromkeys(r['case'] for r in rows):
 pairs={}
 for r in rows:
  if r['case']==case and not r['warmup']:pairs.setdefault(r['repeat'],{})[r['variant']]=r
 for metric in ['wall','rss']:
  ratios=[p['c'][metric]/p['b'][metric] for p in pairs.values()];rng=random.Random(0)
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
  summary.append(dict(case=case,metric=metric,pairs=len(pairs),baseline=statistics.median(p['b'][metric] for p in pairs.values()),candidate=statistics.median(p['c'][metric] for p in pairs.values()),median_ratio=statistics.median(ratios),interval=[boot[249],boot[9749]],passed=statistics.median(ratios)<=1 and boot[9749]<=1.05))
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'precision-extension.json').write_text(json.dumps(dict(cases=['incremental_noop','direct_recipe_launch_j1'],final_measured_pairs=301,original_samples_retained=True,reason='Fixed precision extension after equivocal 0.012%/0.22% medians; no source changes, sample exclusions, or threshold changes.'),indent=2)+'\n')
for x in summary:
 if x['case'] in ('incremental_noop','direct_recipe_launch_j1'):print(x)
