import json, os, subprocess, time
from pathlib import Path
root=Path('/evidence/diagnostic');root.mkdir(exist_ok=True)
for name,binary in [('baseline','/baseline/omktr'),('before','/evidence/architecture-before-omktr')]:
 d=root/name;d.mkdir(exist_ok=True)
 (d/'Makefile').write_text(''.join(f'VAR{i} := value{i}\n' for i in range(10000))+''.join(f'target{i}:\n\t@:\n' for i in range(10000))+'all: '+' '.join(f'target{i}' for i in range(10000))+'\n')
 command=[binary,'--ninja','all']
 for _ in range(2): subprocess.run(command,cwd=d,check=True,stdout=subprocess.DEVNULL)
 with (root/(name+'-stats.log')).open('w') as log:subprocess.run(command+['--kati_stats'],cwd=d,check=True,stdout=log,stderr=log)
 with (root/(name+'-strace.log')).open('w') as log:subprocess.run(['strace','-c',*command],cwd=d,check=True,stdout=subprocess.DEVNULL,stderr=log)
results=[]
for repeat in range(9):
 for name,binary in ([('baseline','/baseline/omktr'),('before','/evidence/architecture-before-omktr')] if repeat%2==0 else [('before','/evidence/architecture-before-omktr'),('baseline','/baseline/omktr')]):
  d=root/name
  for phase,extra in [('convert',['--ninja']),('direct_dry',['-n']),('syntax',['-c']),('noop_regen',['--ninja','--regen'])]:
   t=time.perf_counter();p=subprocess.Popen([binary,*extra,'all'],cwd=d,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);_,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
   assert p.returncode==0
   results.append(dict(repeat=repeat,variant=name,phase=phase,wall=time.perf_counter()-t,user=u.ru_utime,system=u.ru_stime,rss_kib=u.ru_maxrss))
(root/'times.json').write_text(json.dumps(results,indent=2)+'\n')
