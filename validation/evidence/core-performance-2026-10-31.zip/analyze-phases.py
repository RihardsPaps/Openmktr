import json,random,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]); rows=json.loads((root/'times.json').read_text()); report=[]
for phase in dict.fromkeys(row['phase'] for row in rows):
 pairs={}
 for row in rows:
  if row['phase']==phase and row['repeat']>=2:pairs.setdefault(row['repeat'],{})[row['variant']]=row
 for metric in ['wall','rss']:
  ratios=[pair['c'][metric]/pair['b'][metric] for pair in pairs.values()]
  rng=random.Random(0); boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
  report.append(dict(phase=phase,metric=metric,pairs=len(pairs),baseline=statistics.median(p['b'][metric] for p in pairs.values()),candidate=statistics.median(p['c'][metric] for p in pairs.values()),median_ratio=statistics.median(ratios),interval=[boot[249],boot[9749]],passed=statistics.median(ratios)<=1 and boot[9749]<=1.05,ratios=ratios))
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for row in report:print({k:v for k,v in row.items() if k!='ratios'})
