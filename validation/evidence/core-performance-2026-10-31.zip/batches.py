import json,os,statistics,subprocess,time
from pathlib import Path
root=Path('/evidence/batches');root.mkdir(exist_ok=True)
binaries={'b':'/baseline/omktr','c':'/evidence/four-worker-omktr','d':'/workspace/omktr'}
env=dict(PATH='/usr/bin:/bin',HOME='/root',LC_ALL='C',TZ='UTC')
for name in binaries:
 d=root/name;d.mkdir(exist_ok=True)
 (d/'config.mk').write_text('MODE := base\n')
 (d/'Makefile').write_text('include config.mk\n.PHONY: all\nall: '+' '.join(f'out{i}' for i in range(512))+'\n'+''.join(f'out{i}: src{i} config.mk\n\t@printf \'$(MODE):\' > $@; cat $< >> $@\n' for i in range(512)))
 for i in range(512): (d/f'src{i}').write_text(f'input {i}\n')
results=[]
for repeat in range(17):
 order=list(binaries);order=order[repeat%3:]+order[:repeat%3]
 if repeat%2: order.reverse()
 for name in order:
  d=root/name
  for p in d.glob('out*'):p.unlink()
  start=time.perf_counter();p=subprocess.Popen([binaries[name],'-j4','all'],cwd=d,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);_,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
  elapsed=time.perf_counter()-start
  assert p.returncode==0
  assert all((d/f'out{i}').read_text()==f'base:input {i}\n' for i in range(512))
  results.append(dict(repeat=repeat,variant=name,wall=elapsed,user=u.ru_utime,system=u.ru_stime,rss=u.ru_maxrss))
(root/'times.json').write_text(json.dumps(results,indent=2)+'\n')
for name in binaries:
 rows=[r for r in results if r['variant']==name and r['repeat']>=2]
 print(name,{k:statistics.median(r[k] for r in rows) for k in ['wall','user','system','rss']})
