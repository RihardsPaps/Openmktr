import os,subprocess
from pathlib import Path
root=Path('/evidence/padding-dispatch')
env=dict(PATH='/usr/bin:/bin',HOME='/root',LC_ALL='C',TZ='UTC')
for name,tool in [('b','/baseline/omktr'),('c','/evidence/e7dfde5-omktr'),('d','/workspace/omktr')]:
 d=root/name
 for prefix,extra in [('stats',['--kati_stats']),('trace',[])]:
  for p in d.glob('out*'):p.unlink()
  command=[tool,'-j4',*extra,'all']
  if prefix=='trace': command=['strace','-f','-c','-o',f'/evidence/direct-{name}-strace.log',*command]
  with open(f'/evidence/direct-{name}-{prefix}.log','w') as f:
   subprocess.run(command,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
